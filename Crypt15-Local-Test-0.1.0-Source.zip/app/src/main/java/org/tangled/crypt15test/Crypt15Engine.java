package org.tangled.crypt15test;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Locale;
import java.util.zip.InflaterInputStream;
import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Proof-of-concept decoder for standard WhatsApp .crypt15 backups.
 * Built from the publicly documented header / AES-GCM structure of ElDavoo/wa-crypt-tools.
 * Does not use or modify the WhatsApp installation. Does not allow unauthenticated output.
 */
public final class Crypt15Engine {
    public interface Progress { void onProgress(String phase); }
    private static final int BUFFER = 64 * 1024;
    private Crypt15Engine() {}

    public static final class Result {
        public final boolean sqlite;
        public final long bytes;
        Result(boolean sqlite, long bytes) { this.sqlite = sqlite; this.bytes = bytes; }
    }

    public static Result decrypt(File crypt, File output, String hexKey, Progress progress) throws Exception {
        if (crypt == null || !crypt.isFile()) throw new IOException("Select a valid .crypt15 file.");
        String normalized = hexKey.replaceAll("\\s", "");
        if (!normalized.matches("(?i)[0-9a-f]{64}"))
            throw new IllegalArgumentException("Key must contain exactly 64 hexadecimal characters (0–9, A–F).");
        byte[] root = fromHex(normalized);
        byte[] key = deriveKey(root);
        Arrays.fill(root, (byte)0);
        Header header;
        try (InputStream in = new BufferedInputStream(new FileInputStream(crypt))) {
            header = parseHeader(in);
        }
        if (crypt.length() < header.length + 17) throw new IOException("Backup is truncated.");
        progress.onProgress("Verifying backup checksum…");
        boolean hasMd5 = checkMd5(crypt);
        long encryptedLength = crypt.length() - header.length - (hasMd5 ? 32 : 16);
        if (encryptedLength < 1) throw new IOException("Encrypted payload is empty.");
        // In the normal variant: [ciphertext][GCM-tag][MD5]; in a multi-file variant: [ciphertext][GCM-tag].
        File compressed = new File(output.getParentFile(), "payload-" + System.nanoTime() + ".tmp");
        try {
            progress.onProgress("Decrypting and authenticating…");
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, header.iv));
            Arrays.fill(key, (byte)0);
            try (InputStream in = new BufferedInputStream(new FileInputStream(crypt));
                 OutputStream out = new BufferedOutputStream(new FileOutputStream(compressed))) {
                skipFully(in, header.length);
                long remaining = encryptedLength;
                byte[] buffer = new byte[BUFFER];
                while (remaining > 0) {
                    int amount = in.read(buffer, 0, (int)Math.min(buffer.length, remaining));
                    if (amount < 0) throw new EOFException("Encrypted data truncated.");
                    byte[] part = cipher.update(buffer, 0, amount);
                    if (part != null && part.length > 0) out.write(part);
                    remaining -= amount;
                }
                byte[] tag = new byte[16];
                readFully(in, tag);
                byte[] finalPart = cipher.doFinal(tag); // Throws AEADBadTagException on invalid key/corruption.
                if (finalPart != null && finalPart.length > 0) out.write(finalPart);
            }
            progress.onProgress("Decompressing verified data…");
            byte[] head = new byte[4];
            try (InputStream in = new FileInputStream(compressed)) {
                if (in.read(head) != 4) throw new IOException("Decrypted payload is empty.");
            }
            boolean rawZip = head[0] == 'P' && head[1] == 'K';
            try (InputStream source = new BufferedInputStream(new FileInputStream(compressed));
                 InputStream decoded = rawZip ? source : new InflaterInputStream(source);
                 OutputStream out = new BufferedOutputStream(new FileOutputStream(output))) {
                byte[] buffer = new byte[BUFFER];
                int n;
                while ((n = decoded.read(buffer)) >= 0) if (n > 0) out.write(buffer, 0, n);
            } catch (Exception e) {
                output.delete();
                throw new IOException("Authenticated payload couldn't be decompressed: " + e.getMessage(), e);
            }
            try (InputStream in = new FileInputStream(output)) {
                byte[] signature = new byte[16];
                readFully(in, signature);
                boolean sqlite = Arrays.equals(signature, "SQLite format 3\u0000".getBytes(StandardCharsets.US_ASCII));
                boolean zip = signature[0] == 'P' && signature[1] == 'K';
                if (!sqlite && !zip) {
                    output.delete();
                    throw new IOException("Decryption succeeded, but the result was not SQLite or ZIP.");
                }
                return new Result(sqlite, output.length());
            }
        } catch (Exception ex) {
            output.delete();
            throw ex;
        } finally {
            Arrays.fill(key, (byte)0);
            compressed.delete();
        }
    }

    static byte[] deriveKey(byte[] root) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(new byte[32], "HmacSHA256"));
        byte[] intermediate = mac.doFinal(root);
        mac.init(new SecretKeySpec(intermediate, "HmacSHA256"));
        mac.update("backup encryption".getBytes(StandardCharsets.US_ASCII));
        mac.update((byte) 1);
        byte[] result = mac.doFinal();
        Arrays.fill(intermediate, (byte)0);
        return result;
    }
    private static byte[] fromHex(String value) {
        byte[] out = new byte[32];
        for (int i=0;i<32;i++) out[i] = (byte)((Character.digit(value.charAt(i*2),16)<<4) | Character.digit(value.charAt(i*2+1),16));
        return out;
    }
    private static boolean checkMd5(File file) throws Exception {
        MessageDigest md5 = MessageDigest.getInstance("MD5");
        long remain = file.length() - 16;
        if (remain < 1) return false;
        try (InputStream in = new BufferedInputStream(new FileInputStream(file))) {
            byte[] buffer = new byte[BUFFER];
            while (remain > 0) {
                int n = in.read(buffer, 0, (int)Math.min(remain, buffer.length));
                if (n < 0) throw new EOFException("Unexpected end of file.");
                md5.update(buffer,0,n);
                remain -= n;
            }
            byte[] tail = new byte[16];
            readFully(in, tail);
            return MessageDigest.isEqual(md5.digest(), tail);
        }
    }
    static final class Header { final byte[] iv; final long length; Header(byte[] iv, long length){this.iv=iv;this.length=length;} }
    static Header parseHeader(InputStream in) throws IOException {
        long[] count = {0};
        long size = varint(in, count);
        if (size < 4 || size > 1048576) throw new IOException("Unsupported Crypt15 header length: " + size);
        byte[] data = new byte[(int)size];
        readFully(in, data);
        byte[] wrapped = field(data, 3);
        if (wrapped == null) throw new IOException("Not a recognised Crypt15 E2EE header (missing field 3).");
        byte[] iv = field(wrapped, 1);
        if (iv == null || iv.length != 16) throw new IOException("Crypt15 IV is missing or invalid.");
        return new Header(iv, size + count[0]);
    }
    private static byte[] field(byte[] proto, int desired) throws IOException {
        int[] pos = {0};
        while (pos[0] < proto.length) {
            long tag = varint(proto, pos);
            int wire = (int)(tag & 7);
            int number = (int)(tag >>> 3);
            if (number == 0) throw new IOException("Invalid protobuf field.");
            if (wire == 2) {
                long len = varint(proto, pos);
                if (len < 0 || len > proto.length - pos[0]) throw new IOException("Invalid protobuf length.");
                if (number == desired) return Arrays.copyOfRange(proto,pos[0],pos[0]+(int)len);
                pos[0] += (int)len;
            } else if (wire == 0) { varint(proto, pos); }
            else if (wire == 1) { pos[0] += 8; }
            else if (wire == 5) { pos[0] += 4; }
            else throw new IOException("Unsupported protobuf wire type " + wire);
            if (pos[0] > proto.length) throw new IOException("Truncated protobuf header.");
        }
        return null;
    }
    private static long varint(InputStream in, long[] count) throws IOException {
        long result=0;
        for(int i=0;i<10;i++) {
            int b=in.read(); if(b<0) throw new EOFException("Truncated header varint.");
            count[0]++;
            result |= (long)(b & 127) << (7*i);
            if ((b&128)==0) return result;
        }
        throw new IOException("Oversized varint.");
    }
    private static long varint(byte[] data, int[] pos) throws IOException {
        long result=0;
        for(int i=0;i<10;i++) {
            if(pos[0]>=data.length)throw new EOFException("Truncated protobuf varint.");
            int b=data[pos[0]++]&255;
            result |= (long)(b & 127) << (7*i);
            if ((b&128)==0) return result;
        }
        throw new IOException("Oversized protobuf varint.");
    }
    private static void readFully(InputStream in, byte[] bytes) throws IOException {
        int pos=0;
        while(pos<bytes.length){ int n=in.read(bytes,pos,bytes.length-pos);if(n<0)throw new EOFException("Truncated input.");pos+=n; }
    }
    private static void skipFully(InputStream in, long bytes) throws IOException {
        while(bytes>0){long n=in.skip(bytes);if(n<=0){if(in.read()<0)throw new EOFException("Truncated header.");n=1;}bytes-=n;}
    }
}
