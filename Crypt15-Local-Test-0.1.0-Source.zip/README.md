# Crypt15 Local Test — standalone Android proof of concept

**Purpose:** Test locally decrypting your own WhatsApp `.crypt15` backup with its 64-character hexadecimal key and determine whether the decrypted database contains message / quote / reaction tables. This does NOT connect to Tangled yet.

**Privacy:** No INTERNET permission. No analytics. User-selected backup is copied to app-private cache, the key is used in-memory and cleared from the UI, AES-GCM authentication is verified before output is accepted, and the SQLite database remains private unless you deliberately export it. All previous temp files are removed on opening the app. Be careful with exported decrypted databases; they contain private chat data.

**Supported:** Crypt15 backups whose protobuf header contains `BackupPrefix.e2ee_key_data.encryption_iv`; single-file database variant (ciphertext + 16-byte GCM tag + MD5) and multifile variant (ciphertext + 16-byte GCM tag). Payload may be zlib compressed SQLite or ZIP. ZIP is decrypted and can be exported but isn't yet inspected internally. This prototype has not been tested with the user's real backup or on a physical Android phone.

**Build:** This is an Android Studio / GitHub Actions Gradle project using Android Gradle Plugin 8.7.3, Java 17, compile SDK 35. No third-party runtime dependencies. GitHub Action `.github/workflows/build-apk.yml` builds a debug APK and publishes it as a workflow artifact.

**Use:** Select `.crypt15` using the Android picker → enter 64-character key → Decrypt and inspect locally → check reported tables / counts. If successful, selectively export `msgstore.db` for offline use; do not upload your key, database, or plaintext reports.

**Implementation references:** ElDavoo/wa-crypt-tools, especially `src/wa_crypt_tools/lib/db/db15.py`, `src/wa_crypt_tools/lib/key/key15.py`, `src/wa_crypt_tools/lib/utils.py`, and the `proto/backup_prefix.proto`, `proto/C15_IV.proto` definitions: https://github.com/ElDavoo/wa-crypt-tools . This is an independent Java implementation of the specified AES-GCM format.

**Limits:** No extraction of actual quoted/reaction message pairs yet. Potential provider-specific large-file performance/memory constraints. No proper secure key memory wiping (Java strings cannot reliably be wiped). Files temporarily occupy internal storage; ensure enough space. Do not uninstall/alter WhatsApp or delete original backup. The first task is validating compatibility with a real file.

**If you prefer the ZIP-in-repository workflow familiar from Tangled:** Upload `Crypt15-Local-Test-0.1.0-Source.zip` to the root of a GitHub repository and add the workflow from `.github/workflows/build-from-zip.yml` to that repository's workflow directory. It unpacks the ZIP during GitHub Actions and builds the APK. Do not accidentally run both workflows in the same repo unless you want two builds.
