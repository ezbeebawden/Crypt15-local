package org.tangled.crypt15test;
import java.io.*;import java.util.*;import java.util.zip.*;import java.nio.file.*;import java.security.*;
import javax.crypto.*;import javax.crypto.spec.*;
public class TestCrypt15 {
 static byte[] v(int n){ByteArrayOutputStream b=new ByteArrayOutputStream();while(true){int x=n&127;n>>>=7;b.write(n==0?x:x|128);if(n==0)return b.toByteArray();}}
 static byte[] f(int tag,byte[] d)throws Exception {ByteArrayOutputStream b=new ByteArrayOutputStream();b.write(v(tag*8+2));b.write(v(d.length));b.write(d);return b.toByteArray();}
 static byte[] z(byte[] in)throws Exception{ByteArrayOutputStream o=new ByteArrayOutputStream();try(DeflaterOutputStream d=new DeflaterOutputStream(o)){d.write(in);}return o.toByteArray();}
 static void test(boolean md5,boolean zip)throws Exception {
  byte[] root=new byte[32];for(int i=0;i<32;i++)root[i]=(byte)i;
  StringBuilder key=new StringBuilder();for(byte b:root)key.append(String.format("%02x",b&255));
  byte[] iv=new byte[16];for(int i=0;i<16;i++)iv[i]=(byte)(16+i);
  byte[] header=f(3,f(1,iv));ByteArrayOutputStream output=new ByteArrayOutputStream();output.write(v(header.length));output.write(header);
  byte[] sqlite=zip?"PK\003\004some zip content!!!!".getBytes():"SQLite format 3\000dummy db content".getBytes();
  byte[] data=z(sqlite);
  Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(Crypt15Engine.deriveKey(root),"AES"),new GCMParameterSpec(128,iv));output.write(c.doFinal(data));
  if(md5)output.write(MessageDigest.getInstance("MD5").digest(output.toByteArray()));
  File input=File.createTempFile("crypt15test",".crypt15");File dec=File.createTempFile("crypt15out",".db");
  try{Files.write(input.toPath(),output.toByteArray());Crypt15Engine.Result r=Crypt15Engine.decrypt(input,dec,key.toString(),s->{});
   if(r.sqlite==zip || !Arrays.equals(Files.readAllBytes(dec.toPath()),sqlite))throw new AssertionError("result mismatch");
   try{Crypt15Engine.decrypt(input,dec,"0".repeat(64),s->{});throw new AssertionError("wrong key accepted");}catch(javax.crypto.AEADBadTagException expected){}
   byte[] tamper=Files.readAllBytes(input.toPath());tamper[tamper.length-40]^=1;Files.write(input.toPath(),tamper);
   try{Crypt15Engine.decrypt(input,dec,key.toString(),s->{});throw new AssertionError("tamper accepted");}catch(javax.crypto.AEADBadTagException expected){}
   System.out.println("PASS MD5="+md5+" zip="+zip);
  }finally{input.delete();dec.delete();}
 }
 public static void main(String[]args)throws Exception{test(true,false);test(false,false);test(true,true);test(false,true);}
}
