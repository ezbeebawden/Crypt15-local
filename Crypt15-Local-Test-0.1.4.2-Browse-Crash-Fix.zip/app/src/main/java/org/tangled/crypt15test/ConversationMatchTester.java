package org.tangled.crypt15test;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.content.ContentResolver;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.time.*;
import java.time.format.*;
import java.util.*;
import java.util.regex.*;
import java.util.zip.*;

/** Read-only proof of concept. No chat text or identifiers leave this process. */
final class ConversationMatchTester {
    interface Progress { void tell(String info); }
    static final Pattern LINE = Pattern.compile("^[\\u200e\\u200f]*\\[?(\\d{1,2})/(\\d{1,2})/(\\d{2,4}),?\\s+(\\d{1,2}):(\\d{2})(?::(\\d{2}))?\\s*(AM|PM|am|pm)?\\]?\\s*(?:[-–]\\s*)?(.*)$");
    static final class Entry {
        long ms; String sender, text; boolean self;
        Entry(long ms,String sender,String text) {this.ms=ms;this.sender=sender;this.self=sender.equalsIgnoreCase("You")||sender.equalsIgnoreCase("Steve B");this.text=text;}
    }
    static final class DbMsg {
        long row, ms; String key, text; boolean self;
        DbMsg(long row,long ms,String key,String text,boolean self){this.row=row;this.ms=ms;this.key=key;this.text=text;this.self=self;}
    }
    static String norm(String s) {
        if(s==null)return "";
        return Normalizer.normalize(s,Normalizer.Form.NFKC).replace("\u200e", "").replace("\u200f", "").replace("\u00a0", " ").trim().replaceAll("\\s+", " ");
    }
    static boolean mediaPlaceholder(String s) {return s.equalsIgnoreCase("<Media omitted>")||s.equalsIgnoreCase("Media omitted")||s.startsWith("<attached:");}
    static List<Entry> parseZip(ContentResolver resolver,Uri uri) throws Exception {
        byte[] txt=null;
        try(InputStream in=resolver.openInputStream(uri); ZipInputStream zip=new ZipInputStream(new BufferedInputStream(in))) {
            ZipEntry e;
            while((e=zip.getNextEntry())!=null){
                String n=e.getName().toLowerCase(Locale.ROOT);
                if(n.endsWith(".txt")&&(n.contains("chat") || txt==null)){
                    ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[32768];int x;
                    while((x=zip.read(b))>=0){out.write(b,0,x);if(out.size()>100*1024*1024)throw new IOException("Chat text exceeds 100 MB");}
                    txt=out.toByteArray();
                    if(n.contains("chat")) break;
                }
            }
        }
        if(txt==null)throw new IOException("ZIP contains no conversation .txt file");
        String all=new String(txt,StandardCharsets.UTF_8).replace("\ufeff", "");
        // WhatsApp Web exports with AM/PM use US M/D/Y; Android exports generally D/M/Y.
        boolean us=Pattern.compile("(?m)^\\[?\\d{1,2}/\\d{1,2}/\\d{2,4},?\\s+\\d{1,2}:\\d{2}(?::\\d{2})?\\s*[AP]M",Pattern.CASE_INSENSITIVE).matcher(all).find();
        ArrayList<Entry> result=new ArrayList<>();
        ZoneId zone=ZoneId.systemDefault();
        Entry current=null;
        for(String raw:all.split("\\n",-1)){
            String line=raw.replace("\r", "");Matcher m=LINE.matcher(line);
            if(m.matches()){
                try {
                    int d=Integer.parseInt(m.group(us?2:1)),mo=Integer.parseInt(m.group(us?1:2)),y=Integer.parseInt(m.group(3));
                    if(y<100)y+=y>=70?1900:2000;
                    int h=Integer.parseInt(m.group(4)),mi=Integer.parseInt(m.group(5));
                    int ss=m.group(6)==null?0:Integer.parseInt(m.group(6));
                    if(m.group(7)!=null){h=h%12+ (m.group(7).equalsIgnoreCase("PM")?12:0);}
                    long ms=LocalDateTime.of(y,mo,d,h,mi,ss).atZone(zone).toInstant().toEpochMilli();
                    String remainder=m.group(8);
                    int sep=remainder.indexOf(": ");
                    if(sep>0 && sep<90){
                        String sender=remainder.substring(0,sep).trim();
                        current=new Entry(ms,sender,remainder.substring(sep+2));result.add(current);
                    }else current=null;
                    continue;
                }catch(Exception ignored){}
            }
            if(current!=null)current.text+="\n"+line;
        }
        if(result.isEmpty())throw new IOException("No WhatsApp timestamped messages parsed. Check the export format.");
        return result;
    }
    static String run(File dbFile,ContentResolver resolver,Uri zipUri,Progress progress) throws Exception {
        progress.tell("Reading exported chat ZIP…");
        List<Entry> exported=parseZip(resolver,zipUri);
        ArrayList<Entry> samples=new ArrayList<>();
        for(Entry e:exported)if(norm(e.text).length()>15 && !mediaPlaceholder(norm(e.text)))samples.add(e);
        if(samples.isEmpty())throw new IOException("No suitable text messages for identifying the chat.");
        // Spread across the whole chat to avoid choosing a chat from a repeated phrase.
        ArrayList<Entry> picked=new ArrayList<>();int limit=Math.min(160,samples.size());
        for(int i=0;i<limit;i++)picked.add(samples.get((int)((long)i*samples.size()/limit)));
        progress.tell("Identifying the conversation from " + picked.size()+" sample messages…");
        SQLiteDatabase db=SQLiteDatabase.openDatabase(dbFile.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY);
        try {
            HashMap<Long,Integer> chatScores=new HashMap<>();
            for(Entry e:picked){
                long tolerance= e.ms%60000==0?65000:75000; // minute-resolution or second-resolution exports
                try(Cursor c=db.rawQuery("SELECT chat_row_id, text_data, from_me FROM message WHERE timestamp BETWEEN ? AND ? AND text_data IS NOT NULL",new String[]{String.valueOf(e.ms-tolerance),String.valueOf(e.ms+tolerance)})){
                    while(c.moveToNext()){
                        if(norm(e.text).equals(norm(c.getString(1))) && (e.self==(c.getInt(2)!=0) || !e.sender.equalsIgnoreCase("You"))){
                            long id=c.getLong(0);chatScores.put(id,chatScores.getOrDefault(id,0)+1);
                        }
                    }
                }
            }
            if(chatScores.isEmpty())throw new IOException("No matching database conversation found. Check phone timezone and that the backup includes these messages.");
            ArrayList<Map.Entry<Long,Integer>> ranked=new ArrayList<>(chatScores.entrySet());ranked.sort((a,b)->b.getValue()-a.getValue());
            long chatId=ranked.get(0).getKey();int score=ranked.get(0).getValue();
            int runnerUp=ranked.size()>1?ranked.get(1).getValue():0;
            if(score<3 || (runnerUp>0 && score<runnerUp*2))throw new IOException("Conversation identification ambiguous (best "+score+", second "+runnerUp+"). No private data exported.");
            progress.tell("Conversation identified ("+score+" matching samples). Matching messages…");
            ArrayList<DbMsg> dbMsgs=new ArrayList<>();
            HashMap<Long,DbMsg> byRow=new HashMap<>();
            HashMap<String,DbMsg> byKey=new HashMap<>();
            try(Cursor c=db.rawQuery("SELECT _id,timestamp,key_id,text_data,from_me FROM message WHERE chat_row_id=? ORDER BY timestamp",new String[]{String.valueOf(chatId)})){
                while(c.moveToNext()){
                    DbMsg m=new DbMsg(c.getLong(0),c.getLong(1),c.getString(2),c.getString(3),c.getInt(4)!=0);
                    dbMsgs.add(m);byRow.put(m.row,m);if(m.key!=null)byKey.put(m.key,m);
                }
            }
            HashMap<Long,List<DbMsg>> secondBins=new HashMap<>();
            for(DbMsg m:dbMsgs)secondBins.computeIfAbsent(m.ms/60000,k->new ArrayList<>()).add(m);
            HashSet<Long> matchedRows=new HashSet<>();int matched=0,ambiguous=0,unmatched=0,nonText=0;
            for(Entry e:exported){
                String t=norm(e.text);
                if(t.isEmpty()||mediaPlaceholder(t)){nonText++;continue;}
                ArrayList<DbMsg> candidates=new ArrayList<>();
                long bucket=e.ms/60000;
                for(long b=bucket-2;b<=bucket+2;b++){
                    List<DbMsg> list=secondBins.get(b);if(list==null)continue;
                    for(DbMsg m:list){if(m.text==null||matchedRows.contains(m.row))continue;
                        if(Math.abs(m.ms-e.ms)<=75000 && norm(m.text).equals(t) && (!e.self||m.self)) candidates.add(m);
                    }
                }
                if(candidates.size()==1){matched++;matchedRows.add(candidates.get(0).row);}
                else if(candidates.size()>1)ambiguous++;
                else unmatched++;
            }
            progress.tell("Matching database quote and reaction relationships…");
            long quotesTotal=0,quotedRepliesMatched=0,quotesLinked=0,quotesOriginalPresent=0;
            try(Cursor c=db.rawQuery("SELECT q.message_row_id,q.key_id FROM message_quoted q JOIN message m ON m._id=q.message_row_id WHERE m.chat_row_id=?",new String[]{String.valueOf(chatId)})){
                while(c.moveToNext()){
                    quotesTotal++;long reply=c.getLong(0);String originalKey=c.getString(1);
                    if(matchedRows.contains(reply)){
                        quotedRepliesMatched++;
                        if(originalKey!=null && byKey.containsKey(originalKey)){
                            quotesOriginalPresent++;
                            if(matchedRows.contains(byKey.get(originalKey).row))quotesLinked++;
                        }
                    }
                }
            }
            long reactionsTotal=0,reactedMessagesMatched=0,fromMe=0,fromOthers=0;
            try(Cursor c=db.rawQuery("SELECT a.parent_message_row_id,a.from_me FROM message_add_on_reaction r JOIN message_add_on a ON a._id=r.message_add_on_row_id WHERE a.chat_row_id=?",new String[]{String.valueOf(chatId)})){
                while(c.moveToNext()){
                    reactionsTotal++;
                    if(matchedRows.contains(c.getLong(0))){reactedMessagesMatched++;if(c.getInt(1)!=0)fromMe++;else fromOthers++;}
                }
            }
            int eligible=exported.size()-nonText;
            return "MATCH TEST COMPLETE (local only)\n\n"+
                "Exported messages parsed: "+exported.size()+"\n"+
                "Database messages in identified chat: "+dbMsgs.size()+"\n"+
                "Conversation identification: "+score+" / "+picked.size()+" samples\n\n"+
                "TEXT MESSAGE MATCHING\n"+
                "Exact unique matches: "+matched+" / "+eligible+"\n"+
                "Ambiguous: "+ambiguous+"\nUnmatched: "+unmatched+"\n"+
                "Media/system placeholders skipped: "+nonText+"\n\n"+
                "QUOTED MESSAGES\n"+
                "Quote records in database chat: "+quotesTotal+"\n"+
                "Quoted replies matched to export: "+quotedRepliesMatched+"\n"+
                "Matched replies whose original is in DB chat: "+quotesOriginalPresent+"\n"+
                "Both reply and original matched to export: "+quotesLinked+"\n\n"+
                "REACTIONS\n"+
                "Reaction records in database chat: "+reactionsTotal+"\n"+
                "Reaction records linked to matched export messages: "+reactedMessagesMatched+"\n"+
                "On matched messages, reacted by self: "+fromMe+"; other: "+fromOthers+"\n\n"+
                "LIMITATIONS: Exact text/time matching only. Media, edits, emoji formatting, identity variants and different export timezones may reduce matches. Quoted key IDs are only counted as linked when both original and reply matched uniquely. No messages, names, IDs or keys are exported. No existing Tangled archive is changed.";
        } finally {db.close();}
    }
}
