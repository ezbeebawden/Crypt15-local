package org.tangled.crypt15test;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.view.View;
import android.widget.*;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;

/** Read-only conversation reconstruction from a locally decrypted WhatsApp SQLite database. */
final class ConversationBrowser {
    private final Activity activity;
    private final File database;
    private final LinearLayout screen;
    private final ScrollView scroll;
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy HH:mm", Locale.UK);
    private long selectedChat=-1;
    private long beforeTimestamp=Long.MAX_VALUE;
    private long beforeRow=Long.MAX_VALUE;
    private String selectedTitle="";
    private int chatOffset=0;
    private boolean busy=false;
    private static final int PAGE=100;

    ConversationBrowser(Activity a, File db){
        activity=a;database=db;
        screen=new LinearLayout(a);screen.setOrientation(LinearLayout.VERTICAL);screen.setPadding(18,18,18,24);
        scroll=new ScrollView(a);scroll.setFillViewport(true);scroll.addView(screen);
    }

    void show(){loadChats(0);}
    private TextView label(String content, int size){TextView t=new TextView(activity);t.setText(content);t.setTextSize(size);t.setPadding(5,12,5,12);return t;}
    private Button button(String s, Runnable callback){Button b=new Button(activity);b.setText(s);b.setOnClickListener(v->callback.run());return b;}
    private void showScreen(String title){
        screen.removeAllViews();
        // Reuse the existing ScrollView. Reparenting screen to a new ScrollView
        // after an asynchronous query caused IllegalStateException and a crash.
        if(scroll.getParent()==null)activity.setContentView(scroll);
        scroll.scrollTo(0,0);
        TextView heading=label(title,22);heading.setTextColor(0xff075e54);screen.addView(heading);
        screen.addView(label("Local, read-only preview. Nothing is imported into Tangled or exported from this phone.",12));
    }
    private static final class ChatRow {
        long id, latest, count;String name;
        ChatRow(long id,long latest,long count,String name){this.id=id;this.latest=latest;this.count=count;this.name=name;}
    }
    private void loadChats(int offset) {
        if(busy)return;
        chatOffset=offset;showScreen("WhatsApp conversations");
        screen.addView(label("Sorted by latest stored message • tap one to reconstruct it",14));
        if(offset>0)screen.addView(button("← Previous chats",()->loadChats(Math.max(0,chatOffset-50))));
        screen.addView(label("Loading conversations…",14));
        busy=true;
        new Thread(()->{
            ArrayList<ChatRow> list=new ArrayList<>();String error=null;
            try(SQLiteDatabase db=SQLiteDatabase.openDatabase(database.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY)){
                // Page chats before counting their messages. chat.sort_timestamp is the fallback
                // when the cached last_message_row_id is null (including older archived chats).
                String sql="SELECT z._id,z.title,z.last_ms,(SELECT COUNT(*) FROM message n WHERE n.chat_row_id=z._id) AS n FROM (" +
                    "SELECT c._id AS _id,COALESCE(NULLIF(c.subject,''),NULLIF(j.user,''),NULLIF(j.raw_string,''),'Chat '||c._id) AS title, " +
                    "COALESCE(m.timestamp,c.sort_timestamp,0) AS last_ms " +
                    "FROM chat c LEFT JOIN jid j ON j._id=c.jid_row_id LEFT JOIN message m ON m._id=c.last_message_row_id " +
                    "ORDER BY last_ms DESC,c._id DESC LIMIT 50 OFFSET ?) z ORDER BY z.last_ms DESC,z._id DESC";
                try(Cursor c=db.rawQuery(sql,new String[]{String.valueOf(offset)})){
                    while(c.moveToNext())list.add(new ChatRow(c.getLong(0),c.getLong(2),c.getLong(3),c.getString(1)));
                }
            }catch(Exception ex){error=ex.getClass().getSimpleName()+": "+ex.getMessage();}
            final String err=error;
            activity.runOnUiThread(()->{
                busy=false;
                showScreen("WhatsApp conversations");
                screen.addView(label("Latest message first • "+(offset+1)+"–"+(offset+list.size()),13));
                if(err!=null){screen.addView(label("Unable to list conversations: "+err,15));return;}
                if(offset>0)screen.addView(button("← Previous 50",()->loadChats(Math.max(0,chatOffset-50))));
                for(ChatRow row:list){
                    String date=row.latest>0?dateFormat.format(new Date(row.latest)):"No messages";
                    screen.addView(button(row.name+"\n"+date+" · "+row.count+" messages",()->openChat(row.id,row.name)));
                }
                if(list.size()==50)screen.addView(button("Next 50 conversations →",()->loadChats(chatOffset+50)));
            });
        }).start();
    }
    private void openChat(long chatId,String title){selectedChat=chatId;selectedTitle=title;beforeTimestamp=Long.MAX_VALUE;beforeRow=Long.MAX_VALUE;loadMessages();}
    private static class MessageRow {
        long row,ms;String text,quote,quoteKey;boolean self,quoteLinked;ArrayList<String> reactions=new ArrayList<>();
    }
    private static String trimmed(String s,int limit){if(s==null||s.trim().isEmpty())return "[media / non-text message]";return s.length()>limit?s.substring(0,limit)+"…":s;}
    private void loadMessages(){
        if(busy)return;
        showScreen(selectedTitle);
        screen.addView(button("← All conversations",()->loadChats(chatOffset)));
        screen.addView(label("Reconstructing messages, quotes and reactions…",14));
        final long chatId=selectedChat,stamp=beforeTimestamp,rowId=beforeRow;
        busy=true;
        new Thread(()->{
            ArrayList<MessageRow> list=new ArrayList<>();String error=null;
            try(SQLiteDatabase db=SQLiteDatabase.openDatabase(database.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY)) {
                String sql="SELECT m._id,m.timestamp,m.text_data,m.from_me,m.key_id " +
                    "FROM message m WHERE m.chat_row_id=? AND (m.timestamp < ? OR (m.timestamp=? AND m._id<?)) " +
                    "ORDER BY m.timestamp DESC,m._id DESC LIMIT "+PAGE;
                try(Cursor c=db.rawQuery(sql,new String[]{""+chatId,""+stamp,""+stamp,""+rowId})){
                    while(c.moveToNext()){
                        MessageRow msg=new MessageRow();msg.row=c.getLong(0);msg.ms=c.getLong(1);msg.text=c.getString(2);msg.self=c.getInt(3)!=0;
                        list.add(msg);
                    }
                }
                // Each preview page makes bounded, read-only lookups. No N x full-table scans.
                for(MessageRow msg:list){
                    try(Cursor q=db.rawQuery("SELECT q.key_id,q.text_data,q.timestamp,q.from_me FROM message_quoted q WHERE q.message_row_id=? LIMIT 1",new String[]{""+msg.row})) {
                        if(q.moveToFirst()){
                            msg.quoteKey=q.getString(0);
                            msg.quote=trimmed(q.getString(1),190);
                            if(msg.quoteKey!=null){
                                try(Cursor original=db.rawQuery("SELECT _id FROM message WHERE chat_row_id=? AND key_id=? AND from_me=? LIMIT 1",new String[]{""+chatId,msg.quoteKey,""+q.getInt(3)})){
                                    msg.quoteLinked=original.moveToFirst();
                                }
                            }
                        }
                    }
                    try(Cursor r=db.rawQuery("SELECT r.reaction,a.from_me,COALESCE(j.user,j.raw_string,'Other') " +
                        "FROM message_add_on a JOIN message_add_on_reaction r ON r.message_add_on_row_id=a._id " +
                        "LEFT JOIN jid j ON j._id=a.sender_jid_row_id WHERE a.parent_message_row_id=? ORDER BY a.timestamp",new String[]{""+msg.row})){
                        while(r.moveToNext()){
                            String emoji=r.getString(0);
                            msg.reactions.add((emoji==null?"[removed]":emoji)+" · "+(r.getInt(1)!=0?"You":"Other"));
                        }
                    }
                }
            }catch(Exception ex){error=ex.getClass().getSimpleName()+": "+ex.getMessage();}
            final String err=error;
            activity.runOnUiThread(()->{
                busy=false;showScreen(selectedTitle);
                screen.addView(button("← All conversations",()->loadChats(chatOffset)));
                if(err!=null){screen.addView(label("Could not reconstruct this chat: "+err,15));return;}
                int quotes=0,linked=0,reactions=0;
                for(MessageRow msg:list){if(msg.quote!=null){quotes++;if(msg.quoteLinked)linked++;}reactions+=msg.reactions.size();}
                screen.addView(label("This page: "+list.size()+" messages · "+quotes+" quoted replies ("+linked+" originals linked by ID) · "+reactions+" reactions",14));
                screen.addView(label("Newest → oldest. Use 'Older messages' to continue backwards.",12));
                for(MessageRow msg:list){
                    LinearLayout cell=new LinearLayout(activity);cell.setOrientation(LinearLayout.VERTICAL);cell.setPadding(12,9,12,11);
                    cell.setBackgroundColor(msg.self?0xffe3f4ed:0xfff1f1f1);
                    screen.addView(cell);
                    TextView meta=label((msg.self?"You":"Other")+" · "+dateFormat.format(new Date(msg.ms)),12);meta.setTextColor(0xff555555);cell.addView(meta);
                    cell.addView(label(trimmed(msg.text,2000),15));
                    if(msg.quote!=null){TextView quote=label("↳ QUOTE "+(msg.quoteLinked?"(original ID found)":"(original not resolved)")+": "+msg.quote,13);quote.setTextColor(0xff075e54);cell.addView(quote);}
                    if(!msg.reactions.isEmpty())cell.addView(label("Reactions: "+android.text.TextUtils.join("  ",msg.reactions),13));
                    View gap=new View(activity);gap.setMinimumHeight(6);screen.addView(gap);
                }
                if(!list.isEmpty() && list.size()==PAGE){
                    MessageRow oldest=list.get(list.size()-1);
                    screen.addView(button("Older messages →",()->{beforeTimestamp=oldest.ms;beforeRow=oldest.row;loadMessages();}));
                }else screen.addView(label("Beginning of conversation reached",13));
            });
        }).start();
    }
}
