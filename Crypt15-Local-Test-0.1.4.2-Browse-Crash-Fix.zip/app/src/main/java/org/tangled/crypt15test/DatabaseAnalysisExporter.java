package org.tangled.crypt15test;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Offline, privacy-preserving structural analysis: absolutely no user-row values. */
public final class DatabaseAnalysisExporter {
    private DatabaseAnalysisExporter() {}

    private static String quote(String name) { return "\"" + name.replace("\"", "\"\"") + "\""; }

    private static boolean countTable(String name) {
        String s=name.toLowerCase(Locale.ROOT);
        return s.equals("message") || s.equals("chat") || s.equals("jid") ||
                s.contains("reaction") || s.contains("quoted") || s.contains("quote") ||
                s.contains("message_add_on") || s.contains("message_media") ||
                s.contains("message_text") || s.contains("message_quoted") || s.contains("receipt");
    }

    public static void export(File database, File output) throws Exception {
        if(!database.isFile())throw new IOException("Decrypted database missing");
        if(output.exists() && !output.delete())throw new IOException("Cannot replace existing analysis");
        JSONObject root=new JSONObject();
        root.put("format","tangled-crypt15-schema-analysis-v1");
        root.put("privacy","Schema and aggregate row counts only. No row values, message contents, phone numbers, keys, or individual identifiers.");
        root.put("database_size_bytes",database.length());
        JSONArray tables=new JSONArray();
        SQLiteDatabase db=SQLiteDatabase.openDatabase(database.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY);
        try {
            try(Cursor all=db.rawQuery("SELECT name, type FROM sqlite_master WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%' ORDER BY name",null)) {
                while(all.moveToNext()) {
                    String name=all.getString(0), type=all.getString(1);
                    JSONObject item=new JSONObject();item.put("name",name);item.put("type",type);
                    // Counts are for named technical tables only, never group-level personal metadata.
                    if("table".equals(type) && countTable(name)) {
                        try(Cursor c=db.rawQuery("SELECT COUNT(*) FROM "+quote(name),null)){
                            if(c.moveToFirst())item.put("row_count",c.getLong(0));
                        } catch(Exception ignored){item.put("row_count_error","count unavailable");}
                    }
                    JSONArray cols=new JSONArray();
                    try(Cursor c=db.rawQuery("PRAGMA table_info("+quote(name)+")",null)){
                        while(c.moveToNext()){
                            JSONObject col=new JSONObject();
                            col.put("name",c.getString(c.getColumnIndexOrThrow("name")));
                            col.put("type",c.getString(c.getColumnIndexOrThrow("type")));
                            col.put("not_null",c.getInt(c.getColumnIndexOrThrow("notnull"))!=0);
                            col.put("primary_key_position",c.getInt(c.getColumnIndexOrThrow("pk")));
                            cols.put(col);
                        }
                    }
                    item.put("columns",cols);
                    JSONArray foreignKeys=new JSONArray();
                    try(Cursor c=db.rawQuery("PRAGMA foreign_key_list("+quote(name)+")",null)){
                        while(c.moveToNext()){
                            JSONObject fk=new JSONObject();
                            fk.put("from",c.getString(c.getColumnIndexOrThrow("from")));
                            fk.put("to_table",c.getString(c.getColumnIndexOrThrow("table")));
                            fk.put("to_column",c.getString(c.getColumnIndexOrThrow("to")));
                            foreignKeys.put(fk);
                        }
                    }
                    item.put("foreign_keys",foreignKeys);
                    tables.put(item);
                }
            }
        } finally {db.close();}
        root.put("tables",tables);
        String readme="CRYPT15 DATABASE ANALYSIS\n\nThis ZIP contains only technical schema metadata "+
                "(table/column names, data types, foreign-key relationships) and aggregate row counts "+
                "for selected tables. It does NOT contain messages, phone numbers, contacts, chat titles, "+
                "individual message or reaction records, identifiers, the encryption key or the database itself.\n\n"+
                "File: schema-and-counts.json\n"+
                "The aim is to discover how WhatsApp stores quotes and reactions before developing a targeted importer.\n";
        try(ZipOutputStream zip=new ZipOutputStream(new FileOutputStream(output))) {
            zip.putNextEntry(new ZipEntry("README.txt"));
            zip.write(readme.getBytes(StandardCharsets.UTF_8));zip.closeEntry();
            zip.putNextEntry(new ZipEntry("schema-and-counts.json"));
            zip.write(root.toString(2).getBytes(StandardCharsets.UTF_8));zip.closeEntry();
        }
    }
}
