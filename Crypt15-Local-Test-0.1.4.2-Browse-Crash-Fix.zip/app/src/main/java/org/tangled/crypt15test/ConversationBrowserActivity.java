package org.tangled.crypt15test;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import java.io.File;

/** Separate read-only screen; Android Back returns to the decryption tester. */
public final class ConversationBrowserActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        String path=getIntent().getStringExtra("db_path");
        File file=path==null?null:new File(path);
        if(file==null||!file.isFile()||!file.getAbsolutePath().startsWith(getCacheDir().getAbsolutePath()+File.separator)){
            TextView text=new TextView(this);text.setText("Decrypted backup is no longer available. Return to the tester and decrypt it again.");setContentView(text);return;
        }
        new ConversationBrowser(this,file).show();
    }
}
