package org.tangled.crypt15test;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int PICK = 10, SAVE = 11, SAVE_ANALYSIS = 12;
    private Uri selected;
    private TextView selectedLabel, report;
    private EditText keyEntry;
    private Button decryptButton, exportButton, analysisButton;
    private File resultFile, analysisFile;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private boolean busy;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setPadding(dp(20),dp(18),dp(20),dp(18));
        ScrollView scroll = new ScrollView(this);
        scroll.addView(screen);
        setContentView(scroll);
        TextView heading = new TextView(this); heading.setText("Crypt15 Local Test v0.1.2"); heading.setTextSize(26); heading.setTextColor(0xff075e54);
        screen.addView(heading);
        TextView intro = new TextView(this);
        intro.setText("Standalone proof of concept for Tangled. Decrypts your WhatsApp backup locally, authenticates it and checks the database schema. No internet permission. Your WhatsApp data is never modified.");
        intro.setTextSize(15); intro.setPadding(0,dp(10),0,dp(16)); screen.addView(intro);
        Button picker = new Button(this); picker.setText("1. Select .crypt15 backup");screen.addView(picker);
        picker.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.setType("*/*"); intent.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(intent, PICK);
        });
        selectedLabel = new TextView(this); selectedLabel.setText("No backup selected");selectedLabel.setPadding(0,dp(6),0,dp(16));screen.addView(selectedLabel);
        Button diagnostic = new Button(this); diagnostic.setText("Inspect backup header (no key needed)"); screen.addView(diagnostic);
        diagnostic.setOnClickListener(v -> inspect());
        TextView label = new TextView(this);label.setText("2. Enter your 64-character backup key (kept only in memory)");screen.addView(label);
        keyEntry = new EditText(this);keyEntry.setSingleLine(true);
        keyEntry.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        keyEntry.setHint("64-character hexadecimal key");screen.addView(keyEntry);
        CheckBox show = new CheckBox(this);show.setText("Show key while typing");screen.addView(show);
        show.setOnCheckedChangeListener((button, checked) -> {
            int selection = keyEntry.getSelectionStart();
            keyEntry.setInputType(InputType.TYPE_CLASS_TEXT | (checked ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD));
            keyEntry.setSelection(Math.max(0, Math.min(selection,keyEntry.length())));
        });
        decryptButton = new Button(this);decryptButton.setText("3. Decrypt and inspect locally");screen.addView(decryptButton);
        decryptButton.setOnClickListener(v -> decrypt());
        exportButton = new Button(this);exportButton.setText("Export decrypted database (optional)"); exportButton.setEnabled(false);screen.addView(exportButton);
        exportButton.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.setType("application/octet-stream"); intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.putExtra(Intent.EXTRA_TITLE, resultFile != null && resultFile.getName().endsWith(".zip") ? "decrypted-backup.zip" : "msgstore.db");
            startActivityForResult(intent, SAVE);
        });
        analysisButton = new Button(this);
        analysisButton.setText("Export database analysis (small ZIP)");
        analysisButton.setEnabled(false);
        screen.addView(analysisButton);
        analysisButton.setOnClickListener(v -> exportAnalysis());
        TextView analysisNote = new TextView(this);
        analysisNote.setText("The analysis ZIP contains table and column names, relationships and selected row counts ONLY. No message text, phone numbers, contacts, identifiers, encryption key or individual records are included. Check its contents before sharing.");
        analysisNote.setPadding(0,dp(5),0,dp(10));screen.addView(analysisNote);
        TextView warn = new TextView(this);
        warn.setText("PRIVACY: The decrypted database contains private messages. Export only if you understand the risk. Decrypted temporary files are cleared when testing again or when the app is next opened. Do not share your backup key.");
        warn.setPadding(0,dp(12),0,dp(12));screen.addView(warn);
        report = new TextView(this); report.setTextIsSelectable(true); report.setText("Ready to select a file.");screen.addView(report);
        clearOldTemporaryFiles();
    }
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private void update(String message){runOnUiThread(()->report.setText(message));}
    private void inspect() {
        if (busy || selected == null) { if (selected == null) update("Select the backup first."); return; }
        busy=true; decryptButton.setEnabled(false);
        update("Inspecting header locally…");
        worker.execute(() -> {
            File input = new File(getCacheDir(),"header-inspection.crypt15");
            try {
                try (InputStream in = getContentResolver().openInputStream(selected);
                     OutputStream out = new BufferedOutputStream(new FileOutputStream(input))) {
                    if (in == null) throw new IOException("Cannot read selected file.");
                    byte[] bytes = new byte[65536]; int n;
                    while ((n = in.read(bytes)) != -1) out.write(bytes, 0, n);
                }
                update(Crypt15Engine.inspectHeader(input));
            } catch (Exception ex) { update("Header inspection failed: " + ex.getMessage()); }
            finally { input.delete(); runOnUiThread(() -> { busy=false; decryptButton.setEnabled(true); }); }
        });
    }
    private void decrypt() {
        if(busy || selected==null){if(selected==null)update("Please select the .crypt15 file first.");return;}
        String key=keyEntry.getText().toString();
        if(!key.replaceAll("\\s","").matches("(?i)[0-9a-f]{64}")){update("The key must be exactly 64 hexadecimal characters.");return;}
        keyEntry.getText().clear(); // Do not leave the key visible on screen after starting.
        busy=true;decryptButton.setEnabled(false);exportButton.setEnabled(false);analysisButton.setEnabled(false);
        update("Reading backup…");
        worker.execute(()->{
            File input = new File(getCacheDir(),"selected-backup.crypt15");
            File output = new File(getCacheDir(),"decrypted-output.db");
            try {
                resultFile=null; analysisFile=null;
                new File(getCacheDir(),"database-analysis.zip").delete();
                if(output.exists()) output.delete();
                try(InputStream in=getContentResolver().openInputStream(selected);OutputStream out=new BufferedOutputStream(new FileOutputStream(input))){
                    if(in==null)throw new IOException("Unable to read selected file.");
                    byte[] bytes=new byte[65536];int n;
                    while((n=in.read(bytes))!=-1)out.write(bytes,0,n);
                }
                Crypt15Engine.Result r=Crypt15Engine.decrypt(input,output,key,this::update);
                keyEntry.post(()-> keyEntry.getText().clear());
                StringBuilder details = new StringBuilder("SUCCESS: Backup authenticated and decrypted locally.\n");
                details.append("Decrypted size: ").append(r.bytes).append(" bytes\n");
                if(r.sqlite) {
                    details.append("Format: SQLite database\n\nRelevant database tables:\n");
                    SQLiteDatabase db=SQLiteDatabase.openDatabase(output.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY);
                    try(Cursor tables=db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name",null)){
                        int match=0;
                        while(tables.moveToNext()){
                            String name=tables.getString(0);
                            String lower=name.toLowerCase(Locale.ROOT);
                            if(lower.contains("message")||lower.contains("quote")||lower.contains("reaction")||lower.contains("chat")) {
                                match++;
                                if(match<=60){
                                    details.append(" • ").append(name);
                                    try (Cursor count=db.rawQuery("SELECT COUNT(*) FROM \""+name.replace("\"","\"\"")+"\"",null)){
                                        if(count.moveToFirst())details.append(" (rows: ").append(count.getLong(0)).append(")");
                                    }catch(Exception ignored){details.append(" (count unavailable)");}
                                    details.append("\n");
                                }
                            }
                        }
                        details.append("\nMatching tables: ").append(match).append("\n");
                    } finally {db.close();}
                    details.append("\nThis is schema discovery only. It does not yet extract or link reaction and quote records.\n");
                }else {
                    File zipFile=new File(getCacheDir(),"decrypted-output.zip");
                    if(!output.renameTo(zipFile))throw new IOException("Cannot rename ZIP output.");
                    output=zipFile;
                    details.append("Format: ZIP container. Database may be inside; inspection is not implemented for this variant.\n");
                }
                resultFile=output;
                final String finish=details.toString();
                runOnUiThread(()->{report.setText(finish);exportButton.setEnabled(true);analysisButton.setEnabled(r.sqlite);});
            }catch(Exception ex){
                if(output.exists())output.delete();
                update("FAILED: " + ex.getClass().getSimpleName() + " — " + ex.getMessage() + "\n\nNo decrypted file has been exported.");
            }finally{
                input.delete();
                runOnUiThread(()->{busy=false;decryptButton.setEnabled(true);});
            }
        });
    }
    private void exportAnalysis() {
        if (busy || resultFile==null || !resultFile.isFile() || !resultFile.getName().endsWith(".db")) {
            update("Decrypt a SQLite backup before exporting its analysis.");return;
        }
        busy=true; analysisButton.setEnabled(false);decryptButton.setEnabled(false);
        update("Analysing local SQLite schema and aggregate row counts…");
        worker.execute(()->{
            try {
                File target=new File(getCacheDir(),"database-analysis.zip");
                DatabaseAnalysisExporter.export(resultFile,target);
                analysisFile=target;
                runOnUiThread(()->{
                    busy=false; analysisButton.setEnabled(true);decryptButton.setEnabled(true);
                    report.setText("Analysis prepared locally ("+target.length()+" bytes).\nOnly schema and aggregate counts; no chat content. Choose where to save the ZIP.");
                    Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.setType("application/zip");intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.putExtra(Intent.EXTRA_TITLE,"crypt15-database-analysis.zip");
                    startActivityForResult(intent,SAVE_ANALYSIS);
                });
            } catch(Exception ex) {
                runOnUiThread(()->{busy=false;analysisButton.setEnabled(true);decryptButton.setEnabled(true);});
                update("Database analysis failed: "+ex.getClass().getSimpleName()+" — "+ex.getMessage());
            }
        });
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null)return;
        if(request==PICK){selected=data.getData();selectedLabel.setText("Selected: " + selected.getLastPathSegment());report.setText("Backup selected. Enter key and decrypt.");}
        else if(request==SAVE_ANALYSIS){
            final File file=analysisFile;
            if(file==null || !file.isFile()){update("Analysis has not been created.");return;}
            worker.execute(()->{
                try(InputStream in=new BufferedInputStream(new FileInputStream(file));
                    OutputStream out=getContentResolver().openOutputStream(data.getData(),"w")){
                    if(out==null)throw new IOException("Cannot open analysis destination.");
                    byte[] buf=new byte[32768]; int n;
                    while((n=in.read(buf))!=-1)out.write(buf,0,n);
                    update("Analysis ZIP saved. It contains schema and counts, not messages. You can upload that file here.");
                }catch(Exception ex){update("Analysis export failed: "+ex.getMessage());}
            });
        }
        else if(request==SAVE){
            Uri target=data.getData();File file=resultFile;
            if(file==null||!file.exists()){update("No verified decrypted database to export.");return;}
            worker.execute(()->{
                try(InputStream in=new BufferedInputStream(new FileInputStream(file));OutputStream out=getContentResolver().openOutputStream(target,"w")){
                    if(out==null)throw new IOException("Unable to open destination.");
                    byte[] bytes=new byte[65536];int n;
                    while((n=in.read(bytes))!=-1)out.write(bytes,0,n);
                    update("Export complete. The decrypted database is sensitive; store it securely.");
                }catch(Exception ex){update("Export failed: "+ex.getMessage());}
            });
        }
    }
    private void clearOldTemporaryFiles(){
        new File(getCacheDir(),"selected-backup.crypt15").delete();
        new File(getCacheDir(),"header-inspection.crypt15").delete();
        new File(getCacheDir(),"decrypted-output.db").delete();
        new File(getCacheDir(),"decrypted-output.zip").delete();
        new File(getCacheDir(),"database-analysis.zip").delete();
    }
    @Override protected void onDestroy(){super.onDestroy();worker.shutdown();}
}
