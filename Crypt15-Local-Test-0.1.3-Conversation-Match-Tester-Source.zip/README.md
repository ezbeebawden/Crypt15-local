# Crypt15 Local Test v0.1.2 — database analysis export

This version adds **Export database analysis (small ZIP)** after successful decryption. The ZIP contains `schema-and-counts.json` (table and column names, declared types, foreign keys, and aggregate counts for relevant technical tables) and a README. It does **not** include message text, contact names, phone numbers, chat titles, any individual records or identifiers, nor the encryption key. It generates the ZIP entirely offline, using the decrypted SQLite file cached on device.

**Usage:** select `.crypt15`, enter the 64-character hexadecimal backup key locally, decrypt; then tap **Export database analysis (small ZIP)** and select a destination via Android's document picker. Only upload that small analysis ZIP for review. The full decrypted database export remains available but should never be shared casually.

**GitHub ZIP-based build:** Upload `Crypt15-Local-Test-0.1.2-Database-Analysis-Source.zip` and use the workflow from `.github/workflows/build-from-zip.yml` (copy its content to the repository's `.github/workflows/build-crypt15.yml`). This is still a proof-of-concept and has not been tested against all possible WhatsApp SQLite schemas. No internet permission and no modification of original backup.

# Crypt15 Local Test v0.1.1 — standalone Android proof of concept

**Purpose:** Test locally decrypting your own WhatsApp `.crypt15` backup with its 64-character hexadecimal key and determine whether the decrypted database contains message / quote / reaction tables. This does NOT connect to Tangled yet.

**Privacy:** No INTERNET permission. No analytics. User-selected backup is copied to app-private cache, the key is used in-memory and cleared from the UI, AES-GCM authentication is verified before output is accepted, and the SQLite database remains private unless you deliberately export it. All previous temp files are removed on opening the app. Be careful with exported decrypted databases; they contain private chat data.

**Supported:** Crypt15 backups whose protobuf header contains `BackupPrefix.e2ee_key_data.encryption_iv`; single-file database variant (ciphertext + 16-byte GCM tag + MD5) and multifile variant (ciphertext + 16-byte GCM tag). Payload may be zlib compressed SQLite or ZIP. ZIP is decrypted and can be exported but isn't yet inspected internally. This prototype has not been tested with the user's real backup or on a physical Android phone.

**Build:** This is an Android Studio / GitHub Actions Gradle project using Android Gradle Plugin 8.7.3, Java 17, compile SDK 35. No third-party runtime dependencies. GitHub Action `.github/workflows/build-apk.yml` builds a debug APK and publishes it as a workflow artifact.

**Use:** Select `.crypt15` using the Android picker → enter 64-character key → Decrypt and inspect locally → check reported tables / counts. If successful, selectively export `msgstore.db` for offline use; do not upload your key, database, or plaintext reports.

**Implementation references:** ElDavoo/wa-crypt-tools, especially `src/wa_crypt_tools/lib/db/db15.py`, `src/wa_crypt_tools/lib/key/key15.py`, `src/wa_crypt_tools/lib/utils.py`, and the `proto/backup_prefix.proto`, `proto/C15_IV.proto` definitions: https://github.com/ElDavoo/wa-crypt-tools . This is an independent Java implementation of the specified AES-GCM format.

**Limits:** No extraction of actual quoted/reaction message pairs yet. Potential provider-specific large-file performance/memory constraints. No proper secure key memory wiping (Java strings cannot reliably be wiped). Files temporarily occupy internal storage; ensure enough space. Do not uninstall/alter WhatsApp or delete original backup. The first task is validating compatibility with a real file.

**If you prefer the ZIP-in-repository workflow familiar from Tangled:** Upload `Crypt15-Local-Test-0.1.0-Source.zip` to the root of a GitHub repository and add the workflow from `.github/workflows/build-from-zip.yml` to that repository's workflow directory. It unpacks the ZIP during GitHub Actions and builds the APK. Do not accidentally run both workflows in the same repo unless you want two builds.

## v0.1.1 update
The **Inspect backup header (no key needed)** action reports the file size, protobuf header length and parsing status without showing the secret key or decrypting message content. The reader now supports deprecated protobuf group fields and identifies parsing errors more specifically. This is a diagnostic update; success on actual WhatsApp backup is not yet verified.


## v0.1.3: Conversation Match Tester

After decrypting your backup, select a standard exported WhatsApp conversation ZIP and tap **Match messages, quotes and reactions**. This read-only proof of concept parses timestamped chat.txt, discovers the likely SQLite chat by matching a spaced sample of messages, uniquely matches text plus timestamps, and counts quote and reaction links using message_quoted and message_add_on_reaction. No message contents, database keys or contact identifiers are exported, and the full decrypted database stays in the app cache until app restart. Conversation matching uses the phone's timezone; the tool supports WhatsApp Web US-style 12-hour timestamps and Android day-first timestamps. Date/time resolution, attachments, edited messages, and chat identity differences can reduce matches. The on-screen results are aggregates only; this version does not import anything into Tangled.

Caution: exact match counts are conservative. An unmatched message is not proof that it is absent from the backup. If automatic conversation identification is ambiguous the test refuses to guess.
