# Chat Archive for Android

A small native Android app for **cumulatively archiving exported WhatsApp conversations**. It operates entirely offline and stores messages in an SQLite database in Android's app-private storage. No account, Internet permission, analytics, or server.

## Build and install

1. Install current Android Studio (with Android SDK Platform 35, JDK 17+, and the Android Gradle Plugin dependencies).
2. Open this folder as a project in Android Studio.
3. Let Gradle sync. The wrapper is not bundled, so use Android Studio's Gradle tooling (or install Gradle 8.9 separately).
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Install the resulting `app/build/outputs/apk/debug/app-debug.apk` on your Android phone (allow installs from your chosen source).

This source project has **not been compiled or tested on a device** in this environment because the Android SDK/Gradle tooling is unavailable here. Review and test it with nonessential sample data before relying on it.

## Use

1. In WhatsApp, open the conversation → More → Export chat → choose without media (`.txt`) or include media (`.zip`). Save the export to Files.
2. Open Chat Archive → **Import chat** → select `.txt` or `.zip`. Enter an archive name such as `Friend A`.
3. Open the chat to review timestamps, message order, and images from the ZIP, if any. Choose **Set my sender name** for green bubbles.
4. Use **Backup** to create a standalone `.zip` containing all conversations and saved media; **copy it to another device or storage location** and **verify it by restoring to a separate test installation** before deleting WhatsApp history.
5. Only after independently confirming your backup, delete/clear history in WhatsApp if desired.
6. Next time, export the more recent WhatsApp chat and import it using **exactly the same archive name**. Previously archived messages remain; new messages are inserted.

**Restore replaces all existing app data.** Back up the current archive before doing so. Android app-private storage is normally deleted when the app is uninstalled or its data is cleared. Android OS backup is intentionally disabled; the in-app Backup feature is the supported recovery method.

## Duplication and data limitations

- WhatsApp plain-text exports do not include stable unique message identifiers. The app hashes the timestamp, sender, body and occurrence count within a single export. It therefore removes most overlapping-export duplicates, but **cannot guarantee perfect deduplication**, particularly when two different messages have identical timestamp/sender/body and exports begin mid-sequence.
- Exports with ambiguous short dates are interpreted **day-first (UK format)**. The WhatsApp export includes no timezone; timestamps use the phone's current timezone during import. If you use month-first exports or travel across timezones, parsing should be adapted before importing.
- Tested formats were designed for conventional Android `dd/mm/yy, hh:mm - Name: Message` and iOS `[dd/mm/yyyy, hh:mm:ss] Name: Message` layouts, including multiline messages. Other locales, unusual Unicode separators, and some WhatsApp system events may not parse correctly.
- Plain `.txt` exports cannot contain actual images or voice notes. ZIP media files are saved where their filename is referenced in the message. Images are viewable; other media is preserved in backups but not playable in the v1 viewer.
- Media archives are subject to a 100 MB per-file / 500 MB overall extraction limit. Large exports require an enhanced streaming importer.
- No encryption-at-rest beyond Android's app sandbox/device encryption, no PIN/biometric lock, no automated scheduled backups. Protect your unlocked phone and backup ZIPs.
- There is no direct live WhatsApp integration and the app never modifies WhatsApp data.

## Structure

- `app/src/main/java/com/example/chatarchive/MainActivity.kt` — native interface and Android file picker
- `ArchiveIO.kt` — text/ZIP import, parsing and backup/restore
- `ArchiveDb.kt` — SQLite schema, cumulative insert and archive snapshot

## Privacy

The manifest requests no network or broad storage permissions. Files are accessed through Android's system file picker; the archive database and imported images are kept in app-private files. Exported backup ZIPs are unencrypted, so keep them somewhere secure.

## Version 1.2: edited messages and bubble layout
- Message-header recognition now tolerates WhatsApp's invisible directional marks and common nonbreaking spaces. Edited-message annotations remain within the message body instead of becoming separate entries. Exact exported formats vary; test against a non-sensitive sample before deleting source data.
- The two most frequent named senders are detected and one sender's bubbles automatically appear on the right. The **Choose right-side sender** button selects which sender is shown on the right; the choice is remembered by conversation. All other senders appear on the left.
- An already imported malformed message is not automatically repaired by changing the parser; re-importing the original export can add correctly parsed versions but might leave malformed entries, and edited text may have different deduplication hashes. Retain a backup and verify results.

## November 2026 date-format fix
The importer detects US month-first (MM/DD/YY) and UK day-first (DD/MM/YY) WhatsApp exports from unambiguous dates. Previously imported merged message bodies are not rewritten automatically. To preserve your existing archive, back it up, then import the original export under a **new conversation name** and check its message count and bubbles before deleting anything. The old conversation can be retained as an additional backup until reviewed.

Tangled update: Names & identities lets you set display aliases or manually match changed WhatsApp sender names. Original message senders remain unchanged, and identity mappings are stored in backups. Exact repeated messages and exports with ambiguous timestamps may still need manual checking.


## Tangled 3.0 experimental web reply scanning

The in-app WhatsApp Web exporter now offers separate **Resume unfinished historical scan** and **Scan only new messages** modes. A partial historical export stores an oldest-message resume point when the JSON is imported. The scanner must find the saved marker before collecting older history. Successful full historical completion enables incremental scans; incomplete exports cannot advance the new-message checkpoint. Both state values are included in archive backups. If WhatsApp Web cannot locate a checkpoint, do not claim completion; rescan/review as needed.

Original message matching searches backwards in increasing time windows and requires strong quoted-text similarity; generic partial word matches are rejected. The scanner still depends on WhatsApp Web's DOM and requires testing in Chrome on Android.

## v3.1 date-assisted historical replies

Removing **all reply links** also clears the two scanner checkpoints (individual link removals and clearing only uncertain/imported links do not). A fresh historical scan exports the newest ID, oldest ID and timestamp. Importing a partial fresh scan creates a historical resume marker. Tangled then shows the date **one calendar day after** the saved oldest timestamp, to select in WhatsApp Web **before** invoking the resume bookmarklet. The resume bookmarklet verifies the exact saved message ID before collecting older replies. If it cannot verify the ID, the exported JSON cannot advance the resume marker. Backups retain the timestamp alongside the marker; pre-v3.1 backups may have a marker without a date and need manual navigation or a reset. Scanner script tested for JavaScript syntax; actual browser UI compatibility still requires testing on Android Chrome.


## v3.4 scan screen
Simplified historical scan instructions: Chrome Incognito / Desktop site, 'No previous scan' or next-day suggested date, one permanent tested historical bookmarklet. New-message scanning intentionally deferred until validated. All reply links reset clears scan state.
