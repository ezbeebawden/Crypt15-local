plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.example.chatarchive"
    compileSdk = 35
    defaultConfig { applicationId = "com.example.chatarchive"; minSdk = 26; targetSdk = 34; versionCode = 112; versionName = "4.4.84" }
    signingConfigs {
        create("leafLocal") {
            storeFile = file("../leaf-debug.keystore")
            storePassword = "leaf-local-build"
            keyAlias = "leaf-debug"
            keyPassword = "leaf-local-build"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("leafLocal") }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
