package com.example.chatarchive

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.util.Log
import android.widget.Toast

/** Persistent user-added Quick Settings entry. No archive content is displayed. */
class TangledQuickTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        qsTile?.let { tile ->
            val prefs=getSharedPreferences("tangled_hidden_entry",MODE_PRIVATE)
            tile.label=if(prefs.getBoolean("tile_show_label",true)) prefs.getString("tile_label","Shortcuts")?:"Shortcuts" else " "
            val icons=intArrayOf(R.drawable.tangled_tile_medium,R.drawable.tile_grid,R.drawable.tile_sliders,R.drawable.tile_circle)
            val selected=prefs.getInt("tile_icon",0).coerceIn(0,3)
            val chosenIcon=if(selected==0) R.drawable.tangled_tile_large else icons[selected]
            tile.icon=android.graphics.drawable.Icon.createWithResource(this,chosenIcon)
            tile.state=Tile.STATE_ACTIVE
            tile.updateTile()
        }
    }
    override fun onClick() {
        super.onClick()
        try {
            // Debug visible to the user even if Android refuses the activity launch.
            Toast.makeText(applicationContext,"Opening Shortcuts",Toast.LENGTH_SHORT).show()
            val prefs=getSharedPreferences("tangled_hidden_entry",MODE_PRIVATE)
            prefs.edit().putLong("tile_pressed_at",SystemClock.elapsedRealtime()).apply()
            val intent=Intent(this,MainActivity::class.java).apply {
                action=Intent.ACTION_MAIN
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("tangled_from_tile",true)
            }
            if(Build.VERSION.SDK_INT>=34) {
                val pi=PendingIntent.getActivity(this,405,intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                startActivityAndCollapse(pi)
            }else {
                @Suppress("DEPRECATION")
                startActivityAndCollapse(intent)
            }
        }catch(e:Exception) {
            Log.e("TangledTile","Could not open Tangled",e)
            Toast.makeText(applicationContext,"Shortcuts could not open Tangled",Toast.LENGTH_LONG).show()
        }
    }
}
