package com.example.chatarchive

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

/** Private app-sandbox store for successfully imported source files.
 * Never deletes a source until a matching SHA-256 copy is fsynced and checked.
 * Only sources for completed auto-sync batches are passed to seal(). */
internal class SyncedVault(private val context:Context) {
    data class Item(val id:String,val name:String,val kind:String,val chatId:Long,val hash:String,val bytes:Long)
    private val directory=File(context.filesDir,"synced_source_vault").apply{mkdirs()}
    private val manifest=File(directory,"index.json")
    private val resolver get()=context.contentResolver
    private fun validId(id:String)=id.matches(Regex("[a-f0-9]{64}\\.(zip|json|txt)"))
    private fun digest(input:java.io.InputStream):String {
        val md=MessageDigest.getInstance("SHA-256")
        input.use { source ->
            val buf=ByteArray(65536)
            while(true){val n=source.read(buf);if(n<0)break;if(n>0)md.update(buf,0,n)}
        }
        return md.digest().joinToString(""){ "%02x".format(it.toInt() and 255) }
    }
    private fun records():JSONArray = if(manifest.exists())
        runCatching{JSONArray(manifest.readText())}.getOrElse{error("Vault index damaged: ${it.message}")}
        else JSONArray()
    @Synchronized fun list():List<Item> {
        val a=records();return (0 until a.length()).map { i ->
            val j=a.getJSONObject(i)
            Item(j.getString("id"),j.getString("name"),j.getString("kind"),j.getLong("chatId"),j.getString("hash"),j.getLong("bytes"))
        }
    }
    private fun put(items:List<Item>){
        val a=JSONArray();items.forEach{ x -> a.put(JSONObject().put("id",x.id).put("name",x.name).put("kind",x.kind).put("chatId",x.chatId).put("hash",x.hash).put("bytes",x.bytes)) }
        val tmp=File(directory,"index.tmp");tmp.writeText(a.toString())
        check(tmp.renameTo(manifest)){"Cannot update private vault index"}
    }
    @Synchronized fun seal(source:Uri,name:String,kind:String,chatId:Long,expectedHash:String):Boolean {
        require(kind=="chat" || kind=="quote" || kind=="web")
        require(name.endsWith(".zip",true)||name.endsWith(".txt",true)||name.endsWith(".json",true))
        require(expectedHash.matches(Regex("[a-f0-9]{64}")))
        // Do not take a public file merely because its filename resembles an import.
        val extension=name.substringAfterLast('.').lowercase()
        val id="$expectedHash.$extension"
        check(validId(id)) { "Unsupported vault entry" }
        val dest=File(directory,id)
        val old=list()
        if(!dest.exists()) {
            val tmp=File(directory,"$id.tmp")
            try {
                resolver.openInputStream(source)?.use{input->
                    tmp.outputStream().use{out->input.copyTo(out,65536);out.fd.sync()}
                }?:error("Cannot read source for private archiving")
                require(digest(tmp.inputStream())==expectedHash){"Private copy checksum mismatch"}
                check(tmp.renameTo(dest)){"Cannot complete private archiving"}
            } finally {tmp.delete()}
        } else require(digest(dest.inputStream())==expectedHash){"Stored private file checksum mismatch"}
        if(old.none{it.id==id})put(old+Item(id,name,kind,chatId,expectedHash,dest.length()))
        // If deletion fails, the private copy remains, but the app reports the
        // public copy rather than falsely claiming it is hidden.
        val removed=DocumentsContract.deleteDocument(resolver,source)
        check(removed){"Private copy verified, but Android refused to remove the public original"}
        return true
    }
    /** Ingest public files before any sync, including previously archived files.
     * Private copy is checksum-verified and fsynced before public deletion.
     * The retained source is never removed on import/match failure. */
    @Synchronized fun ingest(source:Uri,name:String,kind:String):Item {
        require(kind=="chat" || kind=="quote" || kind=="web")
        require(name.endsWith(".zip",true)||name.endsWith(".txt",true)||name.endsWith(".json",true))
        val extension=name.substringAfterLast('.').lowercase()
        val staging=File(directory,"incoming_${System.nanoTime()}.tmp")
        try {
            resolver.openInputStream(source)?.use{input->
                staging.outputStream().use{out->input.copyTo(out,65536);out.fd.sync()}
            }?:error("Cannot read incoming source")
            val hash=digest(staging.inputStream())
            val id="$hash.$extension"
            check(validId(id)) {"Unsupported private file"}
            val existing=list().firstOrNull{it.id==id}
            val dest=File(directory,id)
            if(!dest.exists()) {
                check(staging.renameTo(dest)) {"Unable to secure source in private vault"}
            } else require(digest(dest.inputStream())==hash) {"Private source checksum mismatch"}
            val item=existing?:Item(id,name,kind,-1L,hash,dest.length())
            if(existing==null)put(list()+item)
            // Import is deliberately performed later from the *private* file.
            check(DocumentsContract.deleteDocument(resolver,source)) {
                "File copied privately but Android refused to remove public original"
            }
            return item
        }finally{staging.delete()}
    }
    /** Store a generated merged ZIP directly in the private vault, without public staging. */
    @Synchronized fun addGenerated(source:File,name:String,kind:String,chatId:Long):Item {
        require(kind=="chat" && name.endsWith(".zip",true))
        val hash=digest(source.inputStream())
        val id="$hash.zip"
        val target=File(directory,id)
        if(!target.exists()) {
            val tmp=File(directory,"generated_${System.nanoTime()}.tmp")
            try {
                source.inputStream().use{input->tmp.outputStream().use{out->input.copyTo(out,65536);out.fd.sync()}}
                require(digest(tmp.inputStream())==hash){"Generated ZIP checksum mismatch"}
                check(tmp.renameTo(target)){"Cannot secure generated ZIP"}
            }finally{tmp.delete()}
        }else require(digest(target.inputStream())==hash){"Existing generated source is corrupt"}
        val previous=list().firstOrNull{it.id==id}
        val item=previous?:Item(id,name,kind,chatId,hash,target.length())
        if(previous==null)put(list()+item)
        return item
    }
    fun uri(item:Item):Uri {
        require(list().any{it.id==item.id}) {"Unknown vault source"}
        val file=File(directory,item.id)
        require(file.isFile) {"Missing private source: ${item.name}"}
        return Uri.fromFile(file)
    }
    fun export(item:Item,to:Uri){
        require(list().any{it.id==item.id}){"Unknown private source"}
        val source=File(directory,item.id)
        require(digest(source.inputStream())==item.hash){"Private source checksum mismatch"}
        resolver.openOutputStream(to,"wt")?.use{output->source.inputStream().use{it.copyTo(output)}}
            ?:error("Cannot write exported file")
        require(resolver.openInputStream(to)?.use{digest(it)}==item.hash){"Exported file verification failed; private original retained"}
    }
    @Synchronized fun setChat(item:Item,chatId:Long){
        val all=list();require(all.any{it.id==item.id}){"Unknown private source"}
        put(all.map { if(it.id==item.id)it.copy(chatId=chatId) else it })
    }
    @Synchronized fun remove(item:Item){
        val all=list();require(all.any{it.id==item.id})
        require(File(directory,item.id).delete()){"Cannot delete private source"}
        put(all.filterNot{it.id==item.id})
    }
    // Backup exports the complete private vault including the index; restore
    // validates every entry before changing the current vault.
    fun backupFiles():List<File> = listOf(manifest).filter{it.isFile}+list().map{File(directory,it.id)}.onEach{require(it.isFile){"Missing private source ${it.name}"}}
    fun restoreFrom(staged:File){
        val index=File(staged,"index.json")
        val text=if(index.exists())index.readText() else "[]"
        val entries=JSONArray(text)
        val known=HashSet<String>()
        for(i in 0 until entries.length()){
            val e=entries.getJSONObject(i)
            val id=e.getString("id");val hash=e.getString("hash")
            require(validId(id)&&known.add(id)&&id.startsWith("$hash.")){"Invalid private source record"}
            val file=File(staged,id)
            require(file.isFile && digest(file.inputStream())==hash){"Private source verification failed: $id"}
        }
        // Stage all checked records before replacing the existing files.
        val replace=File(context.filesDir,"vault_restore_${System.nanoTime()}").apply{mkdirs()}
        try {
            staged.listFiles()?.forEach{it.copyTo(File(replace,it.name),overwrite=true)}
            if(!index.exists())File(replace,"index.json").writeText("[]")
            val previous=File(context.filesDir,"vault_previous_${System.nanoTime()}")
            check(directory.renameTo(previous)){"Cannot stage old private vault"}
            if(!replace.renameTo(directory)){
                previous.renameTo(directory)
                error("Cannot restore private vault")
            }
            previous.deleteRecursively()
        }finally{replace.deleteRecursively()}
    }
}
