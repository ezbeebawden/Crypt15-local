package com.example.chatarchive

import android.content.Context
import android.net.Uri
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.zip.ZipInputStream

/** Companion evidence, not a second message archive. Source ZIPs remain in Private Files. */
internal class WebExportImporter(private val context:Context,private val db:ArchiveDb) {
    data class Result(val seconds:Int,val added:Int,val verified:Int,val corrected:Int,val conflicts:Int,val pending:Int)
    internal data class Progress(val stage:String,val done:Int,val total:Int)
    private data class MdReply(val time:Long,val sender:String,val body:String,val quotedSender:String,val quotedText:String)
    companion object {
        // Require BOTH formats. Android conversation ZIPs contain a .txt and media,
        // but do not normally contain chat.md.
        fun isWebZip(context:Context,uri:Uri):Boolean = runCatching {
            var txt=false;var md=false;var entries=0
            ZipInputStream(context.contentResolver.openInputStream(uri)?:error("ZIP missing")).use{zip->
                while(true){val e=zip.nextEntry?:break;entries++;if(entries>10000)break
                    val name=e.name.substringAfterLast('/').lowercase(Locale.ROOT)
                    if(!e.isDirectory && name.endsWith(".txt"))txt=true
                    if(!e.isDirectory && name.endsWith(".md"))md=true
                    zip.closeEntry()
                }
            };txt&&md
        }.getOrDefault(false)
    }
    fun identifyConversation(uri:Uri):Long? {
        val (txt,_)=texts(uri)
        val samples=WhatsAppParser.parse(txt).filter{it.sender!="System" && it.body.trim().length>=8}
            .let{if(it.size<=20)it else it.take(10)+it.takeLast(10)}
        if(samples.isEmpty())return null
        val results=db.chats().map{chat->
            var matches=0
            for(web in samples) {
                val candidates=db.replyCandidates(chat.id,web.time,web.sender)
                if(candidates.count{normal(it.body)==normal(web.body) && kotlin.math.abs(it.time-web.time)<60000L}==1)matches++
            }
            chat.id to matches
        }.sortedByDescending{it.second}
        val best=results.firstOrNull()?:return null
        val minimum=if(samples.size<3)samples.size else 2
        return best.first.takeIf{best.second>=minimum && best.second>(results.getOrNull(1)?.second?:0)}
    }

    private fun texts(uri:Uri):Pair<String,String> {
        var txt="";var md="";var total=0L
        ZipInputStream(context.contentResolver.openInputStream(uri)?:error("Cannot open web ZIP")).use{z->
            var count=0
            while(true){val e=z.nextEntry?:break;count++;require(count<=10000){"Too many ZIP entries"}
                val name=e.name.substringAfterLast('/').lowercase(Locale.ROOT)
                if(!e.isDirectory && (name.endsWith(".txt")||name.endsWith(".md"))){
                    val buf=java.io.ByteArrayOutputStream();val chunk=ByteArray(8192)
                    while(true){val n=z.read(chunk);if(n<0)break;total+=n;require(total<=40_000_000){"Web ZIP text too large"};buf.write(chunk,0,n)}
                    val body=buf.toString("UTF-8").removePrefix("\uFEFF")
                    if(name.endsWith(".md") && (md.isEmpty()||body.length>md.length))md=body
                    if(name.endsWith(".txt") && (txt.isEmpty()||body.length>txt.length))txt=body
                }
                z.closeEntry()
            }
        }
        require(txt.isNotBlank() && md.isNotBlank()){ "Expected chat.txt and chat.md in WhatsApp Web ZIP" }
        return txt to md
    }
    private fun normal(s:String):String=s.replace(Regex("[\uFE0E\uFE0F\u200e\u200f]"),"")
        .replace(Regex("""\s+""")," ").trim().lowercase(Locale.ROOT)
    private fun samePerson(a:String,b:String):Boolean = a.equals(b,true) ||
        ((a.equals("You",true)||a.equals("Steve B",true)) && (b.equals("You",true)||b.equals("Steve B",true)))
    private fun messageMatch(messages:List<Message>,web:Message):List<Message> = messages.filter {
        kotlin.math.abs(it.time-web.time)<60000L && samePerson(it.sender,web.sender) && normal(it.body)==normal(web.body)
    }
    private val date=SimpleDateFormat("MMMM d, yyyy",Locale.US).apply{isLenient=false}
    private val clock=SimpleDateFormat("MMMM d, yyyy h:mm a",Locale.US).apply{isLenient=false}
    private fun markdown(text:String):List<MdReply> {
        val result=mutableListOf<MdReply>()
        val day=Regex("""^##\s+([A-Za-z]+\s+\d{1,2},\s+\d{4})\s*$""")
        val start=Regex("""^\[(\d{1,2}:\d{2}\s*[AP]M)]\s+\*\*(.*?):\*\*\s*(.*)$""",RegexOption.IGNORE_CASE)
        var dayText="";var whenMs:Long?=null;var who="";val body=StringBuilder();var quoted="";var quoteSender=""
        fun flush(){val t=whenMs
            if(t!=null && quoted.isNotBlank())result.add(MdReply(t,who,body.toString().trim(),quoteSender,quoted))
            whenMs=null;body.clear();quoted="";quoteSender=""
        }
        for(line in text.lineSequence()) {
            val trimmed=line.trimEnd('\r')
            val d=day.matchEntire(trimmed)
            if(d!=null){flush();dayText=d.groupValues[1];continue}
            val h=start.matchEntire(trimmed)
            if(h!=null){flush();who=h.groupValues[2].trim();whenMs=runCatching{clock.parse("$dayText ${h.groupValues[1].trim()}")?.time}.getOrNull()
                if(h.groupValues[3].isNotBlank())body.append(h.groupValues[3].trim());continue}
            if(whenMs==null)continue
            if(trimmed.startsWith(">")) {
                // Markdown reply preview: > _Sarah: original text_ . Do not infer
                // quote links from ordinary blockquotes without an actor prefix.
                val lineText=trimmed.removePrefix(">").trim().trim('_').trim()
                val actor=lineText.substringBefore(':',"").trim()
                val original=lineText.substringAfter(':',"").trim()
                if(actor.isNotBlank() && original.isNotBlank() && (quoted.isNotBlank() || original.length>=3)) {
                    if(quoted.isNotBlank())quoted+=" "
                    quoted+=original
                    if(quoteSender.isBlank())quoteSender=actor
                }
            }else if(trimmed.isNotBlank() && !trimmed.startsWith("---")) {
                if(body.isNotEmpty())body.append('\n')
                body.append(trimmed)
            }
        }
        flush();return result
    }
    // Build lookup tables once, not a full O(web messages × archive messages)
    // scan. Minute buckets include neighboring minutes because TXT has seconds.
    private class MessageIndex(messages:List<Message>,normalize:(String)->String,person:(String)->String) {
        private data class Key(val minute:Long,val sender:String,val text:String)
        private data class TextKey(val sender:String,val text:String)
        private val byMinute=HashMap<Key,MutableList<Message>>()
        private val byText=HashMap<TextKey,MutableList<Message>>()
        private val byPrefix=HashMap<TextKey,MutableList<Message>>()
        private val normal=normalize
        private val actor=person
        init {
            for(m in messages) {
                val who=actor(m.sender);val body=normal(m.body)
                val minute=Math.floorDiv(m.time,60000L)
                byMinute.getOrPut(Key(minute,who,body)){ArrayList(1)}.add(m)
                byText.getOrPut(TextKey(who,body)){ArrayList(1)}.add(m)
                if(body.length>=24)byPrefix.getOrPut(TextKey(who,body.take(24))){ArrayList(1)}.add(m)
            }
        }
        fun exactWithinMinute(time:Long,sender:String,text:String):List<Message> {
            val who=actor(sender);val body=normal(text);val minute=Math.floorDiv(time,60000L)
            return (-1L..1L).flatMap{delta->byMinute[Key(minute+delta,who,body)].orEmpty()}
                .filter{kotlin.math.abs(it.time-time)<60000L}
        }
        fun quotedBefore(replyTime:Long,sender:String,text:String):List<Message> {
            val who=actor(sender);val body=normal(text)
            val exact=byText[TextKey(who,body)].orEmpty().filter{it.time<=replyTime}
            if(exact.isNotEmpty())return exact
            if(body.length<30)return emptyList()
            val prefix=body.removeSuffix("...")
            if(prefix.length<24)return emptyList()
            return byPrefix[TextKey(who,prefix.take(24))].orEmpty()
                .filter{it.time<=replyTime && normal(it.body).startsWith(prefix)}
        }
    }
    private fun canonicalActor(name:String):String=when(name.trim().lowercase(Locale.ROOT)){
        "you","steve b"->"self"
        else->name.trim().lowercase(Locale.ROOT)
    }
    fun import(uri:Uri,chatId:Long,sourceHash:String,batchId:Long,
               progress:((Progress)->Unit)?=null):Result {
        progress?.invoke(Progress("Reading WhatsApp Web ZIP",0,0))
        val (raw,md)=texts(uri)
        progress?.invoke(Progress("Parsing Web TXT",0,0))
        val web=WhatsAppParser.parse(raw).filter{it.sender!="System"}
        require(web.isNotEmpty()){ "Web TXT has no readable messages" }
        val local=db.messages(chatId)
        progress?.invoke(Progress("Indexing archived messages",0,local.size))
        val idx=MessageIndex(local,::normal,::canonicalActor)
        // Match only uniquely identified archive messages. Two different Web
        // exports may include the same records: recordWebSeconds is idempotent.
        val matched=ArrayList<Pair<Message,Message>>()
        web.forEachIndexed { i,w ->
            idx.exactWithinMinute(w.time,w.sender,w.body).singleOrNull()?.let{matched.add(w to it)}
            if(i%250==0 || i==web.lastIndex)progress?.invoke(Progress("Matching Web TXT timestamps",i+1,web.size))
        }
        val required=if(web.size<3)web.size else 2
        require(matched.size>=required){ "Web export does not match this conversation (${matched.size} message anchors)" }
        matched.forEachIndexed {i,(webMessage,stored)->
            db.recordWebSeconds(chatId,stored,webMessage.time,sourceHash)
            if(i%250==0 || i==matched.lastIndex)progress?.invoke(Progress("Saving verified timestamps",i+1,matched.size))
        }
        var added=0;var verified=0;var corrected=0;var conflicts=0;var pending=0
        progress?.invoke(Progress("Reading Markdown quotes",0,0))
        val quotes=markdown(md)
        for((i,q) in quotes.withIndex()) {
            val reply=idx.exactWithinMinute(q.time,q.sender,q.body)
            if(reply.size!=1){pending++}
            else {
                val options=idx.quotedBefore(reply.single().time,q.quotedSender,q.quotedText)
                if(options.size!=1){pending++}
                else when(db.reconcileMarkdownQuote(chatId,reply.single(),options.single(),batchId)){
                    "added"->added++;"verified"->verified++;"corrected"->corrected++;else->conflicts++
                }
            }
            if(i%50==0 || i==quotes.lastIndex)progress?.invoke(Progress("Reconciling Markdown quotes",i+1,quotes.size))
        }
        progress?.invoke(Progress("Web export completed",1,1))
        return Result(matched.size,added,verified,corrected,conflicts,pending)
    }
}
