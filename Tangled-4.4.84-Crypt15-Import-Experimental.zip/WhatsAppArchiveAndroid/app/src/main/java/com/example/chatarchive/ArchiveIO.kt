package com.example.chatarchive

import android.content.Context
import android.net.Uri
import org.json.JSONObject
import org.json.JSONArray
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

internal class ArchiveIO(private val context: Context, private val db: ArchiveDb, mediaRoot:File=File(context.filesDir,"media")) {
    private val media = mediaRoot.apply { mkdirs() }
    private val maxTextBytes = 128L * 1024 * 1024
    private val maxMediaBytes = 4L * 1024 * 1024 * 1024
    private val maxTotalBytes = 8L * 1024 * 1024 * 1024

    fun importChat(uri: Uri, chatName: String, autoBatchId:Long?=null, originalName:String?=null): Pair<Int,Int> {
        val fileName = originalName ?: runCatching { context.contentResolver.query(uri,null,null,null,null)?.use { c ->
            val i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if(i >= 0 && c.moveToFirst()) c.getString(i) else null
        } }.getOrNull() ?: uri.lastPathSegment.orEmpty()
        val text: String
        val staged = mutableMapOf<String,File>()
        val temporary = File(context.cacheDir,"import_${UUID.randomUUID()}").apply{mkdirs()}
        try {
            if (fileName.endsWith(".zip",true)) {
                var total = 0L
                val texts = mutableListOf<Pair<String,String>>()
                val buffer = ByteArray(64 * 1024)
                ZipInputStream(context.contentResolver.openInputStream(uri) ?: error("Unable to read file")).use { zip ->
                    while (true) {
                        val entry = zip.nextEntry ?: break
                        if (entry.isDirectory) { zip.closeEntry(); continue }
                        val baseName = entry.name.replace('\\','/').substringAfterLast('/')
                        if (baseName.isBlank() || baseName.startsWith(".")) { zip.closeEntry(); continue }
                        if (baseName.endsWith(".txt",true)) {
                            val bytes = readBounded(zip,maxTextBytes) { total += it; require(total <= maxTotalBytes) { "Archive exceeds supported size" } }
                            texts.add(baseName to bytes.toString(Charsets.UTF_8).removePrefix("\uFEFF"))
                        } else {
                            val suffix = baseName.substringAfterLast('.',"").lowercase(Locale.ROOT)
                            if (suffix in setOf("jpg","jpeg","png","webp","gif","mp4","mov","3gp","mp3","ogg","opus","pdf","m4a","aac","wav","amr","webm","heic")) {
                                // Write chunks directly to disk; never allocate a giant media ByteArray.
                                val target = File(temporary, UUID.randomUUID().toString()+"."+suffix)
                                target.outputStream().use { out ->
                                    copyBounded(zip,out,buffer,maxMediaBytes) { total += it; require(total <= maxTotalBytes) { "Archive exceeds supported size" } }
                                }
                                if(staged.containsKey(baseName)) target.delete() else staged[baseName]=target
                            } else {
                                // Drain unsupported files without allocating them.
                                copyBounded(zip,null,buffer,maxMediaBytes) { total += it; require(total <= maxTotalBytes) { "Archive exceeds supported size" } }
                            }
                        }
                        zip.closeEntry()
                    }
                }
                text = texts.firstOrNull { it.first.startsWith("_chat",true) }?.second ?: texts.maxByOrNull { it.second.length }?.second ?: error("No WhatsApp .txt chat found in ZIP")
            } else {
                require(fileName.endsWith(".txt",true)) { "Choose a WhatsApp .txt or .zip export" }
                text = context.contentResolver.openInputStream(uri)?.use { String(readBounded(it,maxTextBytes)).removePrefix("\uFEFF") } ?: error("Unable to read file")
            }
            val items = WhatsAppParser.parse(text)
            require(items.isNotEmpty()) { "No WhatsApp messages found. Check that this is an exported chat." }
            // Only media explicitly referenced by imported messages is copied into private storage.
            val imported = items.map { m ->
                val name = WhatsAppParser.attachmentName(m.body)
                val source = if(name == null) null else staged[name]
                if (source == null) m else {
                    // Keep a stable filename across overlapping exports and avoid
                    // overwriting unrelated attachments with the same exported name.
                    val extension = source.extension
                    val dest = File(media, "${m.fingerprint.take(24)}_${m.occurrence}.$extension")
                    if (!dest.exists()) source.copyTo(dest)
                    m.copy(attachment=dest.name)
                }
            }
            return db.insert(chatName, imported,autoBatchId)
        } finally { temporary.deleteRecursively() }
    }

    fun inspectChat(uri:Uri):List<Message> {
        val fileName=runCatching{context.contentResolver.query(uri,null,null,null,null)?.use{c->val i=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);if(i>=0&&c.moveToFirst())c.getString(i)else null}}.getOrNull() ?: uri.lastPathSegment.orEmpty()
        val content=if(fileName.endsWith(".zip",true)) {
            val texts=mutableListOf<Pair<String,String>>()
            ZipInputStream(context.contentResolver.openInputStream(uri) ?: error("Cannot read ZIP")).use {zip->
                while(true){val entry=zip.nextEntry ?: break
                    val base=entry.name.replace('\\','/').substringAfterLast('/')
                    if(!entry.isDirectory && base.endsWith(".txt",true))texts.add(base to readBounded(zip,maxTextBytes).toString(Charsets.UTF_8).removePrefix("\uFEFF"))
                    zip.closeEntry()
                }
            }
            texts.firstOrNull{it.first.startsWith("_chat",true)}?.second ?: texts.maxByOrNull{it.second.length}?.second ?: error("No WhatsApp text found")
        }else context.contentResolver.openInputStream(uri)?.use{readBounded(it,maxTextBytes).toString(Charsets.UTF_8).removePrefix("\uFEFF")} ?: error("Cannot read TXT")
        return WhatsAppParser.parse(content)
    }
    private fun settingsSnapshot():JSONObject {
        val result=JSONObject()
        val prefDir=File(context.applicationInfo.dataDir,"shared_prefs")
        for(file in prefDir.listFiles().orEmpty()) {
            if(!file.isFile || file.extension!="xml")continue
            val name=file.nameWithoutExtension
            // Password hashes, biometrics and device-specific secrets are not portable.
            if(name.contains("security",true) || name.contains("lock",true))continue
            val prefs=context.getSharedPreferences(name,Context.MODE_PRIVATE)
            val entries=JSONObject()
            for((key,value) in prefs.all) {
                if(value==null || key=="folder" || key=="enabled" || key.startsWith("assoc_"))continue
                when(value) {
                    is String -> entries.put(key,JSONObject().put("type","string").put("value",value))
                    is Boolean -> entries.put(key,JSONObject().put("type","boolean").put("value",value))
                    is Int -> entries.put(key,JSONObject().put("type","int").put("value",value))
                    is Long -> entries.put(key,JSONObject().put("type","long").put("value",value))
                    is Float -> entries.put(key,JSONObject().put("type","float").put("value",value.toDouble()))
                    is Set<*> -> entries.put(key,JSONObject().put("type","strings").put("value",JSONArray(value.toList())))
                }
            }
            result.put(name,entries)
        }
        return result
    }
    private fun restoreSettings(settings:JSONObject,chatIdMap:Map<Long,Long>) {
        for(name in settings.keys()) {
            val entries=settings.optJSONObject(name)?:continue
            val pref=context.getSharedPreferences(name,Context.MODE_PRIVATE)
            val edit=pref.edit().clear()
            for(key in entries.keys()) {
                val row=entries.optJSONObject(key)?:continue
                if(key=="folder" || key=="enabled" || key.startsWith("assoc_"))continue
                val actualKey=if(key.startsWith("sender_")) {
                    val old=key.removePrefix("sender_").toLongOrNull()
                    old?.let(chatIdMap::get)?.let { "sender_$it" } ?: continue
                } else key
                when(row.optString("type")) {
                    "string" -> edit.putString(actualKey,row.optString("value"))
                    "boolean" -> edit.putBoolean(actualKey,row.optBoolean("value"))
                    "int" -> edit.putInt(actualKey,row.optInt("value"))
                    "long" -> edit.putLong(actualKey,row.optLong("value"))
                    "float" -> edit.putFloat(actualKey,row.optDouble("value").toFloat())
                    "strings" -> { val a=row.optJSONArray("value")?:JSONArray();edit.putStringSet(actualKey,(0 until a.length()).map{a.optString(it)}.toSet()) }
                }
            }
            edit.apply()
        }
        // Never restore a SAF tree URI from a different Android install.
        context.getSharedPreferences("tangled_auto_sync",Context.MODE_PRIVATE).edit()
            .remove("folder").putBoolean("enabled",false).apply()
    }
    private fun privateScannerFolder():File=File(context.filesDir,"pending_scanner_json")

    fun backup(uri: Uri) {
        context.contentResolver.openOutputStream(uri,"wt")?.use { output ->
            ZipOutputStream(output).use { zip ->
                zip.putNextEntry(ZipEntry("archive.json"))
                zip.write(db.snapshot().toString().toByteArray(Charsets.UTF_8))
                zip.closeEntry()
                zip.putNextEntry(ZipEntry("portable-state.json"))
                zip.write(db.portableExtras().toString().toByteArray(Charsets.UTF_8))
                zip.closeEntry()
                zip.putNextEntry(ZipEntry("settings.json"))
                zip.write(settingsSnapshot().toString().toByteArray(Charsets.UTF_8))
                zip.closeEntry()
                val backedScans=mutableSetOf<String>()
                privateScannerFolder().listFiles()?.filter { it.isFile && it.name.matches(Regex("[a-zA-Z0-9._-]+")) }?.forEach { file ->
                    backedScans.add(file.name)
                    zip.putNextEntry(ZipEntry("pending-scans/${file.name}"))
                    file.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
                // Include watched quote/reaction JSONs as portable sources. Original
                // chat ZIPs need not be duplicated: imported messages and media are
                // already in this backup. Android's SAF grants are not portable.
                val syncPrefs=context.getSharedPreferences("tangled_auto_sync",Context.MODE_PRIVATE)
                val tree=syncPrefs.getString("folder",null)?.let { Uri.parse(it) }
                if(tree!=null) {
                    val children=android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(
                        tree,android.provider.DocumentsContract.getTreeDocumentId(tree))
                    val columns=arrayOf(android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                    runCatching {
                        context.contentResolver.query(children,columns,null,null,null)?.use {cursor ->
                            while(cursor.moveToNext()) {
                                val filename=cursor.getString(1)?:continue
                                if(!filename.matches(Regex("[a-zA-Z0-9._-]+\\.json")) || filename in backedScans)continue
                                backedScans.add(filename)
                                val source=android.provider.DocumentsContract.buildDocumentUriUsingTree(tree,cursor.getString(0))
                                zip.putNextEntry(ZipEntry("pending-scans/$filename"))
                                context.contentResolver.openInputStream(source)?.use { it.copyTo(zip) }
                                    ?:error("Cannot back up $filename")
                                zip.closeEntry()
                            }
                        }
                    }.getOrElse {throw IllegalStateException("Cannot include watched scanner JSON files: ${it.message}. Re-select your Auto Sync folder and retry.",it)}
                }
                // Complete backups include the actual private synced source ZIPs and JSONs.
                val vault=SyncedVault(context)
                vault.backupFiles().forEach { file ->
                    zip.putNextEntry(ZipEntry("synced-vault/${file.name}"))
                    file.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
                media.listFiles()?.filter { it.isFile }?.forEach { file ->
                    zip.putNextEntry(ZipEntry("media/${file.name}"))
                    file.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
            }
        } ?: error("Unable to create backup")
    }

    fun restore(uri: Uri) {
        val staging = File(context.cacheDir,"restore_${UUID.randomUUID()}").apply{mkdirs()}
        try {
            var total = 0L
            var json: JSONObject? = null
            var extra:JSONObject?=null
            var settings:JSONObject?=null
            val stagedVault=File(staging,"synced-vault").apply{mkdirs()}
            val stagedScans=File(staging,"pending-scans").apply{mkdirs()}
            val stagedMedia = File(staging,"media").apply{mkdirs()}
            ZipInputStream(context.contentResolver.openInputStream(uri) ?: error("Unable to open backup")).use { zip ->
                while(true) {
                    val entry = zip.nextEntry ?: break
                    if(entry.isDirectory) continue
                    val name = entry.name
                    if(name == "archive.json") {
                        val bytes = readBounded(zip,maxTextBytes) { total += it; require(total <= maxTotalBytes) { "Backup exceeds supported size" } }
                        json = JSONObject(bytes.toString(Charsets.UTF_8))
                    } else if(name=="portable-state.json") {
                        val bytes=readBounded(zip,maxTextBytes){total+=it;require(total<=maxTotalBytes)}
                        extra=JSONObject(bytes.toString(Charsets.UTF_8))
                    } else if(name=="settings.json") {
                        val bytes=readBounded(zip,maxTextBytes){total+=it;require(total<=maxTotalBytes)}
                        settings=JSONObject(bytes.toString(Charsets.UTF_8))
                    } else if(name.startsWith("pending-scans/") && name.removePrefix("pending-scans/").matches(Regex("[a-zA-Z0-9._-]+\\.json"))) {
                        val target=File(stagedScans,name.removePrefix("pending-scans/"))
                        target.outputStream().use{out->copyBounded(zip,out,ByteArray(65536),maxTextBytes){total+=it;require(total<=maxTotalBytes)}}
                    } else if(name.startsWith("synced-vault/") && name.removePrefix("synced-vault/").matches(Regex("[a-zA-Z0-9._-]+"))) {
                        val entryName=name.removePrefix("synced-vault/")
                        require(entryName=="index.json" || entryName.matches(Regex("[a-f0-9]{64}\\.(zip|json|txt)"))) { "Invalid vault entry" }
                        File(stagedVault,entryName).outputStream().use { out ->
                            copyBounded(zip,out,ByteArray(65536),maxMediaBytes) { total+=it;require(total<=maxTotalBytes) }
                        }
                    } else if(name.startsWith("media/") && name.removePrefix("media/").matches(Regex("[a-zA-Z0-9._-]+"))) {
                        File(stagedMedia,name.removePrefix("media/")).outputStream().use { out ->
                            copyBounded(zip,out,ByteArray(65536),maxMediaBytes) { total += it;require(total <= maxTotalBytes) { "Backup exceeds supported size" } }
                        }
                    } else {
                        copyBounded(zip,null,ByteArray(65536),maxMediaBytes) { total += it;require(total <= maxTotalBytes) { "Backup exceeds supported size" } }
                    }
                }
            }
            val archive = json ?: error("Not a Chat Archive backup: archive.json missing")
            // If archive validation fails, original DB and media remain intact.
            // Copy media before restoring message rows, so an unsuccessful media copy
            // cannot leave a newly restored database pointing to absent attachments.
            val replacement = File(context.filesDir,"restore_media_${UUID.randomUUID()}").apply { mkdirs() }
            try {
                stagedMedia.listFiles()?.forEach { it.copyTo(File(replacement,it.name),overwrite=true) }
                db.restore(archive)
                extra?.let { db.restorePortableExtras(it) }
                val previous = File(context.filesDir,"old_media_${UUID.randomUUID()}")
                if(media.exists()) check(media.renameTo(previous)) { "Cannot prepare media restore" }
                if(!replacement.renameTo(media)) {
                    previous.renameTo(media)
                    error("Cannot complete media restore")
                }
                previous.deleteRecursively()
                // Restore local pending scanner JSON; watched folders are Android-specific.
                val pending=privateScannerFolder().apply{mkdirs()}
                pending.listFiles()?.filter{it.isFile}?.forEach{it.delete()}
                stagedScans.listFiles()?.forEach{it.copyTo(File(pending,it.name),overwrite=true)}
                // Legacy backups lacking a vault explicitly restore an empty vault.
                SyncedVault(context).restoreFrom(stagedVault)
                if(settings!=null)restoreSettings(settings!!,extra?.let{db.portableChatIdMap(it)}?:emptyMap())
            } finally { replacement.deleteRecursively() }
        } finally { staging.deleteRecursively() }
    }

    data class MergePreview(val chats:Int,val newChats:Int,val messages:Int,val mediaEntries:Int)
    private val mergeUndoFile get() = File(context.filesDir,"last-merge-undo.json")
    fun canUndoMerge():Boolean=mergeUndoFile.isFile
    // ZIP entries are staged, never extracted using untrusted paths.
    private fun readMergeBackup(uri:Uri, staging:File):Pair<JSONObject,Map<String,File>> {
        val attachments=linkedMapOf<String,File>()
        var json:JSONObject?=null
        var total=0L
        ZipInputStream(context.contentResolver.openInputStream(uri) ?: error("Cannot read backup")).use{zip->
            while(true){
                val entry=zip.nextEntry ?: break
                if(!entry.isDirectory){
                    when {
                        entry.name=="archive.json" -> {
                            require(json==null){"Duplicate archive.json"}
                            json=JSONObject(readBounded(zip,maxTextBytes){total+=it;require(total<=maxTotalBytes)}.toString(Charsets.UTF_8))
                        }
                        entry.name.startsWith("media/") -> {
                            val name=entry.name.removePrefix("media/")
                            require(name.matches(Regex("[a-zA-Z0-9._-]+"))){"Unsafe media filename in backup"}
                            require(!attachments.containsKey(name)){"Duplicate media name in backup"}
                            val file=File(staging,UUID.randomUUID().toString())
                            file.outputStream().use{out->copyBounded(zip,out,ByteArray(65536),maxMediaBytes){total+=it;require(total<=maxTotalBytes)}}
                            attachments[name]=file
                        }
                        else -> copyBounded(zip,null,ByteArray(65536),maxMediaBytes){total+=it;require(total<=maxTotalBytes)}
                    }
                }
                zip.closeEntry()
            }
        }
        val archive=json ?: error("Not a Tangled backup: archive.json is missing")
        require(archive.getInt("format") in 1..2){"Unsupported Tangled backup version"}
        val chats=archive.getJSONArray("chats")
        for(i in 0 until chats.length()){
            val entry=chats.getJSONObject(i)
            require(entry.has("name") && entry.has("messages")){"Backup conversation is incomplete"}
        }
        return archive to attachments
    }
    fun previewMerge(uri:Uri):MergePreview {
        val staging=File(context.cacheDir,"merge_preview_${UUID.randomUUID()}").apply{mkdirs()}
        try {
            val (json,media)=readMergeBackup(uri,staging)
            val chats=json.getJSONArray("chats")
            val existing=db.chats().map{it.name}.toSet()
            var missing=0;var count=0
            for(i in 0 until chats.length()){
                val c=chats.getJSONObject(i)
                if(c.getString("name") !in existing)missing++
                count+=c.getJSONArray("messages").length()
            }
            return MergePreview(chats.length(),missing,count,media.size)
        }finally{staging.deleteRecursively()}
    }
    fun mergeBackup(uri:Uri):String {
        require(!canUndoMerge()){"Undo the previous merge first, or keep it using 'Accept previous merge' in Restore."}
        val staging=File(context.cacheDir,"merge_stage_${UUID.randomUUID()}").apply{mkdirs()}
        val addedFiles=mutableListOf<File>()
        var committed=false
        try {
            val (json,files)=readMergeBackup(uri,staging)
            // Copy attachments safely before inserting references into the database.
            // Reuse an identical existing file; never replace different bytes.
            fun digest(file:File):String {
                val d=java.security.MessageDigest.getInstance("SHA-256")
                file.inputStream().use{input->val block=ByteArray(65536);while(true){val n=input.read(block);if(n<0)break;d.update(block,0,n)}}
                return d.digest().joinToString(""){ "%02x".format(it) }
            }
            val map=linkedMapOf<String,String>()
            for((original,source) in files){
                val same=File(media,original)
                if(same.isFile && same.length()==source.length() && digest(same)==digest(source)){
                    map[original]=original;continue
                }
                // Existing different content is never overwritten.
                val dest=if(same.exists()) File(media,"merged_${UUID.randomUUID()}_${original}") else same
                source.copyTo(dest)
                addedFiles.add(dest)
                map[original]=dest.name
            }
            val receipt=db.mergeBackup(json,map)
            committed=true
            receipt.put("media",org.json.JSONArray().apply{addedFiles.forEach{put(it.name)}})
            // Persist the undo manifest atomically before reporting success.
            val temp=File(context.filesDir,"last-merge-undo.tmp")
            try {
                temp.writeText(receipt.toString())
                check(temp.renameTo(mergeUndoFile)){"Could not save merge undo record"}
            } catch(error:Exception) {
                // Never leave a successful merge with no corresponding Undo record.
                db.undoBackupMerge(receipt)
                committed=false
                temp.delete()
                throw error
            }
            return "Merged ${receipt.getInt("added")} messages into ${json.getJSONArray("chats").length()} conversations (${receipt.getInt("new_chat_count")} new). Skipped ${receipt.getInt("duplicates")} existing messages. Undo is available under Restore."
        }catch(e:Exception){
            if(!committed)addedFiles.forEach{it.delete()}
            throw e
        }finally{staging.deleteRecursively()}
    }
    fun undoLastMerge():String {
        val saved=JSONObject(mergeUndoFile.readText())
        db.undoBackupMerge(saved)
        val mediaEntries=saved.optJSONArray("media") ?: org.json.JSONArray()
        // Delete only files created by this import and no longer referenced.
        for(i in 0 until mediaEntries.length()){
            val name=mediaEntries.getString(i)
            if(name.matches(Regex("[a-zA-Z0-9._-]+")) && !db.isMediaReferenced(name)) File(media,name).delete()
        }
        mergeUndoFile.delete()
        return "Last backup merge undone. Existing conversations and media were retained."
    }
    fun acceptLastMerge(){mergeUndoFile.delete()}

    fun mediaFile(name: String?): File? = if(name != null && name.matches(Regex("[a-zA-Z0-9._-]+"))) File(media,name).takeIf{it.isFile} else null

    private fun copyBounded(input: InputStream, output: OutputStream?, buffer: ByteArray, limit: Long, onChunk:(Long)->Unit = {}): Long {
        var size = 0L
        while (true) {
            val n = input.read(buffer)
            if(n < 0) break
            size += n
            require(size <= limit) { "One attachment exceeds the supported size" }
            onChunk(n.toLong())
            output?.write(buffer,0,n)
        }
        return size
    }

    private fun readBounded(input: InputStream, limit: Long, onChunk:(Long)->Unit = {}): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var size = 0L
        while(true) {
            val n = input.read(buffer)
            if(n < 0) break
            size += n; require(size <= limit) { "File exceeds size limit" }
            onChunk(n.toLong())
            out.write(buffer,0,n)
        }
        return out.toByteArray()
    }
}

internal object WhatsAppParser {
    // WhatsApp uses hidden left-to-right marks around edited-message tags in some exports.
    // Strip these only while detecting the message header, not from the saved message body.
    private val hiddenMarks = Regex("[\u200e\u200f\u202a-\u202e\u2066-\u2069\ufeff]")
    private val android = Regex("^(\\d{1,2}[/.]\\d{1,2}[/.]\\d{2,4}),?\\s+(\\d{1,2}:\\d{2}(?::\\d{2})?(?:\\s*[AaPp][Mm])?)\\s*[-–]\\s*(.*)$")
    private val ios = Regex("^\\[(\\d{1,2}[/.]\\d{1,2}[/.]\\d{2,4}),?\\s+(\\d{1,2}:\\d{2}(?::\\d{2})?(?:\\s*[AaPp][Mm])?)\\]\\s*(.*)$")
    // Exported files contain no stable message ID. Occurrence distinguishes repeated identical messages within an export.
    fun parse(raw: String): List<Message> {
        val output = mutableListOf<Triple<Long,String,String>>()
        var time: Long? = null
        var sender = ""
        val body = StringBuilder()
        fun flush() { if(time != null) output.add(Triple(time!!,sender,body.toString().trimEnd())) }
        // Determine the format once for the whole export. WhatsApp exports can be
        // MM/DD/YY even on a UK phone: e.g. 10/13/26 is October 13, not day 10
        // of month 13. Without this, all subsequent messages become one bubble.
        val monthFirst = inferMonthFirst(raw)
        for(line in raw.lineSequence()) {
            val normalizedHeader = line.trimEnd('\r').replace(hiddenMarks, "").replace('\u202f', ' ').replace('\u00a0', ' ')
            val match = android.matchEntire(normalizedHeader) ?: ios.matchEntire(normalizedHeader)
            if(match != null) {
                val epoch = parseDate(match.groupValues[1],match.groupValues[2],monthFirst)
                if(epoch != null) {
                    flush(); time=epoch
                    val content = match.groupValues[3]
                    val split = content.indexOf(": ")
                    if(split >= 0) { sender=content.substring(0,split);body.clear();body.append(content.substring(split+2)) }
                    else { sender="System";body.clear();body.append(content) }
                    continue
                }
            }
            if(time != null) body.append('\n').append(line.trimEnd('\r'))
        }
        flush()
        val seen = mutableMapOf<String,Int>()
        return output.map { (t,s,b) ->
            val hash = ArchiveDb.hash(t,s,b)
            val ordinal = seen.getOrDefault(hash,0)
            seen[hash] = ordinal+1
            Message(t,s,b,null,hash,ordinal)
        }
    }
    fun attachmentName(body: String): String? {
        val name = Regex("([A-Za-z0-9 _().-]+\\.(?:jpg|jpeg|png|webp|gif|mp4|mp3|ogg|opus|pdf|m4a|aac))",RegexOption.IGNORE_CASE).find(body)?.groupValues?.get(1)?.trim()
        return name?.substringAfterLast('/')
    }
    private fun inferMonthFirst(raw: String): Boolean {
        var usEvidence = 0
        var ukEvidence = 0
        var attachmentUsEvidence = 0
        var attachmentUkEvidence = 0
        var previousUS: Int? = null
        var previousUK: Int? = null
        var usBackwards = 0
        var ukBackwards = 0
        var headers = 0
        // Work from the FULL export, never from individual ambiguous dates.
        // In particular, a date such as 10/13/26 proves MM/DD/YY whereas
        // 04/11/26 tells us nothing until the export's overall convention is known.
        val mediaDate = Regex("(?i)(?:IMG|VID|PTT|AUD|STK)-((?:19|20)\\d{6})-[A-Z0-9_-]+")
        for (line in raw.lineSequence()) {
            val header = line.trimEnd('\r').replace(hiddenMarks, "").replace('\u202f', ' ').replace('\u00a0', ' ')
            val matched = android.matchEntire(header) ?: ios.matchEntire(header) ?: continue
            val parts = matched.groupValues[1].replace('.', '/').split('/')
            if (parts.size != 3) continue
            val first = parts[0].toIntOrNull() ?: continue
            val second = parts[1].toIntOrNull() ?: continue
            val year = parts[2].toIntOrNull()?.let { if (it < 100) it + (if (it >= 70) 1900 else 2000) else it } ?: continue
            if (first !in 1..31 || second !in 1..31) continue
            headers++
            if (first in 1..12 && second in 13..31) usEvidence++
            if (first in 13..31 && second in 1..12) ukEvidence++
            val stamp = mediaDate.find(matched.groupValues[3])?.groupValues?.getOrNull(1)
            if (stamp != null && stamp.length == 8) {
                val mediaYear = stamp.substring(0, 4).toIntOrNull()
                val mediaMonth = stamp.substring(4, 6).toIntOrNull()
                val mediaDay = stamp.substring(6, 8).toIntOrNull()
                if (mediaYear == year) {
                    if (mediaMonth == first && mediaDay == second) attachmentUsEvidence++
                    if (mediaMonth == second && mediaDay == first) attachmentUkEvidence++
                }
            }
            // Use all calendar-valid dates when assessing chronology. The prior
            // implementation skipped decisive (day > 12) records here.
            if (first in 1..12 && second in 1..31) {
                val key = year * 10000 + first * 100 + second
                if (previousUS != null && key < previousUS!!) usBackwards++
                previousUS = key
            }
            if (second in 1..12 && first in 1..31) {
                val key = year * 10000 + second * 100 + first
                if (previousUK != null && key < previousUK!!) ukBackwards++
                previousUK = key
            }
        }
        // Any unambiguous date in the file takes precedence over the device's locale.
        if (usEvidence != ukEvidence) return usEvidence > ukEvidence
        if (attachmentUsEvidence != attachmentUkEvidence) return attachmentUsEvidence > attachmentUkEvidence
        if (usBackwards != ukBackwards) return usBackwards < ukBackwards
        // Avoid silently corrupting long imports containing *only* dates 1–12.
        // Such files require stronger evidence or an explicit date-format choice.
        if (headers >= 12) throw IllegalArgumentException(
            "Cannot establish DD/MM or MM/DD date order from this export. " +
            "Please import a longer export containing unambiguous dates."
        )
        return false // Legacy DD/MM fallback for very short, wholly ambiguous exports.
    }
    private fun parseDate(date: String, clock: String, monthFirst: Boolean): Long? {
        val pieces = date.replace('.','/').split('/')
        if(pieces.size != 3) return null
        val first = pieces[0].toIntOrNull() ?: return null
        val second = pieces[1].toIntOrNull() ?: return null
        val d = if(monthFirst) second else first
        val m = if(monthFirst) first else second
        var y = pieces[2].toIntOrNull() ?: return null
        if(y < 100) y += if(y >= 70) 1900 else 2000
        val normalized = "%04d-%02d-%02d %s".format(Locale.ROOT,y,m,d,clock.trim().uppercase(Locale.ROOT).replace(Regex("(?i)\\s*([AP]M)$"), " $1").trim())
        val format = if(normalized.endsWith("AM") || normalized.endsWith("PM")) {
            if(clock.count{it==':'}==2) "yyyy-MM-dd hh:mm:ss a" else "yyyy-MM-dd hh:mm a"
        } else { if(clock.count{it==':'}==2) "yyyy-MM-dd HH:mm:ss" else "yyyy-MM-dd HH:mm" }
        return try { SimpleDateFormat(format,Locale.US).apply {isLenient=false;timeZone=TimeZone.getDefault()}.parse(normalized)?.time } catch(_:Exception){null}
    }
}
