package com.example.chatarchive

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import java.io.OutputStream
import org.json.JSONObject
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

// Android SAF: only the folder explicitly selected by the user is accessible.
internal class AutoSync(private val context:Context,private val db:ArchiveDb,private val archive:ArchiveIO) {
    private val prefs=context.getSharedPreferences("tangled_auto_sync",Context.MODE_PRIVATE)
    val vault=SyncedVault(context)
    private val busy=AtomicBoolean(false)
    // UI-only live information. Individual importers don't expose reliable byte or
    // record percentages, so the UI uses an indeterminate progress indicator.
    internal data class SyncProgress(val fileName:String,val stage:String,val index:Int,val total:Int,val recordsDone:Int=0,val recordsTotal:Int=0)
    @Volatile var syncProgress:SyncProgress?=null
        private set
    private val dateParser=SimpleDateFormat("h:mm a, d/M/yyyy",Locale.UK).apply{isLenient=false} // WhatsApp Web JSON uses UK day/month/year
    data class Candidate(val name:String,val uri:Uri,val kind:String,val key:String)
    data class ScanReport(val scanned:Int,val imported:Int,val skipped:Int,val awaiting:List<Candidate>,val errors:List<String>)
    fun folder():Uri?=prefs.getString("folder",null)?.let{Uri.parse(it)}
    fun setFolder(uri:Uri){prefs.edit().putString("folder",uri.toString()).putBoolean("enabled",true).apply()}
    fun enabled():Boolean=prefs.getBoolean("enabled",false)&&folder()!=null

    // Legacy private pending scanner JSON from older versions is still flushed
    // when Auto Sync is configured; no clipboard is inspected by this release.
    fun flushQueuedScannerJson() {
        // Legacy clipboard files are no longer auto-processed. No clipboard access.
    }
    fun hasWriteAccess():Boolean {
        val uri=folder()?:return false
        return context.contentResolver.persistedUriPermissions.any{it.uri==uri && it.isWritePermission}
    }
    fun setEnabled(value:Boolean){prefs.edit().putBoolean("enabled",value).apply()}
    fun isBusy():Boolean=busy.get()
    fun displayFolder():String=folder()?.lastPathSegment?.substringAfterLast(':') ?: "No folder selected"
    // Keep the export filename separate from the editable conversation title.
    // Android often appends " (1)", " (2)", etc. to repeated downloads.
    fun suggestedChatName(filename:String):String {
        val base=filename.trim().replace(Regex("(?i)\\.(zip|txt)$"),"")
            .replace(Regex("\\s*\\(\\d+\\)$"),"").trim()
        // The WhatsApp export prefix is not part of the conversation's display name.
        // Keep normalise() untouched: original export names remain valid Auto Sync aliases.
        return base.replace(Regex("(?i)^whatsapp\\s+chat\\s+with\\s+"),"")
            .replace(Regex("(?i)^whatsapp\\s+chat\\s*[-–]\\s*"),"").trim()
            .ifBlank { base }
    }
    // Preserve v4.4 association keys for JSON files and other already linked imports.
    fun normalise(name:String):String {
        val withoutExtension=name.substringBeforeLast('.',name).trim()
        return withoutExtension.replace(Regex("\\s*\\(\\d+\\)$"),"").trim().lowercase(Locale.ROOT)
    }
    private fun associationKey(candidate:Candidate)="assoc_${candidate.kind}_${candidate.key}"
    fun remember(candidate:Candidate,chatId:Long){
        db.rememberSource(candidate.kind,candidate.key,chatId)
        prefs.edit().putLong(associationKey(candidate),chatId).remove("blocked_${candidate.kind}_${candidate.key}").apply()
    }
    fun unlink(kind:String,key:String,chatId:Long) {
        db.unlinkSource(kind,key,chatId)
        prefs.edit().remove("assoc_${kind}_${key}").putBoolean("blocked_${kind}_${key}",true).apply()
    }
    private fun isKnownChat(id:Long):Boolean=db.chats().any{it.id==id}
    fun assignedChat(c:Candidate):Long? {
        if(prefs.getBoolean("blocked_${c.kind}_${c.key}",false))return null
        val stored=db.sourceOwner(c.kind,c.key)
        if(stored!=null && isKnownChat(stored))return stored
        val remembered=prefs.getLong(associationKey(c),-1L)
        if(remembered>0 && isKnownChat(remembered)) {
            db.rememberSource(c.kind,c.key,remembered)
            return remembered
        }
        if(c.kind=="quote") {
            // Prefer the chat name captured from WhatsApp Web. A filename can be used
            // only if it follows our named-export convention, never for generic JSONs.
            val name=runCatching {
                context.contentResolver.openInputStream(c.uri)?.bufferedReader()?.use { reader ->
                    val raw=reader.readText()
                    require(raw.length<=20_000_000){"Quoted JSON too large"}
                    val json=JSONObject(raw)
                    json.optString("source_chat_name").ifBlank{json.optString("chat_name")}
                }.orEmpty()
            }.getOrDefault("").trim()
            val fallback=Regex("(?i)^(.+?)-quoted-(?:history|update|replies)(?:\\s*\\(\\d+\\))?$")
                .matchEntire(c.key)?.groupValues?.get(1).orEmpty()
            val timestamped=Regex("^(.+)-\\d{12,17}$").matchEntire(c.key)?.groupValues?.get(1).orEmpty()
            val target=name.ifBlank{fallback.ifBlank{timestamped}}
            if(target.isBlank()) {
                val estimated=matchUnnamedScanner(c)
                if(estimated!=null)remember(c,estimated)
                return estimated
            }
            fun key(raw:String):String = normalise(raw)
                .replace(Regex("(?i)^whatsapp\\s+chat\\s+(?:with\\s+|[-–]\\s*)"),"")
                .trim()
            val wanted=key(target)
            val matches=db.chats().filter { chat ->
                key(chat.name)==wanted || db.sourceNames(chat.id).any { (kind,alias) ->
                    kind=="chat" && key(alias)==wanted
                }
            }
            val inferred=matches.singleOrNull()?.id
            if(inferred!=null)remember(c,inferred)
            return inferred
        }
        // Web ZIP names may have a distinct prefix; never create a new chat for them.
        // They remain awaiting association if an Android conversation is not yet present.
        // Filename matching is primary; one-time association resolves renamed archive chats.
        val simple=c.key.removePrefix("whatsapp web export ").removePrefix("whatsapp web chat with ")
            .removePrefix("whatsapp chat with ").removePrefix("whatsapp chat - ").trim()
        val matches=db.chats().filter {chat->
            val chatKey=normalise(chat.name+".zip")
            chatKey==c.key || chatKey==simple || chatKey.removePrefix("whatsapp chat with ")==simple
        }
        val inferred=matches.singleOrNull()?.id ?: if(c.kind=="web")
            runCatching{WebExportImporter(context,db).identifyConversation(c.uri)}.getOrNull() else null
        if(inferred!=null)remember(c,inferred)
        return inferred
    }
    private fun matchUnnamedScanner(file:Candidate):Long? {
        // The original, known-working Test 5.1 has no conversation title.
        // Match only distinctive text at the quoted reply's exact minute.
        val scan=runCatching {
            context.contentResolver.openInputStream(file.uri)?.bufferedReader()?.use { JSONObject(it.readText()) }
        }.getOrNull()?:return null
        if(scan.optString("test") !in setOf("tangled-quotes-reactions-test5.1","tangled-quotes-reactions-test6","tangled-quotes-reactions-test7"))return null
        val items=scan.optJSONArray("quotes")?:return null
        val samples=mutableListOf<Pair<Long,String>>()
        for(i in 0 until items.length()) {
            val entry=items.optJSONObject(i)?:continue
            val time=parseHeader(entry.optString("reply_time"))?.first?:continue
            val body=entry.optString("reply_text").trim().replace(Regex("\\s+")," ")
            if(body.length>=8 && samples.none{it.first==time && it.second==body})samples.add(time to body)
        }
        // Test 6/7 also include reacted-to message text: this helps if the
        // scan contains very few quoted messages.
        val react=scan.optJSONArray("reactions")
        if(react!=null)for(i in 0 until react.length()) {
            val r=react.optJSONObject(i)?:continue
            val moment=parseHeader(r.optString("timestamp"))?.first?:continue
            val body=r.optString("message_text").trim().replace(Regex("\\s+")," ")
            if(body.length>=8 && samples.none{it.first==moment && it.second==body})samples.add(moment to body)
        }
        if(samples.isEmpty())return null
        val selected=if(samples.size<=20)samples else samples.take(10)+samples.takeLast(10)
        val ranked=db.chats().map { it.id to db.scannerQuoteEvidence(it.id,selected) }
            .filter { it.second>0 }.sortedByDescending { it.second }
        val first=ranked.firstOrNull()?:return null
        // Require at least two exact independent matches, and a unique winner.
        return first.first.takeIf { first.second>=2 && (ranked.getOrNull(1)?.second ?: 0)==0 }
    }

    fun list():List<Candidate> {
        val tree=folder() ?: return emptyList()
        val parent=DocumentsContract.getTreeDocumentId(tree)
        val children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,parent)
        val result=mutableListOf<Candidate>()
        val columns=arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE)
        context.contentResolver.query(children,columns,null,null,null)?.use {cursor->
            val idCol=cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameCol=cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val mimeCol=cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
            while(cursor.moveToNext()){
                val mime=cursor.getString(mimeCol)?:""
                if(mime==DocumentsContract.Document.MIME_TYPE_DIR)continue
                val name=cursor.getString(nameCol)?:continue
                val doc=DocumentsContract.buildDocumentUriUsingTree(tree,cursor.getString(idCol))
                val kind=when{
                    name.endsWith(".zip",true)->if(WebExportImporter.isWebZip(context,doc))"web" else "chat"
                    name.endsWith(".txt",true)->"chat"
                    name.endsWith(".json",true)->"quote"
                    else->continue
                }
                result.add(Candidate(name,doc,kind,normalise(name)))
            }
        }
        return result.sortedWith(compareBy<Candidate>{it.kind=="quote"}.thenBy{it.name}) // Chat ZIPs before quoted JSONs.
    }
    // Only the selected SAF folder and its Archive subfolder are touched.
    private data class Entry(val name:String,val uri:Uri,val mime:String)
    private fun children(parent:Uri):List<Entry> {
        val tree=folder() ?: return emptyList()
        val parentId=if(parent==tree)DocumentsContract.getTreeDocumentId(tree) else DocumentsContract.getDocumentId(parent)
        val childUri=DocumentsContract.buildChildDocumentsUriUsingTree(tree,parentId)
        val columns=arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE)
        val result=mutableListOf<Entry>()
        context.contentResolver.query(childUri,columns,null,null,null)?.use{c->
            while(c.moveToNext()){
                val id=c.getString(0);val name=c.getString(1)?:continue;val mime=c.getString(2)?:""
                result.add(Entry(name,DocumentsContract.buildDocumentUriUsingTree(tree,id),mime))
            }
        }
        return result
    }
    private fun archiveFolder():Uri {
        val tree=folder()?:error("No selected folder")
        val root=DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree))
        return children(tree).firstOrNull{it.name=="Archive" && it.mime==DocumentsContract.Document.MIME_TYPE_DIR}?.uri
            ?: DocumentsContract.createDocument(context.contentResolver,root,DocumentsContract.Document.MIME_TYPE_DIR,"Archive")
            ?: error("Cannot create Archive subfolder")
    }
    private fun safeName(chatName:String):String {
        val valid=chatName.replace(Regex("[\\/:*?\"<>|\\p{Cntrl}]"),"_").trim().trimEnd('.')
        return valid.take(100).ifBlank{"Conversation"}
    }
    private fun uniqueName(dir:Uri,base:String):String {
        val used=children(dir).map{it.name.lowercase(Locale.ROOT)}.toSet()
        if(base.lowercase(Locale.ROOT) !in used)return base
        val stem=base.substringBeforeLast('.',base);val ext=base.substringAfterLast('.',"").let{if(it.isBlank())"" else ".$it"}
        for(n in 1..9999){val candidate="$stem-$n$ext";if(candidate.lowercase(Locale.ROOT) !in used)return candidate}
        error("Too many files with the same name")
    }
    private fun copyVerified(source:Uri,destination:Uri,filename:String):Uri {
        val created=DocumentsContract.createDocument(context.contentResolver,destination,"application/zip",filename)?:error("Cannot create $filename")
        try {
            val original=MessageDigest.getInstance("SHA-256")
            context.contentResolver.openInputStream(source)?.use{input->
                context.contentResolver.openOutputStream(created,"w")?.use{out->
                    val buffer=ByteArray(65536)
                    while(true){val n=input.read(buffer);if(n<0)break;if(n>0){original.update(buffer,0,n);out.write(buffer,0,n)}}
                    out.flush()
                }?:error("Cannot write ZIP")
            }?:error("Cannot read ZIP")
            require(digest(created)==original.digest().joinToString(""){ "%02x".format(it.toInt() and 255) }){"ZIP verification failed"}
            return created
        }catch(e:Exception){runCatching{DocumentsContract.deleteDocument(context.contentResolver,created)};throw e}
    }
    private fun archiveName(name:String):String {
        val date=java.text.SimpleDateFormat("yyyy-MM-dd HHmmss-SSS",Locale.UK).format(java.util.Date())
        return "$name ($date).zip"
    }
    // A newer WhatsApp export may safely replace an older ZIP only when the
    // older message stream is an exact prefix AND every old media entry occurs
    // byte-for-byte in the new ZIP. Never infer containment from filenames,
    // timestamps, overlapping messages or a successful DB deduplication alone.
    private fun mediaHashes(uri:Uri):Map<String,String> {
        val result=LinkedHashMap<String,String>()
        val buffer=ByteArray(65536)
        java.util.zip.ZipInputStream(context.contentResolver.openInputStream(uri)
            ?: error("Cannot open ZIP for media verification")).use {zip->
            while(true) {
                val entry=zip.nextEntry?:break
                if(!entry.isDirectory && !entry.name.endsWith(".txt",true)) {
                    // Preserve internal paths; duplicate entry names are ambiguous.
                    val name=entry.name.replace('\\','/')
                    require(name.isNotBlank() && !result.containsKey(name)) {"Duplicate media path in ZIP"}
                    val md=MessageDigest.getInstance("SHA-256")
                    while(true) {val count=zip.read(buffer);if(count<0)break;if(count>0)md.update(buffer,0,count)}
                    result[name]=md.digest().joinToString(""){ "%02x".format(it.toInt() and 255) }
                }
                zip.closeEntry()
            }
        }
        return result
    }
    private fun isVerifiedContinuation(older:Uri,newer:Uri):Boolean {
        return runCatching {
            val oldMessages=archive.inspectChat(older)
            val newMessages=archive.inspectChat(newer)
            if(oldMessages.isEmpty() || oldMessages.size>newMessages.size)return@runCatching false
            for(i in oldMessages.indices) {
                val a=oldMessages[i];val b=newMessages[i]
                if(a.time!=b.time || a.sender!=b.sender || a.body!=b.body ||
                    a.occurrence!=b.occurrence || a.fingerprint!=b.fingerprint) return@runCatching false
            }
            val oldMedia=mediaHashes(older)
            val newMedia=mediaHashes(newer)
            oldMedia.all{(path,hash)->newMedia[path]==hash}
        }.getOrDefault(false)
    }
    // The incoming file has already been fully imported successfully. Ensure that
    // an older or partially overlapping export never displaces a better current ZIP.
    private fun storeCurrentZip(file:Candidate,chatId:Long):String? {
        if(!file.name.endsWith(".zip",true))return null
        require(hasWriteAccess()){ "Reselect watched folder with write access to organise ZIPs" }
        val tree=folder()?:return null
        val root=DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree))
        val name=safeName(db.chats().firstOrNull{it.id==chatId}?.name?:return null)
        val target="$name.zip"
        val existing=children(root).firstOrNull{it.name.equals(target,true)}
        if(existing!=null && existing.uri==file.uri)return null
        if(existing!=null){
            val owner=db.sourceOwner("chat",normalise(existing.name))
            require(owner==null || owner==chatId){"Canonical ZIP is associated with another conversation"}
            if(digest(existing.uri)==digest(file.uri) || isVerifiedContinuation(file.uri,existing.uri)){
                // Identical or older incoming export: never replace the fuller current one.
                require(DocumentsContract.deleteDocument(context.contentResolver,file.uri)) {
                    "Could not delete verified redundant export ${file.name}"
                }
                return null
            }
            if(isVerifiedContinuation(existing.uri,file.uri)) {
                // Stage and SHA-256 verify the new ZIP before touching either source.
                val stage=copyVerified(file.uri,root,uniqueName(root,"${name}-incoming-verified.zip"))
                var held:Uri?=null
                try {
                    val holdName=uniqueName(root,"${name}-previous-verified.zip")
                    held=DocumentsContract.renameDocument(context.contentResolver,existing.uri,holdName)
                        ?:error("Cannot safeguard old canonical ZIP")
                    require(DocumentsContract.renameDocument(context.contentResolver,stage,target)!=null) {
                        "Cannot promote verified replacement ZIP"
                    }
                }catch(e:Exception){
                    // The old archive remains available if promotion fails.
                    if(held!=null)runCatching{DocumentsContract.renameDocument(context.contentResolver,held,target)}
                    runCatching{DocumentsContract.deleteDocument(context.contentResolver,stage)}
                    throw e
                }
                // Delete only after a verified replacement has become canonical.
                require(DocumentsContract.deleteDocument(context.contentResolver,held!!)) {
                    "New ZIP installed; redundant old ZIP retained as ${holdNameForInfo(name)}"
                }
                require(DocumentsContract.deleteDocument(context.contentResolver,file.uri)) {
                    "New ZIP installed; redundant incoming ZIP still needs removal"
                }
                return null
            }
        }
        // An older partial export with unique content must never replace a
        // newer current export. Keep its media and messages in Archive instead.
        if(existing!=null) {
            val currentMessages=archive.inspectChat(existing.uri)
            val incomingMessages=archive.inspectChat(file.uri)
            val currentEnd=currentMessages.maxOfOrNull{it.time} ?: Long.MIN_VALUE
            val incomingEnd=incomingMessages.maxOfOrNull{it.time} ?: Long.MIN_VALUE
            if(incomingEnd<currentEnd || (incomingEnd==currentEnd && incomingMessages.size<=currentMessages.size)) {
                val archiveDir=archiveFolder()
                copyVerified(file.uri,archiveDir,uniqueName(archiveDir,archiveName(file.name.removeSuffix(".zip"))))
                require(DocumentsContract.deleteDocument(context.contentResolver,file.uri)) {
                    "Older non-redundant ZIP safely archived, but source could not be removed"
                }
                return null
            }
        }
        // Not proven redundant: preserve the older current ZIP in Archive.
        val archiveDir=archiveFolder()
        if(existing!=null)copyVerified(existing.uri,archiveDir,uniqueName(archiveDir,archiveName(name)))
        val staged=copyVerified(file.uri,root,uniqueName(root,"${name}-incoming-verified.zip"))
        val held=if(existing!=null){
            DocumentsContract.renameDocument(context.contentResolver,existing.uri,
                uniqueName(root,"${name}-previous-verified.zip"))
                ?: error("Could not safeguard previous canonical ZIP")
        }else null
        try {
            require(DocumentsContract.renameDocument(context.contentResolver,staged,target)!=null) {
                "Could not install new canonical ZIP"
            }
        }catch(e:Exception){
            if(held!=null)runCatching{DocumentsContract.renameDocument(context.contentResolver,held,target)}
            runCatching{DocumentsContract.deleteDocument(context.contentResolver,staged)}
            throw e
        }
        if(held!=null)runCatching{DocumentsContract.deleteDocument(context.contentResolver,held)}
        if(file.uri!=existing?.uri)runCatching{DocumentsContract.deleteDocument(context.contentResolver,file.uri)}
        return null
    }
    private fun holdNameForInfo(name:String)="$name-previous-verified.zip"
    // ZIP deletion choices only operate on source ZIPs with a saved association
    // to this exact chat. Scanner JSON and unknown/shared ZIPs are never touched.
    fun associatedCurrentZips(chatId:Long):List<Candidate> = vault.list()
        .filter{it.kind=="chat" && it.name.endsWith(".zip",true) && it.chatId==chatId}
        .map{Candidate(it.name,vault.uri(it),it.kind,normalise(it.name))}
    fun handleChatDeleteZips(chatId:Long,archive:Boolean) {
        // Vault-first archive means retain privately but remove the chat association.
        // Never recreate the public Archive directory.
        for(item in vault.list().filter{it.kind=="chat" && it.chatId==chatId}) {
            if(archive)vault.setChat(item,-1L) else vault.remove(item)
        }
    }
    fun archiveCurrentForUndo(chatName:String) {
        // Vault-first: source stays private during undo. No public Archive folder.
    }
    fun organiseMergedChat(oldName:String,destinationId:Long):String? {
        // Merged conversation source files live entirely in the private vault.
        for(item in vault.list().filter{it.kind=="chat" && it.chatId>0}) {
            if(db.sourceOwner("chat",normalise(item.name))==destinationId && item.chatId!=destinationId) {
                vault.setChat(item,destinationId)
            }
        }
        return null
    }
    fun renameStoredFiles(chatId:Long,oldName:String,newName:String):String? {
        // Private files retain their original source names for future matching.
        // Conversation display names and source association aliases are stored separately.
        return null
    }
    private fun digest(uri:Uri):String {
        val md=MessageDigest.getInstance("SHA-256")
        context.contentResolver.openInputStream(uri)?.use{input->
            val buffer=ByteArray(65536)
            while(true){val n=input.read(buffer);if(n<0)break;if(n>0)md.update(buffer,0,n)}
        } ?: error("Cannot read file")
        return md.digest().joinToString(""){ "%02x".format(it.toInt() and 255) }
    }
    data class ConsolidationPreview(val fileCount:Int,val messageCount:Int,val mediaCount:Int,val originalBytes:Long)
    data class ConsolidationResult(val fileCount:Int,val messageCount:Int,val mediaCount:Int,val deleted:Int,val savedBytes:Long)

    // Only the explicitly selected folder is inspected. This method is intentionally
    // conservative: ambiguous media filename collisions abort rather than risk
    // replacing an attachment with unrelated content.
    private fun sourceZips(chatId:Long,chatName:String):List<Entry> = vault.list()
        .filter { it.chatId==chatId && it.kind=="chat" && it.name.endsWith(".zip",true) }
        .map { Entry(it.name,vault.uri(it),"application/zip") }
    fun previewConsolidation(chatId:Long):ConsolidationPreview {
        val name=db.chats().firstOrNull{it.id==chatId}?.name?:error("Conversation no longer exists")
        val files=sourceZips(chatId,name)
        require(files.isNotEmpty()){"No current or archived ZIPs found for $name"}
        val ids=HashSet<String>()
        var media=0
        var bytes=0L
        for(file in files){
            context.contentResolver.openFileDescriptor(file.uri,"r")?.use{bytes+=it.statSize.coerceAtLeast(0)}
            archive.inspectChat(file.uri).forEach{ids.add("${it.fingerprint}:${it.occurrence}")}
            java.util.zip.ZipInputStream(context.contentResolver.openInputStream(file.uri) ?: error("Cannot open ${file.name}")).use{zip->
                while(true){val entry=zip.nextEntry?:break;if(!entry.isDirectory&&!entry.name.endsWith(".txt",true))media++;zip.closeEntry()}
            }
        }
        return ConsolidationPreview(files.size,ids.size,media,bytes)
    }
    fun consolidate(chatId:Long,deleteOriginals:Boolean):ConsolidationResult {
        require(hasWriteAccess()){"Reselect your Auto Sync folder to grant write access"}
        require(busy.compareAndSet(false,true)){"Auto Sync is running; try again after it finishes"}
        val temporary=java.io.File(context.cacheDir,"consolidate_${java.util.UUID.randomUUID()}").apply{mkdirs()}
        try {
            val name=db.chats().firstOrNull{it.id==chatId}?.name?:error("Conversation no longer exists")
            val files=sourceZips(chatId,name)
            require(files.isNotEmpty()){"No ZIP archives found for $name"}
            val unique=LinkedHashMap<String,Message>()
            // Original export names are preserved wherever possible; hash-equivalent
            // media with different names are later consolidated with updated references.
            val byName=LinkedHashMap<String,Pair<String,java.io.File>>()
            val byHash=HashMap<String,String>()
            val renames=HashMap<String,String>()
            var originalBytes=0L
            for(file in files){
                context.contentResolver.openFileDescriptor(file.uri,"r")?.use{originalBytes+=it.statSize.coerceAtLeast(0)}
                archive.inspectChat(file.uri).forEach{msg->unique.putIfAbsent("${msg.fingerprint}:${msg.occurrence}",msg)}
                java.util.zip.ZipInputStream(context.contentResolver.openInputStream(file.uri) ?: error("Cannot open ${file.name}")).use{zip->
                    while(true){
                        val entry=zip.nextEntry?:break
                        val base=entry.name.replace('\\','/').substringAfterLast('/')
                        if(entry.isDirectory || base.isEmpty() || base.endsWith(".txt",true)) {zip.closeEntry();continue}
                        val temp=java.io.File(temporary,"media_${java.util.UUID.randomUUID()}")
                        val md=MessageDigest.getInstance("SHA-256")
                        temp.outputStream().use{output->val buf=ByteArray(65536);while(true){val n=zip.read(buf);if(n<0)break;if(n>0){md.update(buf,0,n);output.write(buf,0,n)}}}
                        val hash=md.digest().joinToString(""){ "%02x".format(it.toInt() and 255) }
                        val existingName=byName[base]
                        if(existingName!=null && existingName.first!=hash){
                            temp.delete()
                            error("Two different media files share the filename '$base'. Consolidation stopped safely; originals untouched.")
                        }
                        if(existingName!=null){temp.delete();zip.closeEntry();continue}
                        val previousName=byHash[hash]
                        if(previousName!=null){renames[base]=previousName;temp.delete()}
                        else {byName[base]=hash to temp;byHash[hash]=base}
                        zip.closeEntry()
                    }
                }
            }
            val sorted=unique.values.sortedWith(compareBy<Message>{it.time}.thenBy{it.occurrence})
            val formatter=SimpleDateFormat("dd/MM/yyyy, HH:mm",Locale.UK)
            val transcript=buildString {
                for(msg in sorted){
                    val attachment=WhatsAppParser.attachmentName(msg.body)
                    val body=if(attachment!=null && renames.containsKey(attachment))msg.body.replace(attachment,renames.getValue(attachment)) else msg.body
                    append(formatter.format(java.util.Date(msg.time))).append(" - ")
                    if(msg.sender.isNotBlank() && msg.sender!="System")append(msg.sender).append(": ")
                    append(body).append('\n')
                }
            }
            val reparsed=WhatsAppParser.parse(transcript)
            require(reparsed.size==sorted.size){"Transcript verification failed; originals untouched"}
            val referenced=reparsed.mapNotNull{WhatsAppParser.attachmentName(it.body)}.toSet()
            require(referenced.all{it in byName}){"Some referenced media are missing; originals untouched"}
            val staged=java.io.File(temporary,"merged.zip")
            java.util.zip.ZipOutputStream(staged.outputStream().buffered()).use{zip->
                zip.putNextEntry(java.util.zip.ZipEntry("_chat.txt"));zip.write(transcript.toByteArray(Charsets.UTF_8));zip.closeEntry()
                for((filename,pair) in byName){
                    if(filename !in referenced)continue
                    zip.putNextEntry(java.util.zip.ZipEntry(filename))
                    pair.second.inputStream().use{it.copyTo(zip)}
                    zip.closeEntry()
                }
            }
            // Verify the finished ZIP by round-tripping its transcript and attachment list.
            var verifiedTranscript=false
            val verifiedFiles=HashSet<String>()
            java.util.zip.ZipInputStream(staged.inputStream().buffered()).use{zip->
                while(true){val e=zip.nextEntry?:break
                    if(e.name=="_chat.txt"){
                        val text=zip.readBytes().toString(Charsets.UTF_8)
                        verifiedTranscript=WhatsAppParser.parse(text).size==sorted.size
                    }else verifiedFiles.add(e.name)
                    zip.closeEntry()
                }
            }
            require(verifiedTranscript && referenced.all{it in verifiedFiles}){"ZIP verification failed; originals untouched"}
            val newVaultFile=vault.addGenerated(staged,"${safeName(name)}-consolidated.zip","chat",chatId)
            // The verified merged ZIP is now private; never create public Archive files.
            var deleted=0
            if(deleteOriginals){
                for(file in files) {
                    val previous=vault.list().firstOrNull{vault.uri(it)==file.uri}?:continue
                    if(previous.id==newVaultFile.id)continue
                    vault.remove(previous)
                    deleted++
                }
            }
            val outputBytes=staged.length()
            return ConsolidationResult(files.size,sorted.size,referenced.size,deleted,originalBytes-outputBytes)
        }finally{temporary.deleteRecursively();busy.set(false)}
    }
    private fun digestFile(file:java.io.File):String {
        val md=MessageDigest.getInstance("SHA-256")
        file.inputStream().use{input->val buf=ByteArray(65536);while(true){val n=input.read(buf);if(n<0)break;if(n>0)md.update(buf,0,n)}}
        return md.digest().joinToString(""){ "%02x".format(it.toInt() and 255) }
    }

    // Migrate only historically completed ZIPs from the public Archive folder.
    // The exact SHA-256 must have a completed import record in the database.
    private fun secureCompletedArchiveZips(errors:MutableList<String>) {
        if(!hasWriteAccess())return
        val tree=folder()?:return
        val dir=children(tree).firstOrNull{it.name=="Archive" && it.mime==DocumentsContract.Document.MIME_TYPE_DIR}?:return
        for(file in children(dir.uri).filter{it.name.endsWith(".zip",true)}) {
            try {
                val hash=digest(file.uri)
                val batch=db.autoBatch(hash)?:continue
                if(batch.status!="completed" || !isKnownChat(batch.chatId))continue
                vault.seal(file.uri,file.name,"chat",batch.chatId,hash)
            }catch(e:Exception){errors.add("${file.name}: archive privacy migration needs review: ${e.message}")}
        }
    }

    /** Vault-first sync. The public folder and legacy Archive are input inboxes only.
     * Every source moves to the private store before any parsing or chat creation.
     * Failed/unmatched sources remain in the private vault for retry/relink. */
    private fun importIntoVault(errors:MutableList<String>):Int {
        val folder=folder()?:return 0
        if(!hasWriteAccess()) {
            errors.add("Reselect Auto Sync folder with write access before files can be secured")
            return 0
        }
        val sources=mutableListOf<Candidate>()
        sources.addAll(list())
        val archiveDir=children(folder).firstOrNull{
            it.name.equals("Archive",true) && it.mime==DocumentsContract.Document.MIME_TYPE_DIR
        }
        if(archiveDir!=null)for(entry in children(archiveDir.uri)) {
            val kind=when {
                entry.name.endsWith(".zip",true)->if(WebExportImporter.isWebZip(context,entry.uri))"web" else "chat"
                entry.name.endsWith(".txt",true)->"chat"
                entry.name.endsWith(".json",true)->"quote"
                else->null
            } ?:continue
            sources.add(Candidate(entry.name,entry.uri,kind,normalise(entry.name)))
        }
        var staged=0
        for(source in sources)try {
            vault.ingest(source.uri,source.name,source.kind)
            staged++
        }catch(e:Exception){
            errors.add("${source.name}: could not secure source: ${e.message}")
        }
        return staged
    }
    fun vaultPending():List<Candidate> = vault.list().filter { item ->
        val batch=db.autoBatch(item.hash)
        item.chatId<0 || batch==null || batch.status=="waiting" || batch.status=="failed"
    }.map { Candidate(it.name,vault.uri(it),it.kind,normalise(it.name)) }

    private fun pruneVerifiedVaultZips(chatId:Long,errors:MutableList<String>) {
        val same=vault.list().filter{it.kind=="chat" && it.name.endsWith(".zip",true) && it.chatId==chatId && db.autoBatch(it.hash)?.status=="completed"}
        if(same.size<2)return
        for(older in same) {
            val olderUri=vault.uri(older)
            val newer=same.firstOrNull{candidate ->
                candidate.id!=older.id && runCatching{
                    val oldMessages=archive.inspectChat(olderUri)
                    val newMessages=archive.inspectChat(vault.uri(candidate))
                    oldMessages.size<newMessages.size && isVerifiedContinuation(olderUri,vault.uri(candidate))
                }.getOrDefault(false)
            }
            if(newer!=null)runCatching{vault.remove(older)}.onFailure{
                errors.add("${older.name}: redundant private ZIP could not be removed: ${it.message}")
            }
        }
    }

    // Check previously retained archives as well as newly imported ones. Pairs
    // are memoised by content hashes, so startup doesn't repeatedly unzip a
    // large conversation. A failed check never deletes a source.
    fun pruneAllVerifiedVaultZips():List<String> {
        val errors=mutableListOf<String>()
        val groups=vault.list().filter { it.kind=="chat" && it.chatId>0 &&
            it.name.endsWith(".zip",true) && db.autoBatch(it.hash)?.status=="completed" }
            .groupBy{it.chatId}
        for((_,items) in groups) {
            if(items.size<2)continue
            val sorted=items.sortedByDescending{it.bytes}
            val remove=mutableSetOf<String>()
            for(smaller in sorted.asReversed()) {
                if(smaller.id in remove)continue
                for(larger in sorted) {
                    if(larger.id==smaller.id || larger.id in remove || larger.bytes<=smaller.bytes)continue
                    val cache="zip_contains_${larger.hash}_${smaller.hash}"
                    val known=prefs.getString(cache,null)
                    val contains=when(known){
                        "yes"->true
                        "no"->false
                        else->runCatching{
                            val left=archive.inspectChat(vault.uri(smaller)).size
                            val right=archive.inspectChat(vault.uri(larger)).size
                            left<right && isVerifiedContinuation(vault.uri(smaller),vault.uri(larger))
                        }.getOrElse{errors.add("ZIP comparison skipped: ${it.message}");false}.also{
                            if(errors.isEmpty())prefs.edit().putString(cache,if(it)"yes" else "no").apply()
                        }
                    }
                    if(contains){
                        runCatching{vault.remove(smaller)}.onSuccess{remove.add(smaller.id)}
                            .onFailure{errors.add("Could not remove redundant ${smaller.name}: ${it.message}")}
                        break
                    }
                }
            }
        }
        return errors
    }
    fun scan(force:Boolean=false):ScanReport {
        if(!enabled() || !busy.compareAndSet(false,true))return ScanReport(0,0,0,emptyList(),emptyList())
        val awaiting=mutableListOf<Candidate>();val errors=mutableListOf<String>()
        var scanned=0;var imported=0;var skipped=0;var changedQuotes=false
        try {
            syncProgress=SyncProgress("", "Copying incoming files to Private Files", 0, 0)
            importIntoVault(errors)
            // Process ZIP/TXT before JSON so reaction matching can see new messages.
            val staged=vault.list().sortedWith(compareBy<SyncedVault.Item>{when(it.kind){"chat"->0;"quote"->1;else->2}}.thenBy{it.name})
            for(item in staged){
                scanned++
                syncProgress=SyncProgress(item.name,"Checking source and conversation",scanned,staged.size)
                try {
                    val file=Candidate(item.name,vault.uri(item),item.kind,normalise(item.name))
                    var id=if(item.chatId>0 && isKnownChat(item.chatId))item.chatId else assignedChat(file)
                    val hash=item.hash
                    val old=db.autoBatch(hash)
                    if(id==null && item.kind=="chat" && old!=null && isKnownChat(old.chatId)) {
                        id=old.chatId;remember(file,id)
                    }
                    if(id==null && item.kind=="chat") {
                        require(archive.inspectChat(file.uri).isNotEmpty()) {"Not a WhatsApp chat export"}
                        val original=suggestedChatName(file.name)
                        val existing=db.chats().map{it.name.lowercase(Locale.ROOT)}.toSet()
                        var proposed=original.ifBlank{"WhatsApp Chat"};var n=2
                        while(proposed.lowercase(Locale.ROOT) in existing){proposed="$original ($n)";n++}
                        id=db.createAutoChat(proposed)
                        remember(file,id)
                    }
                    if(id==null){awaiting.add(file);continue}
                    if(item.chatId!=id)vault.setChat(item,id)
                    if(!force && old!=null && old.status=="completed" && !(item.kind=="web" && changedQuotes)) {skipped++;continue}
                    // A Web ZIP can be successfully processed despite unresolved individual quotes.
                    // Older releases incorrectly called that state "waiting" and kept reimporting
                    // the same large file on every app start. Retry those only when message sources
                    // have changed, or the user explicitly chooses Verify All Sources.
                    if(!force && old?.status=="waiting" && file.kind=="web") {
                        val signature="${db.latestArchivedMessageTime(id)?:0L}:${db.chats().firstOrNull{it.id==id}?.count?:0}"
                        if(prefs.getString("web_wait_$hash","")==signature){skipped++;continue}
                    }
                    if(!force && old?.status=="waiting" && file.kind=="quote") {
                        val signature="${db.latestArchivedMessageTime(id)?:0L}:${db.chats().firstOrNull{it.id==id}?.count?:0}"
                        if(prefs.getString("wait_$hash","")==signature){skipped++;continue}
                    }
                    val batch=if(old==null)db.addAutoBatch(hash,file.name,id,file.kind)else old.id
                    try {
                        if(file.kind=="chat") {
                            syncProgress=SyncProgress(item.name,"Importing messages and media",scanned,staged.size)
                            val chat=db.chats().firstOrNull{it.id==id}?:error("Conversation missing")
                            val (added,dupes)=archive.importChat(file.uri,chat.name,batch)
                            db.retryReactionMatches(id)
                            db.finishAutoBatch(batch,added,dupes)
                            imported+=added
                            // Cleanup is performed once after processing all sources.
                        }else if(file.kind=="web") {
                            syncProgress=SyncProgress(item.name,"Verifying times and quoted messages",scanned,staged.size)
                            val result=WebExportImporter(context,db).import(file.uri,id,hash,batch){p->
                                syncProgress=SyncProgress(item.name,p.stage,scanned,staged.size,p.done,p.total)
                            }
                            // Unresolved/ambiguous quotes are per-record results, not file failures.
                            // A successful Web ZIP import must be marked complete and skipped on
                            // subsequent automatic passes. Pending counts remain in batch details.
                            db.finishAutoBatch(batch,result.seconds,result.pending+result.conflicts,"completed")
                            prefs.edit().putString("web_wait_$hash","${db.latestArchivedMessageTime(id)?:0L}:${db.chats().firstOrNull{it.id==id}?.count?:0}").apply()
                            imported+=result.added+result.corrected
                        }else {
                            syncProgress=SyncProgress(item.name,"Matching quotes and reactions",scanned,staged.size)
                            saveUndoCheckpoint(batch,id)
                            val stats=importQuotes(file.uri,id,batch)
                            changedQuotes=true
                            db.finishAutoBatch(batch,stats.first,stats.second,"completed")
                            prefs.edit().putString("wait_$hash","${db.latestArchivedMessageTime(id)?:0L}:${db.chats().firstOrNull{it.id==id}?.count?:0}").apply()
                            imported+=stats.first
                        }
                    }catch(e:Exception){db.finishAutoBatch(batch,0,0,"failed");throw e}
                }catch(e:Exception){errors.add("${item.name}: ${e.message?:"Import failed"}")}
            }
            // Forced Sync Now also repairs PREVIOUSLY SAVED reaction rows, even
            // if the original JSON was removed from Private Files. This is a
            // non-destructive retry; clean QAR rebuild remains source-only.
            if(force) {
                syncProgress=SyncProgress("","Retrying saved reaction matches",scanned,staged.size)
                for(chat in db.chats()) db.retryReactionMatches(chat.id)
            }
            syncProgress=SyncProgress("","Checking redundant conversation ZIPs",scanned,staged.size)
            errors.addAll(pruneAllVerifiedVaultZips())
        }catch(e:Exception){errors.add(e.message?:"Auto Sync failed")}
        finally{syncProgress=null;busy.set(false)}
        return ScanReport(scanned,imported,skipped,awaiting,errors)
    }
    /** A true global replacement, not a merge: only the QAR JSON files currently
     * present in Private Files are authoritative. Deleted files are intentionally
     * excluded. An empty vault legitimately produces zero QAR in every chat. */
    fun rebuildQar():String {
        require(busy.compareAndSet(false,true)){"Another sync is running"}
        try {
            // Validate ALL surviving private JSONs before clearing any data.
            val sources=vault.list().filter{it.kind=="quote"}.sortedBy{it.name}
            val ready=mutableListOf<Pair<SyncedVault.Item,Long>>()
            for(item in sources) {
                val candidate=Candidate(item.name,vault.uri(item),item.kind,normalise(item.name))
                val id=(if(item.chatId>0 && isKnownChat(item.chatId))item.chatId else assignedChat(candidate))
                    ?: error("Cannot identify the chat for ${item.name}. Assign it before rebuilding; nothing changed.")
                // Verify bytes and JSON data without modifying the source file.
                val content=context.contentResolver.openInputStream(candidate.uri)?.bufferedReader()?.use { reader ->
                    val value=reader.readText();require(value.length<=20_000_000){"Oversized QAR source: ${item.name}"};value
                }?:error("Cannot read private QAR file: ${item.name}")
                val json=JSONObject(content)
                val test=json.optString("test") in setOf("tangled-quotes-reactions-test5.1","tangled-quotes-reactions-test6","tangled-quotes-reactions-test7")
                require(test || json.optInt("version") in 1..2){"Unsupported QAR JSON: ${item.name}"}
                require(if(test) json.optJSONArray("quotes")!=null else json.optJSONArray("replies")!=null){"Missing quote array: ${item.name}"}
                ready.add(item to id)
            }
            // Clear + complete reimport are one atomic database operation. On error,
            // SQLite restores ALL old QAR records rather than leaving a partial wipe.
            db.atomicQarRebuild {
                db.clearAllQarForRebuild()
                for((item,id) in ready) {
                    val batch=db.addAutoBatch(item.hash,item.name,id,"quote")
                    val stats=importQuotes(vault.uri(item),id,batch)
                    db.finishAutoBatch(batch,stats.first,stats.second,"completed")
                }
                importPrivateWebIntoFreshArchive()
            }
            val total=db.chats().sumOf{db.reactionCounts(it.id).first}
            val pending=db.chats().sumOf{db.reactionCounts(it.id).second}
            val linked=db.chats().sumOf{db.countReplyLinks(it.id)}
            return "Clean QAR rebuild complete across all chats. Sources remaining in Private Files: ${ready.size}. " +
                "Linked quotes: $linked; reactions: $total saved, ${total-pending} linked, $pending pending. " +
                "Deleted private sources were excluded."
        }finally{busy.set(false)}
    }

    /** Reconcile retained Web ZIPs after conversation messages have been imported. */
    fun importPrivateWebIntoFreshArchive():String {
        var count=0;var quotes=0;var enriched=0;var pending=0
        for(item in vault.list().filter{it.kind=="web"}.sortedBy{it.name}) {
            val candidate=Candidate(item.name,vault.uri(item),"web",normalise(item.name))
            val id=assignedChat(candidate) ?: error("Cannot identify chat for Web export ${item.name}")
            val batch=db.addAutoBatch(item.hash,item.name,id,"web")
            val r=WebExportImporter(context,db).import(vault.uri(item),id,item.hash,batch)
            db.finishAutoBatch(batch,r.seconds,r.conflicts+r.pending,"completed")
            count++;quotes+=r.added+r.corrected;enriched+=r.seconds;pending+=r.pending+r.conflicts
        }
        return "$count Web ZIPs, $enriched verified seconds, $quotes added/corrected quotes, $pending awaiting review"
    }

    /** Import QAR exclusively from the surviving private vault sources into a NEW,
     * empty staging archive. Never reuse old chat IDs or stale association preferences.
     * Fail closed on ambiguous or missing conversation names. */
    fun importPrivateQarIntoFreshArchive():String {
        require(busy.compareAndSet(false,true)) { "Another sync is running" }
        try {
            var files=0
            var quotes=0
            val surviving=vault.list().filter{it.kind=="quote"}.sortedBy{it.name}
            for(item in surviving) {
                val candidate=Candidate(item.name,vault.uri(item),item.kind,normalise(item.name))
                val content=context.contentResolver.openInputStream(candidate.uri)?.bufferedReader()?.use{it.readText()}
                    ?: error("Cannot read retained QAR source ${item.name}")
                require(content.length<=20_000_000) { "QAR source is too large: ${item.name}" }
                val json=JSONObject(content)
                val explicit=json.optString("source_chat_name").ifBlank{json.optString("chat_name")}.trim()
                val stem=item.name.substringBeforeLast('.')
                val fromFilename=Regex("^(.+)-\\d{12,17}$").matchEntire(stem)?.groupValues?.get(1)
                    ?: Regex("(?i)^(.+?)-quoted-(?:history|update|replies)$").matchEntire(stem)?.groupValues?.get(1)
                val wanted=explicit.ifBlank{fromFilename.orEmpty()}.trim()
                fun canon(v:String)=v.trim().lowercase(Locale.ROOT)
                    .replace(Regex("(?i)^whatsapp\\s+chat\\s+(?:with\\s+|[-–]\\s*)"),"")
                val matches=if(wanted.isNotBlank())db.chats().filter{canon(it.name)==canon(wanted)} else emptyList()
                require(matches.size==1) { "Cannot uniquely match private QAR file ${item.name} to a rebuilt conversation; rebuild cancelled" }
                val chat=matches.single()
                val batch=db.addAutoBatch(item.hash,item.name,chat.id,"quote")
                val result=importQuotes(candidate.uri,chat.id,batch)
                db.finishAutoBatch(batch,result.first,result.second,if(result.third)"completed" else "waiting")
                files++;quotes+=result.first
            }
            val counts=db.chats().sumOf{db.reactionCounts(it.id).first}
            val pending=db.chats().sumOf{db.reactionCounts(it.id).second}
            return "$files QAR source(s), $quotes linked quotes, $counts reactions ($pending awaiting matches)"
        } finally {busy.set(false)}
    }

    private fun saveUndoCheckpoint(batchId:Long,chatId:Long) {
        val history=db.historyResume(chatId)
        val state=JSONObject().put("chat",chatId).put("web",db.webCheckpoint(chatId))
            .put("history",history!=null)
            .put("start",history?.first.orEmpty()).put("oldest",history?.second.orEmpty())
            .put("oldest_time",db.historyResumeTime(chatId))
        val key="undo_checkpoint_$batchId"
        if(!prefs.contains(key))prefs.edit().putString(key,state.toString()).apply()
    }
    fun undoBatch(batchId:Long):String {
        val result=db.undoAutoBatch(batchId)
        if(!result.startsWith("Undid "))return result
        val key="undo_checkpoint_$batchId"
        val snapshot=prefs.getString(key,null)
        if(snapshot!=null) {
            val state=JSONObject(snapshot);val id=state.getLong("chat")
            db.setWebCheckpoint(id,state.optString("web"))
            if(state.optBoolean("history"))db.saveHistoryResumeTime(id,state.optString("start"),state.optString("oldest"),state.optString("oldest_time"))
            else db.clearHistoryResume(id)
            prefs.edit().remove(key).apply()
            return "$result Previous quoted-message scan checkpoints restored."
        }
        return result
    }

    /** Earliest/latest successfully synced quote or reaction for this automatic batch.
     *  These are content markers, not safe skip-ahead scanner checkpoints. */
    fun syncedItemRange(batchId:Long):String {
        val early=prefs.getLong("sync_first_$batchId",-1L)
        val late=prefs.getLong("sync_last_$batchId",-1L)
        if(early<0 || late<0)return "No dated quote or reaction synced in this batch"
        val fmt=SimpleDateFormat("d MMM yyyy HH:mm",Locale.UK)
        return "Earliest synced quote/reaction: ${fmt.format(java.util.Date(early))}\n"+
               "Latest synced quote/reaction: ${fmt.format(java.util.Date(late))}"
    }
    fun batchBreakdown(batchId:Long):String {
        val quotes=prefs.getInt("quote_detected_$batchId",-1)
        if(quotes<0)return "Detailed counts unavailable for this older sync"
        return "Quotes: $quotes detected · ${prefs.getInt("quote_added_$batchId",0)} newly linked\n"+
            "Reactions: ${prefs.getInt("reaction_detected_$batchId",0)} detected · ${prefs.getInt("reaction_added_$batchId",0)} newly saved\n"+
            "Reactions awaiting an exact message match: ${prefs.getInt("reaction_pending_$batchId",0)} (chat total at time of sync)"
    }
    private fun parseHeader(value:String,compact:Boolean=false):Pair<Long,String>? {
        val m=Regex("""^\[([^]]+)]\s*(.*?):\s*$""").find(value) ?: return null
        val formatter=if(compact) SimpleDateFormat("h:mm a, M/d/yyyy",Locale.US).apply{isLenient=false} else dateParser
        val time=try {formatter.parse(m.groupValues[1])?.time}catch(_:Exception){null} ?: return null
        return time to m.groupValues[2].trim()
    }
    private fun importQuotes(uri:Uri,chatId:Long,batchId:Long):Triple<Int,Int,Boolean> {
        val content=context.contentResolver.openInputStream(uri)?.bufferedReader()?.use{reader->
            val s=StringBuilder();val buffer=CharArray(16384)
            while(true){val n=reader.read(buffer);if(n<0)break;s.append(buffer,0,n);require(s.length<=20_000_000){"JSON too large"}}
            s.toString()
        } ?: error("Cannot read JSON")
        val json=JSONObject(content)
        val test51=json.optString("test") in setOf("tangled-quotes-reactions-test5.1","tangled-quotes-reactions-test6","tangled-quotes-reactions-test7")
        require(test51 || json.optInt("version") in 1..2){"Unsupported quoted-message JSON"}
        val replies=if(test51)json.getJSONArray("quotes") else json.getJSONArray("replies")
        val reactionRows=json.optJSONArray("reactions")
        val quotesDetected=replies.length()
        var reactionsDetected=0
        var newlyAddedReactions=0
        var storedReactions=0
        var earliestSynced:Long?=null
        var latestSynced:Long?=null
        fun markSynced(time:Long?) {
            if(time==null)return
            earliestSynced=earliestSynced?.let { kotlin.math.min(it,time) } ?: time
            latestSynced=latestSynced?.let { kotlin.math.max(it,time) } ?: time
        }
        if(reactionRows!=null) {
            require(reactionRows.length()<=50000){"Too many reaction records"}
            for(j in 0 until reactionRows.length()) {
                val entry=reactionRows.optJSONObject(j)?:continue
                val webId=entry.optString("message_id")
                if(webId.isBlank())continue
                val header=entry.optString("timestamp")
                val parsed=Regex("""^\[([^]]+)]\s*(.*?):\s*$""").find(header)
                val sender=parsed?.groupValues?.get(2).orEmpty()
                val reactionFmt=if(test51)SimpleDateFormat("h:mm a, M/d/yyyy",Locale.US).apply{isLenient=false} else dateParser
                val moment=runCatching{reactionFmt.parse(parsed?.groupValues?.get(1).orEmpty())?.time}.getOrNull()
                val people=entry.optJSONArray("reactions")?:continue
                for(k in 0 until people.length()) {
                    val item=people.optJSONObject(k)?:continue
                    val rawActor=item.optString("actor").trim()
                    val actor=if(rawActor.equals("You",true)||rawActor.equals("self",true)||rawActor.equals("Steve B",true))"self" else rawActor
                    val emoji=item.optString("emoji").trim()
                    if(actor.isNotBlank() && emoji.isNotBlank()) {
                        reactionsDetected++
                        if(db.saveReaction(chatId,webId,header,sender,actor,emoji,moment,entry.optString("message_text")))newlyAddedReactions++
                        storedReactions++
                        markSynced(moment)
                    }
                }
            }
        }
        require(replies.length()<=20000){"Too many quoted replies"}
        val latest=db.latestArchivedMessageTime(chatId)
        var linked=0;var untouched=0;var pending=false
        for(i in 0 until replies.length()){
            val item=replies.getJSONObject(i)
            val parsed=parseHeader(item.optString("reply_time"),test51)
            if(parsed==null){untouched++;pending=true;continue}
            val (time,sender)=parsed
            if(latest==null || time>latest){untouched++;pending=true;continue}
            val text=item.optString("reply_text").trim().replace(Regex("\\s+")," ")
            val responseOptions=db.replyCandidates(chatId,time,sender).filter {m->
                text.isNotBlank() && m.body.trim().replace(Regex("\\s+")," ").equals(text,true)
            }
            if(responseOptions.size!=1){untouched++;pending=true;continue}
            val quote=item.optString("quoted_text").trim().split('\n',limit=2)
            val from=if(quote.size==2)quote[0].trim() else ""
            val phrase=(if(quote.size==2)quote[1] else quote[0]).removeSuffix("...").trim().replace(Regex("\\s+")," ").take(300)
            if(phrase.length<8){untouched++;pending=true;continue}
            val owner=if(from.equals("You",true)||from.equals("Steve B",true))context.getSharedPreferences("MainActivity",Context.MODE_PRIVATE).getString("sender_$chatId","").orEmpty().ifBlank { "Steve B" } else from
            // "You" has no stable identity in older JSON: do not guess the original sender.
            if((from.equals("You",true)||from.equals("Steve B",true)) && owner.isBlank()){untouched++;pending=true;continue}
            val originals=db.originalCandidates(chatId,phrase,owner,time)
            if(originals.size!=1){untouched++;pending=true;continue}
            if(db.autoLinkedReply(chatId,responseOptions.single(),originals.single(),batchId)) {
                linked++
                markSynced(time)
            } else untouched++
        }
        // The compact browser scanner reports the two endpoints and the reason it stopped.
        // These are *observed* endpoints, not a proof that every intervening message
        // was inspected. Persist even partial scans so they can be planned around.
        if(test51) {
            val cp=json.optJSONObject("checkpoint")
            val first=cp?.optJSONObject("newest")
            val last=cp?.optJSONObject("oldest")
            val top=parseHeader(first?.optString("time").orEmpty(),true)?.first
            val bottom=parseHeader(last?.optString("time").orEmpty(),true)?.first
            if(top!=null && bottom!=null && top>=bottom && json.optInt("unique_messages_seen",0)>0) {
                val reason=json.optString("stop_reason","Stopped")
                db.addScanCoverage(chatId,batchId,bottom,top,first?.optString("id").orEmpty(),last?.optString("id").orEmpty(),
                    json.optInt("unique_messages_seen"),reason)
                val prior=db.historyResumeTime(chatId).let { parseHeader(it,true)?.first ?: parseHeader(it)?.first }
                if(prior==null || bottom<prior) {
                    db.saveHistoryResumeTime(chatId,db.historyResume(chatId)?.first ?: first?.optString("id").orEmpty(),
                        last?.optString("id").orEmpty(),last?.optString("time").orEmpty())
                }
                // Importing a file does not prove that the browser checkpoint was
                // reached. Never silently promote the update boundary here.
                db.saveScanEvent(chatId,reason.equals("Checkpoint",true),top)
            }
        }
        val mode=json.optString("scan_mode","")
        if(mode=="new") {
            val cp=json.optJSONObject("checkpoint")
            val previous=cp?.optString("prior_checkpoint_id").orEmpty().ifBlank { cp?.optString("prior_newest_message_id").orEmpty() }
            val newest=cp?.optString("newest_message_id").orEmpty()
            val saved=db.webCheckpoint(chatId).ifBlank {db.historyResume(chatId)?.first.orEmpty()}
            if(json.optBoolean("scan_complete",false) && json.optBoolean("checkpoint_reached",false) && previous.isNotBlank() && previous==saved && newest.isNotBlank()){
                db.setWebCheckpoint(chatId,newest)
                db.saveScanEvent(chatId,true,null)
            }
        }
        if(mode in listOf("fresh","history","resume")) {
            val meta=json.optJSONObject("checkpoint")
            val oldest=meta?.optString("oldest_message_id").orEmpty()
            val oldestHeader=meta?.optString("oldest_message_time").orEmpty()
            val oldTime=db.historyResumeTime(chatId)
            fun moment(value:String):Long?=parseHeader(value)?.first
            val newOld=moment(oldestHeader)
            val previous=db.historyResume(chatId)
            val previousOld=moment(oldTime)
            val newestHeader=meta?.optString("newest_message_time").orEmpty()
            val newest=moment(newestHeader) ?: (0 until replies.length()).mapNotNull{moment(replies.getJSONObject(it).optString("reply_time"))}.maxOrNull()
            val crosses=previous!=null && newOld!=null && previousOld!=null && newest!=null && newest>=previousOld && newOld<previousOld
            val start=meta?.optString("history_start_id").orEmpty().ifBlank{meta?.optString("newest_message_id").orEmpty()}.ifBlank{oldest}
            if(oldest.isNotBlank() && newOld!=null && json.optInt("message_ids_seen")>0 && ((previous==null && start.isNotBlank()) || crosses)){
                db.saveHistoryResumeTime(chatId,previous?.first ?: start,oldest,oldestHeader)
                db.saveScanEvent(chatId,true,newOld)
            }
        }
        db.retryReactionMatches(chatId)
        val reactionPending=db.reactionCounts(chatId).second
        prefs.edit().putInt("quote_detected_$batchId",quotesDetected)
            .putInt("quote_added_$batchId",linked)
            .putInt("reaction_detected_$batchId",reactionsDetected)
            .putInt("reaction_added_$batchId",newlyAddedReactions)
            .putInt("reaction_pending_$batchId",reactionPending).apply()
        if(earliestSynced!=null && latestSynced!=null) {
            prefs.edit().putLong("sync_first_$batchId",earliestSynced!!)
                .putLong("sync_last_$batchId",latestSynced!!).apply()
        }
        // Entries awaiting an updated WhatsApp archive are preserved in the source file.
        // A 'waiting' batch is shown for review; reimport through manual workflow as needed.
        return Triple(linked+storedReactions,untouched,!pending)
    }
}
