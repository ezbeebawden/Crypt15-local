package com.example.chatarchive

import android.content.ContentValues
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** Personal annotations only. Never copies source conversations or QAR associations. */
internal class AnnotationPreserver {
    private data class Ref(val fingerprint:String,val occurrence:Int,val time:Long,val sender:String,val body:String,val attachment:String?)
    private data class Group(val label:String,val savedAt:Long,val members:List<Ref>)
    private data class Annotated(val ref:Ref,val value:String="")
    private data class ChatNotes(val name:String,val groups:List<Group>,val favourites:List<Annotated>,val labels:List<Annotated>)
    internal data class Report(val bookmarks:Int,val favs:Int,val labels:Int,val unmatched:Int,val unmatchedJson:JSONObject) {
        override fun toString()="$bookmarks bookmarks, $favs media favourites, $labels voice-note labels restored; $unmatched unmatched"
    }
    private val notes=mutableListOf<ChatNotes>()
    private fun readRef(c:android.database.Cursor,start:Int=0)=Ref(c.getString(start),c.getInt(start+1),c.getLong(start+2),c.getString(start+3),c.getString(start+4),if(c.isNull(start+5))null else c.getString(start+5))
    private fun refJson(ref:Ref)=JSONObject().put("fingerprint",ref.fingerprint).put("occurrence",ref.occurrence).put("time",ref.time).put("sender",ref.sender).put("body",ref.body).put("attachment",ref.attachment)
    fun capture(source:ArchiveDb) {
        notes.clear()
        val sql=source.readableDatabase
        for(chat in source.chats()) {
            val groups=mutableListOf<Group>()
            sql.rawQuery("SELECT id,label,saved_at FROM bookmark_groups WHERE chat_id=? ORDER BY id",arrayOf(chat.id.toString())).use{g->
                while(g.moveToNext()) {
                    val members=mutableListOf<Ref>()
                    sql.rawQuery("SELECT m.fingerprint,m.occurrence,m.time,m.sender,m.body,m.attachment FROM bookmark_items b JOIN messages m ON m.id=b.message_id WHERE b.group_id=? ORDER BY m.id",arrayOf(g.getLong(0).toString())).use{c->while(c.moveToNext())members.add(readRef(c))}
                    groups.add(Group(g.getString(1),g.getLong(2),members))
                }
            }
            val favs=mutableListOf<Annotated>()
            sql.rawQuery("SELECT m.fingerprint,m.occurrence,m.time,m.sender,m.body,m.attachment FROM media_favourites f JOIN messages m ON m.chat_id=f.chat_id AND m.fingerprint=f.fingerprint AND m.occurrence=f.occurrence WHERE f.chat_id=?",arrayOf(chat.id.toString())).use{c->while(c.moveToNext())favs.add(Annotated(readRef(c)))}
            val labels=mutableListOf<Annotated>()
            sql.rawQuery("SELECT m.fingerprint,m.occurrence,m.time,m.sender,m.body,m.attachment,l.label FROM voice_labels l JOIN messages m ON m.chat_id=l.chat_id AND m.fingerprint=l.fingerprint AND m.occurrence=l.occurrence WHERE l.chat_id=?",arrayOf(chat.id.toString())).use{c->while(c.moveToNext())labels.add(Annotated(readRef(c),c.getString(6)))}
            if(groups.isNotEmpty()||favs.isNotEmpty()||labels.isNotEmpty())notes.add(ChatNotes(chat.name,groups,favs,labels))
        }
    }
    /** Only exact unique matches are restored. All unresolved annotations are retained in the report. */
    fun restore(stage:ArchiveDb):Report {
        val sql=stage.writableDatabase
        val ids=stage.chats().associate{it.name.trim().lowercase(Locale.ROOT) to it.id}
        val missing=JSONArray()
        var bookmarks=0;var favs=0;var labels=0;var unmatched=0
        fun markMissing(chat:String,type:String,ref:Ref?,label:String) {
            unmatched++
            missing.put(JSONObject().put("chat",chat).put("kind",type).put("label",label).put("message",ref?.let{refJson(it)}))
        }
        fun resolve(chatId:Long,ref:Ref):Long? {
            sql.rawQuery("SELECT id,time,sender,body,attachment FROM messages WHERE chat_id=? AND fingerprint=? AND occurrence=?",arrayOf(chatId.toString(),ref.fingerprint,ref.occurrence.toString())).use{c->
                if(c.moveToFirst() && c.getLong(1)==ref.time && c.getString(2)==ref.sender && c.getString(3)==ref.body && (if(c.isNull(4))null else c.getString(4))==ref.attachment)return c.getLong(0)
            }
            // Re-imports can generate different fingerprints. Only accept one precise match.
            val args=arrayOf(chatId.toString(),ref.time.toString(),ref.sender,ref.body)
            val idsFound=mutableListOf<Long>()
            val extra=if(ref.attachment==null) " AND attachment IS NULL" else " AND attachment=?"
            val matchArgs=if(ref.attachment==null) args else args+ref.attachment
            sql.rawQuery("SELECT id FROM messages WHERE chat_id=? AND time=? AND sender=? AND body=?$extra LIMIT 2",matchArgs).use{c->while(c.moveToNext())idsFound.add(c.getLong(0))}
            return idsFound.singleOrNull()
        }
        sql.beginTransaction()
        try {
            for(note in notes) {
                val chatId=ids[note.name.trim().lowercase(Locale.ROOT)]
                for(group in note.groups) {
                    val found=if(chatId==null)emptyList() else group.members.mapNotNull{ref->resolve(chatId,ref)}.distinct()
                    if(found.isNotEmpty() && chatId!=null) {
                        val values=ContentValues().apply{put("chat_id",chatId);put("label",group.label);put("saved_at",group.savedAt)}
                        val groupId=sql.insertOrThrow("bookmark_groups",null,values)
                        for(id in found)sql.insertWithOnConflict("bookmark_items",null,ContentValues().apply{put("group_id",groupId);put("message_id",id)},android.database.sqlite.SQLiteDatabase.CONFLICT_IGNORE)
                        bookmarks++
                    }
                    // An empty group is not reconstructed. Keep every missing member for later recovery.
                    for(ref in group.members)if(chatId==null || resolve(chatId,ref)==null)markMissing(note.name,"bookmark",ref,group.label)
                    if(group.members.isEmpty())markMissing(note.name,"empty_bookmark",null,group.label)
                }
                for(fav in note.favourites) {
                    val msgId=chatId?.let{resolve(it,fav.ref)}
                    if(msgId==null || chatId==null){markMissing(note.name,"favourite",fav.ref,"");continue}
                    sql.rawQuery("SELECT fingerprint,occurrence FROM messages WHERE id=?",arrayOf(msgId.toString())).use{c->if(c.moveToFirst()){
                        sql.insertWithOnConflict("media_favourites",null,ContentValues().apply{put("chat_id",chatId);put("fingerprint",c.getString(0));put("occurrence",c.getInt(1))},android.database.sqlite.SQLiteDatabase.CONFLICT_IGNORE)
                        favs++
                    }}
                }
                for(label in note.labels) {
                    val msgId=chatId?.let{resolve(it,label.ref)}
                    if(msgId==null || chatId==null){markMissing(note.name,"voice_label",label.ref,label.value);continue}
                    sql.rawQuery("SELECT fingerprint,occurrence FROM messages WHERE id=?",arrayOf(msgId.toString())).use{c->if(c.moveToFirst()){
                        sql.insertWithOnConflict("voice_labels",null,ContentValues().apply{put("chat_id",chatId);put("fingerprint",c.getString(0));put("occurrence",c.getInt(1));put("label",label.value)},android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE)
                        labels++
                    }}
                }
            }
            sql.setTransactionSuccessful()
        } finally {sql.endTransaction()}
        return Report(bookmarks,favs,labels,unmatched,JSONObject().put("format","tangled-unmatched-personal-annotations-v1").put("items",missing))
    }
}
