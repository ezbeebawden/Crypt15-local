package com.example.chatarchive

import android.content.Context
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.provider.DocumentsContract
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.io.File
import java.security.KeyStore
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.spec.GCMParameterSpec

/** Isolated Crypt15 ingestion. The original export importers and files are never modified. */
internal class Crypt15Sync(private val context:Context, private val archive:ArchiveDb) {
    data class Conversation(val jid:String,val title:String,val count:Long,val latest:Long,val group:Boolean,val linkedChat:Long?)
    data class Result(val added:Int,val skipped:Int,val quotes:Int,val reactions:Int)
    private val preferences=context.getSharedPreferences("tangled_crypt15",Context.MODE_PRIVATE)
    private val store=File(context.filesDir,"crypt15-private").also{it.mkdirs()}
    private val current=File(store,"current.crypt15")
    private val alias="tangled-crypt15-backup-key"

    private fun secret():javax.crypto.SecretKey {
        val ks=KeyStore.getInstance("AndroidKeyStore").apply{load(null)}
        (ks.getKey(alias,null) as? javax.crypto.SecretKey)?.let{return it}
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        }.generateKey()
    }
    fun saveKey(raw:String) {
        val key=raw.replace(Regex("\\s+"),"")
        require(key.matches(Regex("(?i)[a-f0-9]{64}"))){"Enter the complete 64-character hexadecimal crypt15 key."}
        val cipher=Cipher.getInstance("AES/GCM/NoPadding").apply{init(Cipher.ENCRYPT_MODE,secret())}
        val encrypted=cipher.doFinal(key.toByteArray(Charsets.US_ASCII))
        preferences.edit().putString("key",Base64.encodeToString(cipher.iv+encrypted,Base64.NO_WRAP)).apply()
    }
    fun hasKey()=preferences.contains("key")
    private fun key():String {
        val raw=preferences.getString("key",null)?:error("Set your crypt15 encryption key first")
        val bytes=Base64.decode(raw,Base64.DEFAULT)
        val cipher=Cipher.getInstance("AES/GCM/NoPadding").apply {init(Cipher.DECRYPT_MODE,secret(),GCMParameterSpec(128,bytes.copyOfRange(0,12)))}
        return String(cipher.doFinal(bytes.copyOfRange(12,bytes.size)),Charsets.US_ASCII)
    }
    fun hasBackup()=current.isFile
    fun status():String=if(current.exists())"Saved backup · ${current.length()/1048576} MB" else "No crypt15 backup imported"
    fun lastSync():String=preferences.getString("last_sync","")?:""
    private fun digest(file:File):String {
        val md=MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->val buffer=ByteArray(65536);while(true){val n=input.read(buffer);if(n<0)break;md.update(buffer,0,n)}}
        return md.digest().joinToString(""){ "%02x".format(it) }
    }
    /** Stage, authenticate and only then swap. The earlier backup survives every failed import. */
    @Synchronized fun importFile(uri:Uri):Boolean {
        val tmp=File(store,"incoming.tmp");val decoded=File(store,"incoming.sqlite")
        try {
            context.contentResolver.openInputStream(uri)?.use{source->tmp.outputStream().buffered().use{source.copyTo(it)}} ?: error("Cannot read selected backup")
            val hash=digest(tmp)
            if(hash==preferences.getString("current_hash",null) && current.exists())return false
            val result=Crypt15Engine.decrypt(tmp,decoded,key(),Crypt15Engine.Progress{})
            require(result.sqlite){"This crypt15 backup contains an archive other than a SQLite message database"}
            SQLiteDatabase.openDatabase(decoded.absolutePath,null,SQLiteDatabase.OPEN_READONLY).use{sql ->
                require(sql.rawQuery("SELECT 1 FROM sqlite_master WHERE type='table' AND name='message'",null).use{it.moveToFirst()}){"No WhatsApp message table"}
            }
            val staged=File(store,"next.crypt15")
            tmp.copyTo(staged,overwrite=true)
            val old=File(store,"previous.crypt15")
            old.delete()
            if(current.exists() && !current.renameTo(old))error("Cannot protect previous crypt15 backup")
            if(!staged.renameTo(current)){
                if(old.exists())old.renameTo(current)
                error("Cannot commit crypt15 backup")
            }
            preferences.edit().putString("current_hash",hash).apply()
            // Retain the preceding verified backup until the new source has synced.
            log("backup","imported",0,0,0,0)
            return true
        } finally {tmp.delete();decoded.delete()}
    }
    private fun <T> withDb(block:(SQLiteDatabase)->T):T {
        require(current.isFile){"Import a crypt15 backup first"}
        val decoded=File(store,"working-${Thread.currentThread().id}.sqlite")
        try{
            val result=Crypt15Engine.decrypt(current,decoded,key(),Crypt15Engine.Progress{})
            require(result.sqlite){"Not a SQLite backup"}
            return SQLiteDatabase.openDatabase(decoded.absolutePath,null,SQLiteDatabase.OPEN_READONLY).use{db->block(db)}
        }finally{decoded.delete()}
    }
    private fun tableColumn(db:SQLiteDatabase,table:String,column:String):Boolean = db.rawQuery("PRAGMA table_info($table)",null).use{c->
        var found=false;while(c.moveToNext())if(c.getString(1)==column)found=true;found
    }
    private fun source():SQLiteDatabase=archive.writableDatabase
    private fun setup(){
        source().execSQL("CREATE TABLE IF NOT EXISTS crypt_sync_events (id INTEGER PRIMARY KEY AUTOINCREMENT, backup_hash TEXT NOT NULL, timestamp INTEGER NOT NULL, jid TEXT NOT NULL, status TEXT NOT NULL, added INTEGER NOT NULL, skipped INTEGER NOT NULL, quotes INTEGER NOT NULL, reactions INTEGER NOT NULL)")
        source().execSQL("CREATE TABLE IF NOT EXISTS crypt_chat_links (jid TEXT PRIMARY KEY, chat_id INTEGER NOT NULL, title TEXT NOT NULL)")
        source().execSQL("CREATE TABLE IF NOT EXISTS crypt_message_ids (jid TEXT NOT NULL, key_id TEXT NOT NULL, from_me INTEGER NOT NULL, chat_id INTEGER NOT NULL, fingerprint TEXT NOT NULL, occurrence INTEGER NOT NULL, PRIMARY KEY(jid,key_id,from_me))")
    }
    init{setup()}
    private fun log(jid:String,status:String,added:Int,skipped:Int,quotes:Int,reactions:Int){
        source().insert("crypt_sync_events",null,ContentValues().apply{
            put("backup_hash",preferences.getString("current_hash","")?:"");put("timestamp",System.currentTimeMillis())
            put("jid",jid);put("status",status);put("added",added);put("skipped",skipped)
            put("quotes",quotes);put("reactions",reactions)
        })
    }
    fun history():List<String> = source().rawQuery("SELECT timestamp,jid,status,added,skipped,quotes,reactions FROM crypt_sync_events ORDER BY id DESC LIMIT 35",null).use{c->
        buildList { while(c.moveToNext()){
            val date=java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.SHORT,java.text.DateFormat.SHORT).format(java.util.Date(c.getLong(0)))
            add("$date · ${c.getString(1)} · ${c.getString(2)} · +${c.getInt(3)} messages, ${c.getInt(4)} existing, ${c.getInt(5)} quotes, ${c.getInt(6)} reactions")
        }}
    }
    private fun linked(jid:String):Long?=source().rawQuery("SELECT chat_id FROM crypt_chat_links WHERE jid=?",arrayOf(jid)).use{if(it.moveToFirst())it.getLong(0)else null}
    fun link(jid:String,title:String,chatId:Long){
        require(archive.chats().any{it.id==chatId}){"Target conversation no longer exists"}
        source().insertWithOnConflict("crypt_chat_links",null,ContentValues().apply{put("jid",jid);put("chat_id",chatId);put("title",title)},SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun unlink(jid:String){source().delete("crypt_chat_links","jid=?",arrayOf(jid))}
    fun mapped():List<Pair<String,Long>> =source().rawQuery("SELECT jid,chat_id FROM crypt_chat_links ORDER BY jid",null).use{c->buildList{while(c.moveToNext())add(c.getString(0) to c.getLong(1))}}
    fun conversations():List<Conversation> = withDb{db->
        val sql="""SELECT COALESCE(j.raw_string,'chat:'||c._id),COALESCE(NULLIF(c.subject,''),NULLIF(j.user,''),NULLIF(j.raw_string,''),'Chat '||c._id),
            (SELECT COUNT(*) FROM message m WHERE m.chat_row_id=c._id),COALESCE(m.timestamp,c.sort_timestamp,0)
            FROM chat c LEFT JOIN jid j ON j._id=c.jid_row_id LEFT JOIN message m ON m._id=c.last_message_row_id
            ORDER BY 4 DESC,c._id DESC"""
        db.rawQuery(sql,null).use{c->buildList{
            while(c.moveToNext()){
                val jid=c.getString(0);add(Conversation(jid,c.getString(1),c.getLong(2),c.getLong(3),jid.endsWith("@g.us"),linked(jid)))
            }
        }}
    }
    private fun realMessage(jid:String,key:String,mine:Int):Message? {
        val sql=source()
        return sql.rawQuery("""SELECT m.time,m.sender,m.body,m.attachment,m.fingerprint,m.occurrence
            FROM crypt_message_ids x JOIN messages m ON m.chat_id=x.chat_id AND m.fingerprint=x.fingerprint AND m.occurrence=x.occurrence
            WHERE x.jid=? AND x.key_id=? AND x.from_me=? LIMIT 1""",arrayOf(jid,key,mine.toString())).use{c ->
            if(c.moveToFirst())Message(c.getLong(0),c.getString(1),c.getString(2),if(c.isNull(3))null else c.getString(3),c.getString(4),c.getInt(5)) else null
        }
    }
    private fun matchOld(chatId:Long,time:Long,body:String,mine:Boolean):Message? {
        if(body.isBlank())return null
        val me=context.getSharedPreferences("MainActivity",Context.MODE_PRIVATE).getString("sender_$chatId",null)
        val min=time-60000L;val max=time+60000L
        val matches=mutableListOf<Message>()
        source().rawQuery("SELECT time,sender,body,attachment,fingerprint,occurrence FROM messages WHERE chat_id=? AND time>=? AND time<=? AND body=? LIMIT 5",
            arrayOf(chatId.toString(),min.toString(),max.toString(),body)).use{c ->
            while(c.moveToNext()){
                val sender=c.getString(1)
                if(me!=null && (sender==me)!=mine)continue
                matches.add(Message(c.getLong(0),sender,c.getString(2),if(c.isNull(3))null else c.getString(3),c.getString(4),c.getInt(5)))
            }
        }
        // Never merge when two existing messages are indistinguishable.
        return matches.singleOrNull()
    }
    /** Import only missing messages; preserve the original archived message rows and attachments.
     * Crypt stable IDs are kept separately for repeat-safe subsequent imports. */
    fun sync(jid:String):Result=withDb{sql->
        val target=linked(jid)?:error("Link this conversation first")
        val chat=archive.chats().firstOrNull{it.id==target}?:error("Linked Tangled conversation was deleted")
        val row=sql.rawQuery("SELECT c._id FROM chat c JOIN jid j ON j._id=c.jid_row_id WHERE j.raw_string=?",arrayOf(jid)).use{c->if(c.moveToFirst())c.getLong(0)else error("Conversation not found in this backup")}
        val senderCol=tableColumn(sql,"message","sender_jid_row_id")
        val query="SELECT m.timestamp,m.text_data,m.from_me,m.key_id,"+(if(senderCol)"COALESCE(j.raw_string,'')" else "''")+" FROM message m "+(if(senderCol)"LEFT JOIN jid j ON j._id=m.sender_jid_row_id " else "")+" WHERE m.chat_row_id=? AND m.timestamp>0 ORDER BY m.timestamp,m._id"
        var added=0;var skipped=0
        val baseHash="crypt15:${preferences.getString("current_hash","")}:$jid"
        if(preferences.getBoolean("synced_$baseHash",false) || archive.autoBatch(baseHash)?.status=="completed")return@withDb Result(0,0,0,0)
        val batchHash=if(archive.autoBatchExists(baseHash))"$baseHash:retry:${System.currentTimeMillis()}" else baseHash
        val batch=archive.addAutoBatch(batchHash,"crypt15 · ${chat.name}",target,"crypt")
        val records=mutableListOf<Triple<String,Int,Message>>()
        val occurrences=mutableMapOf<String,Int>()
        try {
            sql.rawQuery(query,arrayOf(row.toString())).use {c->
                while(c.moveToNext()) {
                    val body=c.getString(1)?:""
                    val mine=c.getInt(2)!=0
                    val id=c.getString(3).orEmpty()
                    val actor=c.getString(4).orEmpty()
                    val me=context.getSharedPreferences("MainActivity",Context.MODE_PRIVATE).getString("sender_$target",null)
                    val sender=if(mine)me?.takeIf{it.isNotBlank()}?:"You"
                        else if(jid.endsWith("@g.us"))actor.ifBlank{"Unknown participant"}
                        else archive.participants(target).firstOrNull{it!=me}?:"Other"
                    val timestamp=c.getLong(0)
                    val fp=ArchiveDb.hash(timestamp,sender,body)
                    val occ=occurrences.getOrDefault(fp,0);occurrences[fp]=occ+1
                    if(id.isBlank() || body.isBlank()){skipped++;continue}
                    val prior=realMessage(jid,id,if(mine)1 else 0)
                    if(prior!=null){skipped++;continue}
                    val original=matchOld(target,timestamp,body,mine)
                    if(original!=null){
                        val cv=ContentValues().apply{put("jid",jid);put("key_id",id);put("from_me",if(mine)1 else 0);put("chat_id",target);put("fingerprint",original.fingerprint);put("occurrence",original.occurrence)}
                        source().insertWithOnConflict("crypt_message_ids",null,cv,SQLiteDatabase.CONFLICT_REPLACE)
                        skipped++;continue
                    }
                    records.add(Triple(id,if(mine)1 else 0,Message(timestamp,sender,body,null,fp,occ)))
                }
            }
            // Insert through the established importer to retain fingerprint and batch undo tracking.
            // Use batches to avoid building the entire conversation in memory twice.
            records.chunked(400).forEach{chunk->
                val (a,d)=archive.insert(chat.name,chunk.map{it.third},batch)
                added+=a;skipped+=d
                for((key,from,message) in chunk){
                    val cv=ContentValues().apply{put("jid",jid);put("key_id",key);put("from_me",from);put("chat_id",target);put("fingerprint",message.fingerprint);put("occurrence",message.occurrence)}
                    source().insertWithOnConflict("crypt_message_ids",null,cv,SQLiteDatabase.CONFLICT_IGNORE)
                }
            }
            // Exact key-ID quote relations, only where both records can be mapped.
            var quotes=0
            if(tableColumn(sql,"message_quoted","message_row_id")) {
                sql.rawQuery("""SELECT m.key_id,m.from_me,q.key_id,q.from_me
                    FROM message_quoted q JOIN message m ON m._id=q.message_row_id
                    WHERE m.chat_row_id=? AND q.key_id IS NOT NULL""",arrayOf(row.toString())).use{c->
                    while(c.moveToNext()){
                        val reply=realMessage(jid,c.getString(0)?:continue,c.getInt(1))?:continue
                        val original=realMessage(jid,c.getString(2)?:continue,c.getInt(3))?:continue
                        if(reply.fingerprint==original.fingerprint && reply.occurrence==original.occurrence)continue
                        if(archive.autoLinkedReply(target,reply,original,batch))quotes++
                    }
                }
            }
            var reactions=0
            if(sql.rawQuery("SELECT 1 FROM sqlite_master WHERE type='table' AND name='message_add_on_reaction'",null).use{it.moveToFirst()}){
                val reactionSql="""SELECT m.key_id,m.from_me,r.reaction,a.from_me,COALESCE(j.raw_string,'')
                    FROM message_add_on a JOIN message_add_on_reaction r ON r.message_add_on_row_id=a._id
                    JOIN message m ON m._id=a.parent_message_row_id
                    LEFT JOIN jid j ON j._id=a.sender_jid_row_id WHERE m.chat_row_id=?"""
                sql.rawQuery(reactionSql,arrayOf(row.toString())).use{c ->
                    while(c.moveToNext()){
                        val targetMessage=realMessage(jid,c.getString(0)?:continue,c.getInt(1))?:continue
                        val emoji=c.getString(2)?.takeIf{it.isNotBlank()}?:continue
                        val actor=if(c.getInt(3)!=0)"You" else c.getString(4)?.takeIf{it.isNotBlank()}?:"Other"
                        val webId="crypt15:${jid}:${c.getString(0)}"
                        val values=ContentValues().apply{
                            put("chat_id",target);put("web_id",webId);put("web_time","")
                            put("sender",targetMessage.sender);put("actor",actor);put("emoji",emoji)
                            put("message_text",targetMessage.body);put("fingerprint",targetMessage.fingerprint);put("occurrence",targetMessage.occurrence)
                        }
                        source().insertWithOnConflict("web_reactions",null,values,SQLiteDatabase.CONFLICT_REPLACE)
                        reactions++
                    }
                }
            }
            archive.finishAutoBatch(batch,added,skipped,"completed")
            preferences.edit().putBoolean("synced_$baseHash",true)
                .putString("last_sync",java.text.DateFormat.getDateTimeInstance().format(java.util.Date())).apply()
            log(jid,"completed",added,skipped,quotes,reactions)
            Result(added,skipped,quotes,reactions)
        }catch(t:Throwable){
            archive.finishAutoBatch(batch,added,skipped,"failed")
            log(jid,"failed",added,skipped,0,0)
            throw t
        }
    }
    fun syncLinked():List<String> {
        if(!current.exists() || !hasKey())return emptyList()
        val available=conversations().map{it.jid}.toSet()
        val links=mapped()
        val missing=links.filter{it.first !in available}.map{"ERROR ${it.first}: linked conversation not present in this backup"}
        val results=links.filter{it.first in available}.map{(jid,id)->
            runCatching{val result=sync(jid);"${archive.chats().find{it.id==id}?.name ?: jid}: +${result.added} messages, ${result.quotes} quotes, ${result.reactions} reactions"}
                .getOrElse{"ERROR $jid: ${it.message}"}
        }
        // Remove the earlier backup only once every linked conversation has synced.
        if(results.isNotEmpty() && missing.isEmpty() && results.none{it.startsWith("ERROR ")})File(store,"previous.crypt15").delete()
        return results+missing
    }
    /** Checks only the user-selected SAF folder. Never deletes the source document. */
    fun importNewestWatched(folder:Uri?):Boolean {
        if(folder==null || !hasKey())return false
        val root=DocumentsContract.getTreeDocumentId(folder)
        val children=DocumentsContract.buildChildDocumentsUriUsingTree(folder,root)
        val columns=arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_LAST_MODIFIED)
        val files=mutableListOf<Pair<Long,Uri>>()
        context.contentResolver.query(children,columns,null,null,null)?.use{c->
            while(c.moveToNext()){
                val name=c.getString(1)?:continue
                if(!name.endsWith(".crypt15",true))continue
                files.add(c.getLong(2) to DocumentsContract.buildDocumentUriUsingTree(folder,c.getString(0)))
            }
        }
        val latest=files.maxByOrNull{it.first}?.second?:return false
        return importFile(latest)
    }
}
