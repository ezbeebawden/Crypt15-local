package com.example.chatarchive

import java.util.Locale

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

internal data class Chat(val id: Long, val name: String, val count: Int, val lastTime: Long)
internal data class Message(val time: Long, val sender: String, val body: String, val attachment: String?, val fingerprint: String, val occurrence: Int)

internal data class SavedBookmark(val groupId: Long, val label: String, val savedAt: Long, val messages: List<Message>)
internal data class ChatStatistics(val total:Int,val first:Long?,val last:Long?,val streak:Int,val onHourPhotos:Int,val days:Int,val busiestCount:Int,val busiestDay:String,val busiestHour:Int,val busiestHourCount:Int,val daily:List<Pair<String,Int>>,val dailyEpochs:List<Long>,val streakStart:Long?) : java.io.Serializable
internal class ArchiveDb(private val appContext: Context, databaseName:String="archive.db") : SQLiteOpenHelper(appContext, databaseName, null, 21) {
    internal data class CachedStats(val signature:String,val basic:ChatStatistics,val extended:ExtraStats,val visuals:VisualStats):java.io.Serializable
    internal data class VisualStats(val hourCounts:List<Int>,val hoursBySender:List<Pair<String,List<Int>>>,val heatmap:List<Pair<Long,Int>>,val rhythm:List<RhythmBucket>,val peakHourDate:Long?,val peakHourCount:Int,val fastestReplyTime:Long?,val fastestReplySeconds:Long?,val firstSender:String?,val lastSender:String?,val dailySenders:List<DailySender>,val mediaTypes:List<Pair<String,List<Int>>>,val linkedQuotes:Int,val flowPeriods:List<FlowPeriod>):java.io.Serializable
    internal data class FlowPeriod(val startTime:Long,val messages:List<Int>,val photos:List<Int>,val voiceNotes:List<Int>):java.io.Serializable
    internal data class DailySender(val dayStart:Long,val counts:List<Int>):java.io.Serializable
    internal data class RhythmBucket(val startTime:Long,val endTime:Long,val counts:List<Int>):java.io.Serializable
    private fun statsSignature(chatId:Long):String {
        val messageKey=readableDatabase.rawQuery("SELECT COUNT(*),COALESCE(MAX(id),0),COALESCE(MAX(time),0) FROM messages WHERE chat_id=?",arrayOf(chatId.toString())).use { c ->
            c.moveToFirst(); "${c.getLong(0)}:${c.getLong(1)}:${c.getLong(2)}"
        }
        // Changing names/merged senders must also refresh sender-dependent statistics.
        val names=StringBuilder()
        for(table in listOf("sender_aliases","sender_names")) {
            readableDatabase.rawQuery("SELECT * FROM $table WHERE chat_id=? ORDER BY 1,2",arrayOf(chatId.toString())).use { c ->
                while(c.moveToNext())for(i in 0 until c.columnCount)names.append('|').append(c.getString(i))
            }
        }
        val tracked=trackedWords(chatId).joinToString("|")
        return "stats-v4435-am-pm-flow:$chatId:$messageKey:${names.toString().hashCode()}:${tracked.hashCode()}"
    }
    fun cachedChatStats(chatId:Long):Triple<ChatStatistics,ExtraStats,VisualStats> {
        val signature=statsSignature(chatId)
        val file=java.io.File(appContext.filesDir,"tangled-stats-${chatId}.bin")
        if(file.exists())try {
            val saved=java.io.ObjectInputStream(file.inputStream().buffered()).use{it.readObject() as CachedStats}
            if(saved.signature==signature)return Triple(saved.basic,saved.extended,saved.visuals)
        }catch(_:Exception) { /* Rebuild older or incomplete cache. */ }
        val basic=chatStatistics(chatId)
        val extended=extendedStatistics(chatId)
        val visuals=visualStatistics(chatId,extended.senders.map{it.first})
        // Atomic replacement avoids leaving a damaged cache if the app closes mid-write.
        try {
            val temp=java.io.File(appContext.filesDir,"tangled-stats-${chatId}.tmp")
            java.io.ObjectOutputStream(temp.outputStream().buffered()).use{it.writeObject(CachedStats(signature,basic,extended,visuals))}
            if(!temp.renameTo(file)){file.delete();temp.renameTo(file)}
        }catch(_:Exception) { /* Statistics still display even if caching fails. */ }
        return Triple(basic,extended,visuals)
    }
    private fun visualStatistics(chatId:Long,senderNames:List<String>):VisualStats {
        val hours=IntArray(24)
        val hourSender=senderNames.associateWith{IntArray(24)}
        val dayCounts=sortedMapOf<Long,Int>()
        val daySenders=sortedMapOf<Long,IntArray>()
        val mediaCategories=Array(senderNames.size){IntArray(5)}
        val senderIndices=senderNames.withIndex().associate{it.value to it.index}
        val halfDayCounts=sortedMapOf<Long,Array<IntArray>>()
        val calendar=java.util.Calendar.getInstance()
        val zone=java.time.ZoneId.systemDefault()
        var minTime:Long?=null;var maxTime:Long?=null
        var prevSender:String?=null;var prevTime:Long?=null
        var fastestTime:Long?=null;var fastestSeconds:Long?=null
        var firstSender:String?=null;var lastSender:String?=null
        var peakHourTime:Long?=null;var peakHourCount=0
        val perHour=hashMapOf<Long,Int>()
        val senderResolution=mutableMapOf<String,String>()
        // The visual aggregation is performed once in the same background stats task.
        // Only compact aggregates are retained, never the 62k message bodies.
        val stream=mutableListOf<Pair<Long,String>>()
        readableDatabase.rawQuery("SELECT time,sender,attachment FROM messages WHERE chat_id=? AND TRIM(sender) <> '' AND LOWER(TRIM(sender)) <> 'system' ORDER BY time,id",arrayOf(chatId.toString())).use{c->
            while(c.moveToNext()) {
                val time=c.getLong(0);val raw=c.getString(1)
                val sender=senderResolution.getOrPut(raw){displaySender(chatId,raw)}
                if(minTime==null) {minTime=time;firstSender=sender}
                maxTime=time;lastSender=sender
                calendar.timeInMillis=time
                val hour=calendar.get(java.util.Calendar.HOUR_OF_DAY)
                hours[hour]++
                hourSender[sender]?.let{it[hour]++}
                val day=java.time.Instant.ofEpochMilli(time).atZone(zone).toLocalDate().atStartOfDay(zone).toInstant().toEpochMilli()
                dayCounts[day]=(dayCounts[day]?:0)+1
                val index=senderIndices[sender]
                if(index!=null) {
                    daySenders.getOrPut(day){IntArray(senderNames.size)}[index]++
                    val attachment=if(c.isNull(2)) "" else c.getString(2)
                    val ext=attachment.substringBefore('?').substringAfterLast('.').lowercase(Locale.ROOT)
                    val category=when(ext) {
                        in setOf("jpg","jpeg","png","webp","gif","heic","bmp") -> 1
                        in setOf("mp4","mov","webm","3gp","mkv") -> 2
                        in setOf("mp3","m4a","ogg","opus","aac","wav","amr") -> 3
                        else -> if(attachment.isNotBlank()) 4 else 0
                    }
                    mediaCategories[index][category]++
                    val epochDay=java.time.Instant.ofEpochMilli(time).atZone(zone).toLocalDate().toEpochDay()
                    val halfDayKey=epochDay*2L+(if(hour>=12)1L else 0L)
                    val bin=halfDayCounts.getOrPut(halfDayKey){Array(3){IntArray(senderNames.size)}}
                    bin[0][index]++
                    if(category==1) bin[1][index]++
                    if(category==3) bin[2][index]++
                }
                val hourStart=time - calendar.get(java.util.Calendar.MINUTE)*60000L - calendar.get(java.util.Calendar.SECOND)*1000L - calendar.get(java.util.Calendar.MILLISECOND)
                val inHour=(perHour[hourStart]?:0)+1
                perHour[hourStart]=inHour
                if(inHour>peakHourCount){peakHourCount=inHour;peakHourTime=hourStart}
                if(prevTime!=null && prevSender!=sender && time>=prevTime!!) {
                    val seconds=(time-prevTime!!)/1000L
                    if(fastestSeconds==null || seconds<fastestSeconds!!){fastestSeconds=seconds;fastestTime=time}
                }
                prevSender=sender;prevTime=time
                stream.add(time to sender)
            }
        }
        val first=minTime;val last=maxTime
        val buckets=if(first!=null && last!=null && stream.isNotEmpty()) {
            val span=(last-first+1).coerceAtLeast(1)
            val counts=Array(48){IntArray(senderNames.size)}
            val indices=senderNames.withIndex().associate{it.value to it.index}
            for((time,sender) in stream){
                val slot=(((time-first).toDouble()/span)*48).toInt().coerceIn(0,47)
                indices[sender]?.let{counts[slot][it]++}
            }
            counts.mapIndexed{index,values->
                val start=first+(span.toDouble()*index/48).toLong()
                val end=first+(span.toDouble()*(index+1)/48).toLong()
                RhythmBucket(start,end,values.toList())
            }
        }else emptyList()
        // Include zero-activity AM/PM periods, so gaps are plotted on the real time axis.
        // These small aggregate arrays are cached alongside the other statistics.
        val flowPeriods=if(halfDayCounts.isEmpty()) emptyList() else
            (halfDayCounts.firstKey()..halfDayCounts.lastKey()).map {key->
                val counts=halfDayCounts[key] ?: Array(3){IntArray(senderNames.size)}
                val day=java.time.LocalDate.ofEpochDay(Math.floorDiv(key,2L))
                val at=day.atTime(if(Math.floorMod(key,2L)==0L)0 else 12,0).atZone(zone).toInstant().toEpochMilli()
                FlowPeriod(at,counts[0].toList(),counts[1].toList(),counts[2].toList())
            }
        val linkedQuotes=readableDatabase.rawQuery("SELECT COUNT(*) FROM reply_links WHERE chat_id=?",arrayOf(chatId.toString())).use{c->if(c.moveToFirst())c.getInt(0) else 0}
        return VisualStats(hours.toList(),senderNames.map{it to (hourSender[it]?.toList()?:List(24){0})},dayCounts.toList(),buckets,peakHourTime,peakHourCount,fastestTime,fastestSeconds,firstSender,lastSender,
            daySenders.map{DailySender(it.key,it.value.toList())},senderNames.mapIndexed{index,name->name to mediaCategories[index].toList()},linkedQuotes,flowPeriods)
    }
    fun statsMessageAt(chatId:Long, timestamp:Long, startOfDay:Boolean=false):Message? {
        val where=if(startOfDay) "time >= ? AND time < ?" else "time = ?"
        val nextDay=java.time.Instant.ofEpochMilli(timestamp).atZone(java.time.ZoneId.systemDefault()).toLocalDate().plusDays(1).atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
        val args=if(startOfDay) arrayOf(chatId.toString(),timestamp.toString(),nextDay.toString()) else arrayOf(chatId.toString(),timestamp.toString())
        val results=mutableListOf<Message>()
        readableDatabase.rawQuery("SELECT time,sender,body,attachment,fingerprint,occurrence FROM messages WHERE chat_id=? AND $where AND TRIM(sender) <> '' AND LOWER(TRIM(sender)) <> 'system' ORDER BY time,id LIMIT 1",args).use{c->
            if(c.moveToFirst()) results.add(Message(c.getLong(0),c.getString(1),c.getString(2),if(c.isNull(3))null else c.getString(3),c.getString(4),c.getInt(5)))
        }
        return results.firstOrNull()
    }
    fun statsLastMessage(chatId:Long):Message? = readableDatabase.rawQuery(
        "SELECT time,sender,body,attachment,fingerprint,occurrence FROM messages WHERE chat_id=? AND TRIM(sender) <> '' AND LOWER(TRIM(sender)) <> 'system' ORDER BY time DESC,id DESC LIMIT 1",arrayOf(chatId.toString())
    ).use{c->if(c.moveToFirst())Message(c.getLong(0),c.getString(1),c.getString(2),if(c.isNull(3))null else c.getString(3),c.getString(4),c.getInt(5))else null}
    fun chatStatistics(chatId:Long):ChatStatistics {
        val calendar=java.util.Calendar.getInstance()
        val dates=sortedMapOf<Long,Int>()
        val hours=IntArray(24)
        var total=0;var first:Long?=null;var last:Long?=null;var onHour=0
        readableDatabase.rawQuery("SELECT time,attachment FROM messages WHERE chat_id=? AND TRIM(sender) <> '' AND LOWER(TRIM(sender)) <> 'system' ORDER BY time",arrayOf(chatId.toString())).use {c->
            while(c.moveToNext()) {
                val time=c.getLong(0);val attachment=if(c.isNull(1)) "" else c.getString(1)
                total++;if(first==null)first=time;last=time
                calendar.timeInMillis=time
                val hour=calendar.get(java.util.Calendar.HOUR_OF_DAY)
                hours[hour]++
                if(calendar.get(java.util.Calendar.MINUTE)==0 && calendar.get(java.util.Calendar.SECOND)==0 && attachment.substringAfterLast('.').lowercase(Locale.ROOT) in setOf("jpg","jpeg","png","webp","gif","heic"))onHour++
                calendar.set(java.util.Calendar.HOUR_OF_DAY,0);calendar.set(java.util.Calendar.MINUTE,0);calendar.set(java.util.Calendar.SECOND,0);calendar.set(java.util.Calendar.MILLISECOND,0)
                val key=calendar.timeInMillis;dates[key]=(dates[key]?:0)+1
            }
        }
        var streak=0;var current=0;var previous:Long?=null;var currentStart:Long?=null;var longestStart:Long?=null
        val daily=dates.map { (day,count)->
            val consecutive=previous!=null && (java.time.Instant.ofEpochMilli(day).atZone(java.time.ZoneId.systemDefault()).toLocalDate().toEpochDay()-java.time.Instant.ofEpochMilli(previous!!).atZone(java.time.ZoneId.systemDefault()).toLocalDate().toEpochDay())==1L
            if(!consecutive)currentStart=day
            current=if(consecutive) current+1 else 1
            if(current>streak){streak=current;longestStart=currentStart}
            previous=day
            java.text.SimpleDateFormat("dd/MM",Locale.UK).format(java.util.Date(day)) to count
        }
        val peak=dates.maxByOrNull {it.value}
        val busiestHour=hours.indices.maxByOrNull {hours[it]}?.takeIf{hours[it]>0} ?: -1
        return ChatStatistics(total,first,last,streak,onHour,dates.size,peak?.value?:0,peak?.key?.let{java.text.SimpleDateFormat("d MMM yyyy",Locale.UK).format(java.util.Date(it))}?:"—",busiestHour,if(busiestHour>=0)hours[busiestHour] else 0,daily,dates.keys.toList(),longestStart)
    }
    internal data class ExtraStats(
        val senders:List<Pair<String,Int>>,val onHourBySender:List<Pair<String,Int>>,
        val photos:Int,val voices:Int,val videos:Int,val otherFiles:Int,
        val emojis:List<Pair<String,Int>>,val emojiBySender:List<Pair<String,List<Pair<String,Int>>>>,val trains:List<Pair<String,Int>>,
        val averageReplyMinutes:Double?,val medianReplyMinutes:Double?,
        val averageLength:Double,val busiestWeekday:String,val busiestMonth:String,
        val longestTextLength:Int,val nightMessages:Int,val daysBySender:List<Pair<String,Int>>,
        val topWordsBySender:List<Pair<String,List<Pair<String,Int>>>>,val questionsBySender:List<Pair<String,Int>>,
        val goodMorningsBySender:List<Pair<String,Int>>,val longestTextTime:Long?,
        val repeatedMessages:List<Pair<String,List<Pair<String,Int>>>>,
        val trackedCounts:List<Pair<String,List<Pair<String,Int>>>>,
        val vocabularyBySender:List<SenderVocabulary>,
        val quirksBySender:List<Pair<String,SenderQuirks>>,
        val sharedRepeatedMessages:List<Pair<String,List<Pair<String,Int>>>>
    ) : java.io.Serializable
    internal data class SenderQuirks(
        val exclamations:Int=0, val questions:Int=0, val emojiMessages:Int=0,
        val emojiOnly:Int=0, val laughterMessages:Int=0, val doubleTexts:Int=0,
        val midnightMessages:Int=0, val uppercaseMessages:Int=0,
        val longestLaugh:String="—"
    ) : java.io.Serializable
    internal data class SenderVocabulary(
        val sender:String, val words:Long, val characters:Long,
        val averageWordLength:Double, val distinctWords:Int,
        val exclusiveWords:Int, val longestRecognisedWord:String
    ) : java.io.Serializable
    // A bundled, offline English pronunciation dictionary is used to exclude
    // arbitrary character strings, URLs, hashes and file names from this metric.
    // The dictionary is a pragmatic filter, not proof of linguistic validity.
    // Restrict lookup to the set of actual candidate words after the scan.
    private fun recognisedLongestWords(vocabulary:Map<String,MutableSet<String>>):Map<String,String> {
        val candidates=vocabulary.values.flatMap { words ->
            words.filter { it.length>=7 && it.all { char -> char in 'a'..'z' } }
        }.toHashSet()
        if(candidates.isEmpty())return emptyMap()
        val recognised=hashSetOf<String>()
        try {
            appContext.assets.open("english_words_cmudict.txt").bufferedReader().useLines { lines ->
                lines.forEach { word -> if(word in candidates)recognised.add(word) }
            }
        }catch(_:Exception){ return emptyMap() }
        return vocabulary.mapValues { (_,words) ->
            words.asSequence().filter { it in recognised }
                .sortedWith(compareByDescending<String> { it.length }.thenBy { it })
                .firstOrNull() ?: "—"
        }
    }

    fun trackedWords(chatId:Long):List<String> {
        val raw=appContext.getSharedPreferences("tangled_stats_words",Context.MODE_PRIVATE).getString("chat_${chatId}","[]")?:"[]"
        return try {
            val json=org.json.JSONArray(raw)
            (0 until json.length()).map{json.optString(it).trim().lowercase(Locale.ROOT)}.filter{it.isNotBlank()}.distinct().take(30)
        }catch(_:Exception){emptyList()}
    }
    fun saveTrackedWords(chatId:Long,words:List<String>) {
        val json=org.json.JSONArray()
        words.take(30).forEach{json.put(it)}
        appContext.getSharedPreferences("tangled_stats_words",Context.MODE_PRIVATE).edit().putString("chat_${chatId}",json.toString()).apply()
    }
    fun statsRepeatedMessage(chatId:Long,senderLabel:String,normalizedBody:String):Message? {
        readableDatabase.rawQuery("SELECT time,sender,body,attachment,fingerprint,occurrence FROM messages WHERE chat_id=? AND TRIM(sender)<>'' AND LOWER(TRIM(sender))<>'system' ORDER BY time,id",arrayOf(chatId.toString())).use{cursor->
            while(cursor.moveToNext()) {
                val sender=displaySender(chatId,cursor.getString(1))
                val normalized=(cursor.getString(2)?:"")
                    .replace(Regex("(?i)<media omitted>|\\[media omitted\\]"), "")
                    .replace(Regex("\\s+")," ").trim().lowercase(Locale.ROOT)
                if(sender==senderLabel && normalized==normalizedBody) return Message(cursor.getLong(0),cursor.getString(1),cursor.getString(2),if(cursor.isNull(3))null else cursor.getString(3),cursor.getString(4),cursor.getInt(5))
            }
        }
        return null
    }
    fun extendedStatistics(chatId:Long):ExtraStats {
        val senders=linkedMapOf<String,Int>();val onHour=linkedMapOf<String,Int>();val trains=linkedMapOf<String,Int>()
        val senderDays=linkedMapOf<String,MutableSet<Long>>();val emojiCount=mutableMapOf<String,Int>()
        val emojiSenders=linkedMapOf<String,MutableMap<String,Int>>()
        val wordCounts=linkedMapOf<String,MutableMap<String,Int>>()
        val vocabulary=linkedMapOf<String,MutableSet<String>>()
        val totalWords=linkedMapOf<String,Long>()
        val totalWordCharacters=linkedMapOf<String,Long>()
        val totalCharacters=linkedMapOf<String,Long>()
        val questions=linkedMapOf<String,Int>();val greetings=linkedMapOf<String,Int>()
        // Counts represent messages (rather than punctuation / emoji occurrences).
        val quirks=linkedMapOf<String,IntArray>()
        val longestLaughBySender=linkedMapOf<String,String>()
        val laughRegex=Regex("(?i)(?:ha){2,}h?|(?:he){2,}h?|(?:hi){2,}h?|(?:lol){2,}|(?:lmao){2,}")
        val uppercaseRegex=Regex("[A-Z]{3,}")
        val repeatCounts=linkedMapOf<String,MutableMap<String,Int>>()
        val tracked=trackedWords(chatId)
        val trackedRegex=tracked.associateWith {word-> Regex("(?iu)(?<![\\p{L}\\p{N}])"+Regex.escape(word)+"(?![\\p{L}\\p{N}])") }
        val trackedCounts=linkedMapOf<String,MutableMap<String,Int>>()
        val greetingPattern=Regex("(?iu)\\bgood[\\s\\p{Punct}]*morning\\b")
        val editNotice=Regex("(?im)\\(?this message was edited\\)?|\\(?this message was deleted\\)?|you deleted this message|this message was deleted|(?m)^\\s*(?:edited|deleted)\\s*$")
        val stopwords=setOf("the","and","or","so","a","an","to","of","in","on","at","for","as","is","it","its","i","im","i'm","you","your","yours","me","my","we","our","us","they","them","this","that","these","those","be","been","being","are","was","were","am","do","does","did","have","has","had","with","but","if","then","than","not","no","yes","yeah","yeh","just","like","can","could","would","should","will","shall","from","by","up","out","about","all","there","here","what","when","where","who","how","why","he","she","his","her","him","their","some","any","more","very","really","also","too","get","got","going","go","one","two","dont","don't","thats","that's","ive","i've","its","it's","were","we're","youre","you're","well","ok","okay","haha","lol","oh","ah","er","um","because","cos","though","think","know","time","said","edited","edit","editing","deleted","delete","deleting","message")
        val wordsPattern=Regex("[\\p{L}]+(?:['’][\\p{L}]+)?")
        val responseTimes=mutableListOf<Double>();val calendar=java.util.Calendar.getInstance()
        val weekdays=IntArray(7);val months=sortedMapOf<String,Int>()
        val photosExt=setOf("jpg","jpeg","png","webp","gif","heic","heif","bmp")
        val voiceExt=setOf("opus","ogg","mp3","m4a","aac","amr","wav","flac")
        val videoExt=setOf("mp4","3gp","mov","webm","mkv","avi")
        var photos=0;var voices=0;var videos=0;var other=0;var charTotal=0L;var messages=0
        var maxText=0;var longestTextTime:Long?=null;var night=0;var prevSender:String?=null;var prevTime=0L;var run=0
        // Each sender name used to trigger two SQLite lookups *per message*.
        val resolvedSenders=mutableMapOf<String,String>()
        val monthFormat=java.text.SimpleDateFormat("MMM yyyy",Locale.UK)
        readableDatabase.rawQuery("SELECT time,sender,body,attachment FROM messages WHERE chat_id=? ORDER BY time,id",arrayOf(chatId.toString())).use { c ->
            while(c.moveToNext()) {
                val time=c.getLong(0);val rawSender=c.getString(1)
                if(rawSender.trim().equals("System",true) || rawSender.isBlank())continue
                val sender=resolvedSenders.getOrPut(rawSender){displaySender(chatId,rawSender)}
                // Export placeholders are not words, phrases, punctuation quirks or
                // captions. Media messages still contribute to message/media totals.
                val originalBody=c.getString(2)?:""
                val noPlaceholder=originalBody.replace(Regex("(?i)<media omitted>|\\[media omitted\\]"), "")
                val body=editNotice.replace(noPlaceholder, "").trim()
                val attachment=if(c.isNull(3))"" else c.getString(3)
                val ext=attachment.substringBefore('?').substringAfterLast('.').lowercase(Locale.ROOT)
                val photo=ext in photosExt
                if(photo)photos++ else if(ext in voiceExt) voices++ else if(ext in videoExt)videos++ else if(attachment.isNotBlank())other++
                senders[sender]=(senders[sender]?:0)+1
                val q=quirks.getOrPut(sender){IntArray(8)}
                if('!' in body)q[0]++
                if('?' in body)q[1]++
                if(laughRegex.containsMatchIn(body))q[4]++
                for(laugh in laughRegex.findAll(body)) {
                    val old=longestLaughBySender[sender].orEmpty()
                    if(laugh.value.codePointCount(0,laugh.value.length)>old.codePointCount(0,old.length))
                        longestLaughBySender[sender]=laugh.value
                }
                if(prevSender==sender)q[5]++
                if(uppercaseRegex.containsMatchIn(body))q[7]++
                calendar.timeInMillis=time
                if(photo && calendar.get(java.util.Calendar.MINUTE)==0 && calendar.get(java.util.Calendar.SECOND)==0)onHour[sender]=(onHour[sender]?:0)+1
                weekdays[calendar.get(java.util.Calendar.DAY_OF_WEEK)-1]++
                val month=monthFormat.format(java.util.Date(time))
                months[month]=(months[month]?:0)+1
                if(calendar.get(java.util.Calendar.HOUR_OF_DAY) in 0..5){night++;q[6]++}
                senderDays.getOrPut(sender){mutableSetOf()}.add(java.time.Instant.ofEpochMilli(time).atZone(java.time.ZoneId.systemDefault()).toLocalDate().toEpochDay())
                charTotal+=body.length
                // Count Unicode code points, so supplementary emoji count as one character.
                // Whitespace and punctuation in real message bodies are included.
                totalCharacters[sender]=(totalCharacters[sender]?:0L)+body.codePointCount(0,body.length)
                val ownVocabulary=vocabulary.getOrPut(sender){mutableSetOf()}
                for(match in wordsPattern.findAll(body)){
                    val token=match.value.lowercase(Locale.ROOT).trim('’','\'')
                    if(token.isEmpty())continue
                    totalWords[sender]=(totalWords[sender]?:0L)+1L
                    totalWordCharacters[sender]=(totalWordCharacters[sender]?:0L)+token.codePointCount(0,token.length)
                    ownVocabulary.add(token)
                }
                if(body.length>maxText){maxText=body.length;longestTextTime=time}
                messages++
                if('?' in body) questions[sender]=(questions[sender]?:0)+1
                if(greetingPattern.containsMatchIn(body)) greetings[sender]=(greetings[sender]?:0)+1
                val normalized=body.replace(Regex("\\s+")," ").trim().lowercase(Locale.ROOT)
                if(normalized.length<=280 && wordsPattern.findAll(normalized).count()>=2) {
                    val same=repeatCounts.getOrPut(sender){mutableMapOf()}
                    same[normalized]=(same[normalized]?:0)+1
                }
                val senderTracked=trackedCounts.getOrPut(sender){mutableMapOf()}
                for((word,pattern) in trackedRegex) {
                    val hits=if(word in setOf("deleted","edit","edited"))0 else pattern.findAll(body).count()
                    if(hits>0)senderTracked[word]=(senderTracked[word]?:0)+hits
                }
                val wc=wordCounts.getOrPut(sender){mutableMapOf()}
                for(match in wordsPattern.findAll(body.lowercase(Locale.ROOT))){
                    val w=match.value.trim('’','\'')
                    if(w.length>=3 && w !in stopwords)wc[w]=(wc[w]?:0)+1
                }
                if(sender==prevSender)run++ else {run=1
                    if(prevSender!=null && time>=prevTime && time-prevTime<=12L*60*60*1000)responseTimes.add((time-prevTime)/60000.0)
                }
                trains[sender]=maxOf(trains[sender]?:0,run);prevSender=sender;prevTime=time
                // Android ICU applies Unicode extended-grapheme boundaries, so ZWJ emoji,
                // flags, keycaps and skin-tone sequences are counted as *one* occurrence.
                // java.text.BreakIterator can split emoji sequences on Android devices.
                val breaks=android.icu.text.BreakIterator.getCharacterInstance(android.icu.util.ULocale.ROOT)
                breaks.setText(body)
                var start=breaks.first();var end=breaks.next()
                var containsEmoji=false
                var onlyEmoji=body.isNotBlank()
                while(end!=android.icu.text.BreakIterator.DONE){
                    val cluster=body.substring(start,end)
                    val cps=cluster.codePoints().toArray()
                    val looksEmoji=cps.any {cp ->
                        cp in 0x1F000..0x1FAFF || cp in 0x2600..0x27BF ||
                        cp==0x00A9 || cp==0x00AE || cp==0x203C || cp==0x2049 ||
                        cp==0x2122 || cp==0x2139 || cp==0x3030 || cp==0x303D ||
                        cp==0x3297 || cp==0x3299 || cp==0x20E3
                    }
                    if(looksEmoji){
                        containsEmoji=true
                    }else if(cluster.isNotBlank()){
                        onlyEmoji=false
                    }
                    if(looksEmoji){
                        // Normalise presentation and skin-tone modifiers, while retaining
                        // the joining characters that distinguish compound emoji.
                        val normalized=buildString {
                            for(cp in cps)if(cp !in 0x1F3FB..0x1F3FF && cp!=0xFE0E && cp!=0xFE0F)
                                appendCodePoint(cp)
                        }
                        if(normalized.isNotEmpty()){
                            emojiCount[normalized]=(emojiCount[normalized]?:0)+1
                            val bySender=emojiSenders.getOrPut(normalized){mutableMapOf()}
                            bySender[sender]=(bySender[sender]?:0)+1
                        }
                    }
                    start=end;end=breaks.next()
                }
                if(containsEmoji)q[2]++
                if(containsEmoji && onlyEmoji)q[3]++
            }
        }
        val longestWords=recognisedLongestWords(vocabulary)
        val vocabularyOwners=mutableMapOf<String,Int>()
        for(words in vocabulary.values)for(word in words) vocabularyOwners[word]=(vocabularyOwners[word]?:0)+1
        val senderVocabulary=senders.keys.map { sender ->
            val words=totalWords[sender]?:0L
            val distinct=vocabulary[sender].orEmpty()
            SenderVocabulary(sender,words,totalCharacters[sender]?:0L,
                if(words>0) (totalWordCharacters[sender]?:0L).toDouble()/words else 0.0,
                distinct.size,distinct.count{vocabularyOwners[it]==1},longestWords[sender] ?: "—")
        }
        val times=responseTimes.sorted();val median=if(times.isEmpty())null else if(times.size%2==1)times[times.size/2] else (times[times.size/2-1]+times[times.size/2])/2
        val weekdaysNames=listOf("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")
        return ExtraStats(senders.toList().sortedByDescending{it.second},senders.keys.map{it to (onHour[it]?:0)}.sortedByDescending{it.second},photos,voices,videos,other,
            emojiCount.toList().sortedWith(compareByDescending<Pair<String,Int>>{it.second}.thenBy{it.first}),
            emojiSenders.map { (emoji,counts)-> emoji to counts.toList() },trains.toList().sortedByDescending{it.second},
            times.takeIf{it.isNotEmpty()}?.average(),median,if(messages>0)charTotal.toDouble()/messages else 0.0,
            weekdays.indices.maxByOrNull{weekdays[it]}?.takeIf{weekdays[it]>0}?.let{weekdaysNames[it]}?:"—",
            months.maxByOrNull{it.value}?.key?:"—",maxText,night,senderDays.map{it.key to it.value.size}.sortedByDescending{it.second},
            wordCounts.map{it.key to it.value.toList().sortedByDescending{pair->pair.second}.take(5)},
            questions.toList().sortedByDescending{it.second},greetings.toList().sortedByDescending{it.second},longestTextTime,
            repeatCounts.map{it.key to it.value.filterValues{count->count>=2}.toList().sortedWith(compareByDescending<Pair<String,Int>>{it.second}.thenBy{it.first}).take(5)},
            senders.keys.map{sender->sender to tracked.map{word->word to (trackedCounts[sender]?.get(word)?:0)}},
            senderVocabulary,
            senders.keys.map { sender ->
                val q=quirks[sender] ?: IntArray(8)
                sender to SenderQuirks(q[0],q[1],q[2],q[3],q[4],q[5],q[6],q[7],
                    longestLaughBySender[sender] ?: "—")
            },
            repeatCounts.values.flatMap { it.keys }.distinct().mapNotNull { phrase ->
                val byPerson=senders.keys.map { sender -> sender to (repeatCounts[sender]?.get(phrase) ?: 0) }
                if(byPerson.count { it.second>0 } >= 2) phrase to byPerson else null
            }.sortedWith(compareByDescending<Pair<String,List<Pair<String,Int>>>> { it.second.sumOf { n -> n.second } }.thenBy { it.first }).take(5))
    }
    /** Copy an entirely validated staging archive in one SQLite transaction.
     * Private vault contents are never touched; every derived database table is replaced.
     * The original database is preserved on any SQLite failure. */
    fun replaceWithStagedArchive(stagePath:String) {
        val sql=writableDatabase
        require(java.io.File(stagePath).isFile) { "Prepared archive missing" }
        // ATTACH must be outside an active transaction.
        sql.execSQL("ATTACH DATABASE ? AS fresh",arrayOf(stagePath))
        try {
            val tables=mutableListOf<String>()
            sql.rawQuery("SELECT name FROM fresh.sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'",null).use { c ->
                while(c.moveToNext())tables.add(c.getString(0))
            }
            val current=mutableSetOf<String>()
            sql.rawQuery("SELECT name FROM main.sqlite_master WHERE type='table'",null).use { c ->
                while(c.moveToNext())current.add(c.getString(0))
            }
            require(tables.isNotEmpty() && tables.all{it in current}) { "Incompatible prepared archive" }
            require("chats" in tables && "messages" in tables) { "Missing prepared conversation tables" }
            fun quoted(name:String)="\""+name.replace("\"","\"\"")+"\""
            sql.beginTransaction()
            try {
                // Every stage is produced using the same schema/version.
                for(table in tables)sql.execSQL("DELETE FROM main.${quoted(table)}")
                for(table in tables)sql.execSQL("INSERT INTO main.${quoted(table)} SELECT * FROM fresh.${quoted(table)}")
                sql.execSQL("DELETE FROM main.sqlite_sequence")
                sql.execSQL("INSERT INTO main.sqlite_sequence SELECT * FROM fresh.sqlite_sequence")
                sql.setTransactionSuccessful()
            }finally{sql.endTransaction()}
        }finally{sql.execSQL("DETACH DATABASE fresh")}
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE chats (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE)")
        db.execSQL("CREATE TABLE messages (id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER NOT NULL, time INTEGER NOT NULL, sender TEXT NOT NULL, body TEXT NOT NULL, attachment TEXT, fingerprint TEXT NOT NULL, occurrence INTEGER NOT NULL, UNIQUE(chat_id,fingerprint,occurrence), FOREIGN KEY(chat_id) REFERENCES chats(id))")
        db.execSQL("CREATE INDEX msg_chat_time ON messages(chat_id,time,id)")
        createBookmarkTables(db)
        createVoiceLabelTable(db)
        createIdentityTables(db)
        createReplyLinkTable(db)
        addReplyConfidence(db)
        createWebCheckpoint(db)
        createHistoryResume(db)
        createScanEvents(db)
        createAutoSyncTables(db)
        createAutoSyncAliases(db)
        createMediaFavouritesTable(db)
        createMergedChatTables(db)
        createReactionTables(db)
        createScanCoverage(db)
        installMergedQarTriggers(db)
        installMergedAnnotationTriggers(db)
        createWebEvidence(db)
        createCrypt15Tables(db)
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) createBookmarkTables(db)
        if (oldVersion < 3) createVoiceLabelTable(db)
        if (oldVersion < 4) createIdentityTables(db)
        if (oldVersion < 5) createReplyLinkTable(db)
        if (oldVersion < 6) addReplyConfidence(db)
        if (oldVersion < 7) createWebCheckpoint(db)
        if (oldVersion < 8) createHistoryResume(db)
        if (oldVersion == 8) db.execSQL("ALTER TABLE web_history_resume ADD COLUMN oldest_time TEXT NOT NULL DEFAULT ''")
        if (oldVersion < 10) createScanEvents(db)
        if (oldVersion < 11) createAutoSyncTables(db)
        if (oldVersion < 12) createAutoSyncAliases(db)
        if (oldVersion < 13) createMediaFavouritesTable(db)
        if (oldVersion < 14) createMergedChatTables(db)
        if (oldVersion < 15) createReactionTables(db)
        if (oldVersion == 15) db.execSQL("ALTER TABLE web_reactions ADD COLUMN message_text TEXT NOT NULL DEFAULT ''")
        if (oldVersion < 17) createScanCoverage(db)
        if (oldVersion < 18) { installMergedQarTriggers(db); backfillMergedQar(db) }
        if (oldVersion < 19) { db.execSQL("CREATE TABLE IF NOT EXISTS merged_bookmark_links (group_id INTEGER NOT NULL, sibling_group_id INTEGER NOT NULL, PRIMARY KEY(group_id,sibling_group_id))"); installMergedAnnotationTriggers(db); backfillMergedAnnotations(db) }
        if (oldVersion < 20) createWebEvidence(db)
        if (oldVersion < 21) createCrypt15Tables(db)
    }
    private fun createCrypt15Tables(sql:SQLiteDatabase) {
        sql.execSQL("CREATE TABLE IF NOT EXISTS crypt_chat_links (jid TEXT PRIMARY KEY, chat_id INTEGER NOT NULL, title TEXT NOT NULL)")
        sql.execSQL("CREATE TABLE IF NOT EXISTS crypt_message_ids (jid TEXT NOT NULL, key_id TEXT NOT NULL, from_me INTEGER NOT NULL, chat_id INTEGER NOT NULL, fingerprint TEXT NOT NULL, occurrence INTEGER NOT NULL, PRIMARY KEY(jid,key_id,from_me))")
        sql.execSQL("CREATE TABLE IF NOT EXISTS crypt_sync_events (id INTEGER PRIMARY KEY AUTOINCREMENT, backup_hash TEXT NOT NULL, timestamp INTEGER NOT NULL, jid TEXT NOT NULL, status TEXT NOT NULL, added INTEGER NOT NULL, skipped INTEGER NOT NULL, quotes INTEGER NOT NULL, reactions INTEGER NOT NULL)")
    }
    // Reaction records retain WhatsApp's original message IDs. An archive message
    // is linked only when its minute and original sender identify ONE local row.
    // Ambiguous matches remain pending instead of attaching to a neighbour.
    private fun createReactionTables(sql:SQLiteDatabase) {
        sql.execSQL("""CREATE TABLE IF NOT EXISTS web_reactions (
          chat_id INTEGER NOT NULL, web_id TEXT NOT NULL, web_time TEXT NOT NULL,
          sender TEXT NOT NULL, actor TEXT NOT NULL, emoji TEXT NOT NULL,
          fingerprint TEXT, occurrence INTEGER, message_text TEXT NOT NULL DEFAULT '',
          PRIMARY KEY(chat_id,web_id,actor,emoji))""")
        sql.execSQL("CREATE INDEX IF NOT EXISTS web_reactions_message ON web_reactions(chat_id,fingerprint,occurrence)")
    }
    // A message id from WhatsApp Web is retained as evidence, but TXT imports don't
    // contain that ID. Only a unique exact sender+normalised-content+minute match
    // may attach a reaction. Ambiguous results stay pending, never guessed.
    // WhatsApp Web's selectable text may omit emoji that are present in the TXT
    // archive message. Match full text first; then ignore emoji ONLY for matching.
    // The message and reaction as stored are never modified.
    private fun qarComparableText(value:String):String = value.trim().replace(Regex("\\s+")," ").lowercase(Locale.ROOT)
    private fun qarWithoutEmoji(value:String):String {
        val result=StringBuilder()
        var i=0
        while(i<value.length) {
            val cp=value.codePointAt(i)
            val emoji=cp in 0x1F000..0x1FAFF || cp in 0x2600..0x27BF ||
                cp in 0x2300..0x23FF || cp in 0x2B00..0x2BFF ||
                cp in 0x1F3FB..0x1F3FF || cp==0x200D || cp==0xFE0E ||
                cp==0xFE0F || cp==0x20E3 || cp==0x00A9 || cp==0x00AE ||
                cp==0x203C || cp==0x2049 || cp==0x2122 || cp==0x2139 ||
                cp==0x3030 || cp==0x303D || cp==0x3297 || cp==0x3299
            if(!emoji) result.appendCodePoint(cp)
            i+=Character.charCount(cp)
        }
        return qarComparableText(result.toString())
    }
    private fun reactionTarget(sql:SQLiteDatabase,chatId:Long,sender:String,timeMs:Long?,messageText:String):Pair<String,Int>? {
        if(timeMs==null || sender.isBlank())return null
        val start=(timeMs/60000L)*60000L
        val query=messageText.trim().replace(Regex("\\s+")," ")
        val candidates=mutableListOf<Message>()
        sql.rawQuery("SELECT time,sender,body,attachment,fingerprint,occurrence FROM messages WHERE chat_id=? AND time>=? AND time<? LIMIT 250",
            arrayOf(chatId.toString(),start.toString(),(start+60000L).toString())).use {c->
            while(c.moveToNext())candidates.add(Message(c.getLong(0),c.getString(1),c.getString(2),if(c.isNull(3))null else c.getString(3),c.getString(4),c.getInt(5)))
        }
        val selfName=appContext.getSharedPreferences("MainActivity",Context.MODE_PRIVATE).getString("sender_$chatId","").orEmpty()
        val sameSender=candidates.filter {
            it.sender.equals(sender,true) || displaySender(chatId,it.sender).equals(sender,true) ||
            (sender.equals("You",true) && it.sender.equals(selfName,true) && selfName.isNotBlank()) ||
            (sender.equals("Steve B",true) && selfName.isNotBlank() &&
                (it.sender.equals(selfName,true) || displaySender(chatId,it.sender).equals(selfName,true)))
        }
        // No text -> do not guess based on timestamp alone.
        if(query.isBlank())return null
        val exact=sameSender.filter {qarComparableText(it.body)==qarComparableText(query)}
        if(exact.size==1)return exact.single().let{it.fingerprint to it.occurrence}
        if(exact.isNotEmpty())return null // same-minute ambiguity
        val comparable=qarWithoutEmoji(query)
        if(comparable.isBlank())return null // emoji-only messages need exact matching
        val matches=sameSender.filter {qarWithoutEmoji(it.body)==comparable}
        return matches.singleOrNull()?.let { it.fingerprint to it.occurrence }
    }
    fun saveReaction(chatId:Long,webId:String,header:String,sender:String,actor:String,emoji:String,timeMs:Long?,messageText:String=""):Boolean {
        val sql=writableDatabase
        val previous=sql.rawQuery("SELECT fingerprint,occurrence,message_text FROM web_reactions WHERE chat_id=? AND web_id=? AND actor=? AND emoji=?",
            arrayOf(chatId.toString(),webId,actor,emoji)).use{c->
            if(c.moveToFirst())Triple(if(c.isNull(0))null else c.getString(0),if(c.isNull(1))null else c.getInt(1),c.getString(2)) else null
        }
        val bestText=messageText.ifBlank { previous?.third.orEmpty() }
        val target=reactionTarget(sql,chatId,sender,timeMs,bestText)
        val fingerprint=target?.first
        val occurrence=target?.second
        sql.insertWithOnConflict("web_reactions",null,ContentValues().apply{
            put("chat_id",chatId);put("web_id",webId);put("web_time",header)
            put("sender",sender);put("actor",actor);put("emoji",emoji)
            put("message_text",bestText)
            if(fingerprint!=null&&occurrence!=null){put("fingerprint",fingerprint);put("occurrence",occurrence)}
            else {putNull("fingerprint");putNull("occurrence")}
        },SQLiteDatabase.CONFLICT_REPLACE)
        return previous==null
    }
    // Retry pending reactions after a new WhatsApp export, or once a better Test 7
    // record supplies the original text. Does not alter user-confirmed links.
    fun retryReactionMatches(chatId:Long):Int {
        val sql=writableDatabase
        var resolved=0
        val pending=mutableListOf<Array<String>>()
        sql.rawQuery("SELECT web_id,actor,emoji,web_time,sender,message_text FROM web_reactions WHERE chat_id=?",
            arrayOf(chatId.toString())).use{c->while(c.moveToNext())pending.add(Array(6){c.getString(it)?:""})}
        // WhatsApp Web Test 7/9-series exports use US month/day/year, whereas
        // legacy Android/UK exports may use day/month/year. The original code
        // retried ALL records as UK, destroying otherwise valid US matches.
        // Accept both formats, but only attach on a UNIQUE exact message match.
        val formats=listOf(
            java.text.SimpleDateFormat("h:mm a, M/d/yyyy",java.util.Locale.US).apply{isLenient=false},
            java.text.SimpleDateFormat("h:mm a, d/M/yyyy",java.util.Locale.UK).apply{isLenient=false}
        )
        for(row in pending){
            val stamp=Regex("""^\[([^]]+)]""").find(row[3])?.groupValues?.get(1).orEmpty()
            val matched=formats.asSequence().mapNotNull{fmt ->
                val time=runCatching{fmt.parse(stamp)?.time}.getOrNull()
                reactionTarget(sql,chatId,row[4],time,row[5])
            }.firstOrNull()
            val updated=ContentValues().apply{
                if(matched!=null){put("fingerprint",matched.first);put("occurrence",matched.second)}
                else {putNull("fingerprint");putNull("occurrence")}
            }
            resolved+=sql.update("web_reactions",updated,"chat_id=? AND web_id=? AND actor=? AND emoji=?",
                arrayOf(chatId.toString(),row[0],row[1],row[2]))
        }
        return resolved
    }
    fun reactionCounts(chatId:Long):Pair<Int,Int> = readableDatabase.rawQuery(
        "SELECT COUNT(*),COALESCE(SUM(CASE WHEN fingerprint IS NULL THEN 1 ELSE 0 END),0) FROM web_reactions WHERE chat_id=?",
        arrayOf(chatId.toString())).use {c->c.moveToFirst();c.getInt(0) to c.getInt(1)}
    fun reactionsByMessage(chatId:Long):Map<String,List<Pair<String,String>>> {
        val result=linkedMapOf<String,MutableList<Pair<String,String>>>()
        readableDatabase.rawQuery("SELECT fingerprint,occurrence,actor,emoji FROM web_reactions WHERE chat_id=? AND fingerprint IS NOT NULL",
            arrayOf(chatId.toString())).use {c->while(c.moveToNext()) {
                val key=c.getString(0)+":"+c.getInt(1)
                result.getOrPut(key){mutableListOf()}.add(c.getString(2) to c.getString(3))
            }}
        return result
    }
    fun clearReactions(chatId:Long) {writableDatabase.delete("web_reactions","chat_id=?",arrayOf(chatId.toString()))}

    // A merged chat is an independently stored conversation with permanent source links.
    // The trigger runs inside every ordinary import / Auto Sync transaction, so future
    // messages are copied atomically and no app-side polling is required.
    private fun createMergedChatTables(sql:SQLiteDatabase) {
        sql.execSQL("CREATE TABLE IF NOT EXISTS merged_chat_sources (merged_chat_id INTEGER NOT NULL, source_chat_id INTEGER NOT NULL, source_key TEXT NOT NULL, PRIMARY KEY(merged_chat_id,source_chat_id))")
        sql.execSQL("CREATE TABLE IF NOT EXISTS merged_bookmark_links (group_id INTEGER NOT NULL, sibling_group_id INTEGER NOT NULL, PRIMARY KEY(group_id,sibling_group_id))")
        sql.execSQL("CREATE INDEX IF NOT EXISTS merged_source_lookup ON merged_chat_sources(source_chat_id)")
        sql.execSQL("""CREATE TRIGGER IF NOT EXISTS merged_message_insert AFTER INSERT ON messages BEGIN
          INSERT OR IGNORE INTO messages(chat_id,time,sender,body,attachment,fingerprint,occurrence)
          SELECT s.merged_chat_id,NEW.time,NEW.sender,NEW.body,NEW.attachment,
                 'merged:' || s.source_key || ':' || NEW.fingerprint,NEW.occurrence
          FROM merged_chat_sources s WHERE s.source_chat_id=NEW.chat_id;
        END""")
        sql.execSQL("""CREATE TRIGGER IF NOT EXISTS merged_reply_insert AFTER INSERT ON reply_links BEGIN
          INSERT OR IGNORE INTO reply_links(chat_id,reply_fingerprint,reply_occurrence,original_fingerprint,original_occurrence)
          SELECT s.merged_chat_id,'merged:'||s.source_key||':'||NEW.reply_fingerprint,NEW.reply_occurrence,
                 'merged:'||s.source_key||':'||NEW.original_fingerprint,NEW.original_occurrence
          FROM merged_chat_sources s WHERE s.source_chat_id=NEW.chat_id;
        END""")
        sql.execSQL("""CREATE TRIGGER IF NOT EXISTS merged_favourite_insert AFTER INSERT ON media_favourites BEGIN
          INSERT OR IGNORE INTO media_favourites(chat_id,fingerprint,occurrence)
          SELECT s.merged_chat_id,'merged:'||s.source_key||':'||NEW.fingerprint,NEW.occurrence
          FROM merged_chat_sources s WHERE s.source_chat_id=NEW.chat_id;
        END""")
    }
    // Copy favourite/voice-label updates from originals into each live merged view.
    // Reverse updates from a merged view target its exact source message; the app
    // methods below also fan out to other merged views of the same original.
    private fun installMergedAnnotationTriggers(sql:SQLiteDatabase) {
        for(name in listOf("merged_fav_del", "merged_voice_ins", "merged_voice_del"))
            sql.execSQL("DROP TRIGGER IF EXISTS $name")
        sql.execSQL("""CREATE TRIGGER merged_fav_del AFTER DELETE ON media_favourites BEGIN
          DELETE FROM media_favourites WHERE EXISTS (SELECT 1 FROM merged_chat_sources s
            WHERE s.source_chat_id=OLD.chat_id AND media_favourites.chat_id=s.merged_chat_id
            AND media_favourites.fingerprint='merged:'||s.source_key||':'||OLD.fingerprint
            AND media_favourites.occurrence=OLD.occurrence);
        END""")
        sql.execSQL("""CREATE TRIGGER merged_voice_ins AFTER INSERT ON voice_labels BEGIN
          INSERT OR REPLACE INTO voice_labels(chat_id,fingerprint,occurrence,label)
          SELECT s.merged_chat_id,'merged:'||s.source_key||':'||NEW.fingerprint,NEW.occurrence,NEW.label
          FROM merged_chat_sources s WHERE s.source_chat_id=NEW.chat_id;
        END""")
        sql.execSQL("""CREATE TRIGGER merged_voice_del AFTER DELETE ON voice_labels BEGIN
          DELETE FROM voice_labels WHERE EXISTS (SELECT 1 FROM merged_chat_sources s
            WHERE s.source_chat_id=OLD.chat_id AND voice_labels.chat_id=s.merged_chat_id
            AND voice_labels.fingerprint='merged:'||s.source_key||':'||OLD.fingerprint
            AND voice_labels.occurrence=OLD.occurrence);
        END""")
    }
    private fun backfillMergedAnnotations(sql:SQLiteDatabase) {
        sql.execSQL("""INSERT OR IGNORE INTO media_favourites(chat_id,fingerprint,occurrence)
          SELECT s.merged_chat_id,'merged:'||s.source_key||':'||f.fingerprint,f.occurrence
          FROM media_favourites f JOIN merged_chat_sources s ON s.source_chat_id=f.chat_id""")
        sql.execSQL("""INSERT OR REPLACE INTO voice_labels(chat_id,fingerprint,occurrence,label)
          SELECT s.merged_chat_id,'merged:'||s.source_key||':'||v.fingerprint,v.occurrence,v.label
          FROM voice_labels v JOIN merged_chat_sources s ON s.source_chat_id=v.chat_id""")
        // Historical groups can be mirrored deterministically once, and linked for deletion.
        val sourceGroups=mutableListOf<Long>()
        sql.rawQuery("SELECT DISTINCT b.id FROM bookmark_groups b JOIN merged_chat_sources s ON s.source_chat_id=b.chat_id",null)
            .use{c->while(c.moveToNext())sourceGroups.add(c.getLong(0))}
        for(id in sourceGroups)mirrorBookmarkGroup(sql,id)
    }
    private fun sourceMessage(sql:SQLiteDatabase,chatId:Long,fp:String,occ:Int):Triple<Long,String,Int> {
        sql.rawQuery("SELECT source_chat_id,source_key FROM merged_chat_sources WHERE merged_chat_id=?",arrayOf(chatId.toString())).use{c->
            while(c.moveToNext()){
                val prefix="merged:${c.getString(1)}:"
                if(fp.startsWith(prefix))return Triple(c.getLong(0),fp.removePrefix(prefix),occ)
            }
        }
        return Triple(chatId,fp,occ)
    }
    private fun relatedMessageRefs(sql:SQLiteDatabase,chatId:Long,fp:String,occ:Int):List<Triple<Long,String,Int>> {
        val (source,raw,num)=sourceMessage(sql,chatId,fp,occ)
        val result=mutableListOf(Triple(source,raw,num))
        sql.rawQuery("SELECT merged_chat_id,source_key FROM merged_chat_sources WHERE source_chat_id=?",arrayOf(source.toString())).use{c->
            while(c.moveToNext())result.add(Triple(c.getLong(0),"merged:${c.getString(1)}:$raw",num))
        }
        return result
    }
    private fun mirrorBookmarkGroup(sql:SQLiteDatabase,groupId:Long) {
        var label="";var saved=0L;var chatId=0L
        sql.rawQuery("SELECT chat_id,label,saved_at FROM bookmark_groups WHERE id=?",arrayOf(groupId.toString())).use{c->
            if(!c.moveToFirst())return
            chatId=c.getLong(0);label=c.getString(1);saved=c.getLong(2)
        }
        val targets=linkedMapOf<Long,MutableSet<Long>>()
        sql.rawQuery("SELECT m.fingerprint,m.occurrence FROM bookmark_items b JOIN messages m ON m.id=b.message_id WHERE b.group_id=?",arrayOf(groupId.toString())).use{c->
            while(c.moveToNext())for((id,fp,occ) in relatedMessageRefs(sql,chatId,c.getString(0),c.getInt(1))){
                sql.rawQuery("SELECT id FROM messages WHERE chat_id=? AND fingerprint=? AND occurrence=?",arrayOf(id.toString(),fp,occ.toString())).use{hit->
                    if(hit.moveToFirst())targets.getOrPut(id){linkedSetOf()}.add(hit.getLong(0))
                }
            }
        }
        for((target,ids) in targets) {
            if(target==chatId || ids.isEmpty())continue
            // Preserve groups sharing the same original annotation without duplicating.
            var mapped=0L
            sql.rawQuery("SELECT sibling_group_id FROM merged_bookmark_links WHERE group_id=? AND sibling_group_id IN (SELECT id FROM bookmark_groups WHERE chat_id=?) LIMIT 1",arrayOf(groupId.toString(),target.toString())).use{c->if(c.moveToFirst())mapped=c.getLong(0)}
            if(mapped==0L){
                mapped=sql.insertOrThrow("bookmark_groups",null,ContentValues().apply{put("chat_id",target);put("label",label);put("saved_at",saved)})
                sql.insertWithOnConflict("merged_bookmark_links",null,ContentValues().apply{put("group_id",groupId);put("sibling_group_id",mapped)},SQLiteDatabase.CONFLICT_IGNORE)
                sql.insertWithOnConflict("merged_bookmark_links",null,ContentValues().apply{put("group_id",mapped);put("sibling_group_id",groupId)},SQLiteDatabase.CONFLICT_IGNORE)
            }
            for(messageId in ids)sql.insertWithOnConflict("bookmark_items",null,ContentValues().apply{put("group_id",mapped);put("message_id",messageId)},SQLiteDatabase.CONFLICT_IGNORE)
        }
    }
    // QAR exists on the original conversation and is mirrored into live merged chats.
    // Source-qualified Web IDs keep reactions from different source chats distinct.
    // Recreate these triggers on upgrade so existing installs are covered too.
    private fun installMergedQarTriggers(sql:SQLiteDatabase) {
        val triggers=listOf("merged_qr_insert","merged_qr_update","merged_qr_delete",
            "merged_ql_update","merged_ql_delete","merged_qs_insert","merged_qs_update","merged_qs_delete")
        triggers.forEach {sql.execSQL("DROP TRIGGER IF EXISTS $it")}
        for(action in listOf("INSERT","UPDATE")) {
            sql.execSQL("""CREATE TRIGGER merged_qr_${action.lowercase(Locale.ROOT)} AFTER $action ON web_reactions BEGIN
              INSERT OR REPLACE INTO web_reactions(chat_id,web_id,web_time,sender,actor,emoji,fingerprint,occurrence,message_text)
              SELECT s.merged_chat_id,'merged:'||s.source_key||':'||NEW.web_id,NEW.web_time,
                     NEW.sender,NEW.actor,NEW.emoji,
                     CASE WHEN NEW.fingerprint IS NULL THEN NULL ELSE 'merged:'||s.source_key||':'||NEW.fingerprint END,
                     NEW.occurrence,NEW.message_text
              FROM merged_chat_sources s WHERE s.source_chat_id=NEW.chat_id;
            END""")
            sql.execSQL("""CREATE TRIGGER merged_qs_${action.lowercase(Locale.ROOT)} AFTER $action ON reply_link_status BEGIN
              INSERT OR REPLACE INTO reply_link_status(chat_id,reply_fingerprint,reply_occurrence,status)
              SELECT s.merged_chat_id,'merged:'||s.source_key||':'||NEW.reply_fingerprint,
                     NEW.reply_occurrence,NEW.status
              FROM merged_chat_sources s WHERE s.source_chat_id=NEW.chat_id;
            END""")
        }
        sql.execSQL("""CREATE TRIGGER merged_qr_delete AFTER DELETE ON web_reactions BEGIN
          DELETE FROM web_reactions WHERE EXISTS (SELECT 1 FROM merged_chat_sources s
            WHERE s.source_chat_id=OLD.chat_id AND web_reactions.chat_id=s.merged_chat_id
            AND web_reactions.web_id='merged:'||s.source_key||':'||OLD.web_id
            AND web_reactions.actor=OLD.actor AND web_reactions.emoji=OLD.emoji);
        END""")
        sql.execSQL("""CREATE TRIGGER merged_ql_update AFTER UPDATE ON reply_links BEGIN
          DELETE FROM reply_links WHERE EXISTS (SELECT 1 FROM merged_chat_sources s
            WHERE s.source_chat_id=OLD.chat_id AND reply_links.chat_id=s.merged_chat_id
            AND reply_links.reply_fingerprint='merged:'||s.source_key||':'||OLD.reply_fingerprint
            AND reply_links.reply_occurrence=OLD.reply_occurrence);
          INSERT OR REPLACE INTO reply_links(chat_id,reply_fingerprint,reply_occurrence,original_fingerprint,original_occurrence)
          SELECT s.merged_chat_id,'merged:'||s.source_key||':'||NEW.reply_fingerprint,NEW.reply_occurrence,
                 'merged:'||s.source_key||':'||NEW.original_fingerprint,NEW.original_occurrence
          FROM merged_chat_sources s WHERE s.source_chat_id=NEW.chat_id;
        END""")
        sql.execSQL("""CREATE TRIGGER merged_ql_delete AFTER DELETE ON reply_links BEGIN
          DELETE FROM reply_links WHERE EXISTS (SELECT 1 FROM merged_chat_sources s
            WHERE s.source_chat_id=OLD.chat_id AND reply_links.chat_id=s.merged_chat_id
            AND reply_links.reply_fingerprint='merged:'||s.source_key||':'||OLD.reply_fingerprint
            AND reply_links.reply_occurrence=OLD.reply_occurrence);
        END""")
        sql.execSQL("""CREATE TRIGGER merged_qs_delete AFTER DELETE ON reply_link_status BEGIN
          DELETE FROM reply_link_status WHERE EXISTS (SELECT 1 FROM merged_chat_sources s
            WHERE s.source_chat_id=OLD.chat_id AND reply_link_status.chat_id=s.merged_chat_id
            AND reply_link_status.reply_fingerprint='merged:'||s.source_key||':'||OLD.reply_fingerprint
            AND reply_link_status.reply_occurrence=OLD.reply_occurrence);
        END""")
    }
    private fun backfillMergedQar(sql:SQLiteDatabase) {
        sql.execSQL("""INSERT OR REPLACE INTO web_reactions(chat_id,web_id,web_time,sender,actor,emoji,fingerprint,occurrence,message_text)
          SELECT s.merged_chat_id,'merged:'||s.source_key||':'||r.web_id,r.web_time,r.sender,r.actor,r.emoji,
                 CASE WHEN r.fingerprint IS NULL THEN NULL ELSE 'merged:'||s.source_key||':'||r.fingerprint END,
                 r.occurrence,r.message_text
          FROM web_reactions r JOIN merged_chat_sources s ON s.source_chat_id=r.chat_id""")
        sql.execSQL("""INSERT OR REPLACE INTO reply_links(chat_id,reply_fingerprint,reply_occurrence,original_fingerprint,original_occurrence)
          SELECT s.merged_chat_id,'merged:'||s.source_key||':'||r.reply_fingerprint,r.reply_occurrence,
                 'merged:'||s.source_key||':'||r.original_fingerprint,r.original_occurrence
          FROM reply_links r JOIN merged_chat_sources s ON s.source_chat_id=r.chat_id""")
        sql.execSQL("""INSERT OR REPLACE INTO reply_link_status(chat_id,reply_fingerprint,reply_occurrence,status)
          SELECT s.merged_chat_id,'merged:'||s.source_key||':'||r.reply_fingerprint,r.reply_occurrence,r.status
          FROM reply_link_status r JOIN merged_chat_sources s ON s.source_chat_id=r.chat_id""")
    }
    fun isMergedChat(chatId:Long):Boolean=readableDatabase.rawQuery(
        "SELECT 1 FROM merged_chat_sources WHERE merged_chat_id=? LIMIT 1",arrayOf(chatId.toString())
    ).use{it.moveToFirst()}
    fun mergedSourceNames(chatId:Long):List<String> = readableDatabase.rawQuery(
        "SELECT c.name FROM merged_chat_sources s JOIN chats c ON c.id=s.source_chat_id WHERE s.merged_chat_id=? ORDER BY c.name",arrayOf(chatId.toString())
    ).use{c->buildList{while(c.moveToNext())add(c.getString(0))}}
    fun createLiveMergedChat(name:String,sourceIds:List<Long>):Long {
        require(name.isNotBlank()){"Choose a name for the merged chat"}
        require(sourceIds.distinct().size>=2){"Select at least two chats"}
        val sql=writableDatabase
        sql.beginTransaction()
        try {
            for(id in sourceIds.distinct()){
                require(!sql.rawQuery("SELECT 1 FROM chats WHERE id=?",arrayOf(id.toString())).use{it.moveToFirst()}.not()){"Missing source chat"}
                require(!sql.rawQuery("SELECT 1 FROM merged_chat_sources WHERE merged_chat_id=?",arrayOf(id.toString())).use{it.moveToFirst()}){"Merging an existing merged chat is not supported yet"}
            }
            val result=sql.insertOrThrow("chats",null,ContentValues().apply{put("name",name.trim())})
            for(id in sourceIds.distinct()){
                sql.insertOrThrow("merged_chat_sources",null,ContentValues().apply{
                    put("merged_chat_id",result);put("source_chat_id",id);put("source_key",id.toString())
                })
                sql.execSQL("""INSERT OR IGNORE INTO messages(chat_id,time,sender,body,attachment,fingerprint,occurrence)
                    SELECT ?,time,sender,body,attachment,'merged:'||?||':'||fingerprint,occurrence
                    FROM messages WHERE chat_id=?""",arrayOf(result,id.toString(),id))
                sql.execSQL("""INSERT OR IGNORE INTO reply_links(chat_id,reply_fingerprint,reply_occurrence,original_fingerprint,original_occurrence)
                    SELECT ?,'merged:'||?||':'||reply_fingerprint,reply_occurrence,
                    'merged:'||?||':'||original_fingerprint,original_occurrence FROM reply_links WHERE chat_id=?""",
                    arrayOf(result,id.toString(),id.toString(),id))
                sql.execSQL("""INSERT OR IGNORE INTO voice_labels(chat_id,fingerprint,occurrence,label)
                    SELECT ?,'merged:'||?||':'||fingerprint,occurrence,label FROM voice_labels WHERE chat_id=?""",arrayOf(result,id.toString(),id))
                sql.execSQL("""INSERT OR IGNORE INTO media_favourites(chat_id,fingerprint,occurrence)
                    SELECT ?,'merged:'||?||':'||fingerprint,occurrence FROM media_favourites WHERE chat_id=?""",arrayOf(result,id.toString(),id))
                sql.execSQL("""INSERT OR REPLACE INTO web_reactions(chat_id,web_id,web_time,sender,actor,emoji,fingerprint,occurrence,message_text)
                    SELECT ?,'merged:'||?||':'||web_id,web_time,sender,actor,emoji,
                    CASE WHEN fingerprint IS NULL THEN NULL ELSE 'merged:'||?||':'||fingerprint END,
                    occurrence,message_text FROM web_reactions WHERE chat_id=?""",arrayOf(result,id.toString(),id.toString(),id))
                sql.execSQL("""INSERT OR REPLACE INTO reply_link_status(chat_id,reply_fingerprint,reply_occurrence,status)
                    SELECT ?,'merged:'||?||':'||reply_fingerprint,reply_occurrence,status
                    FROM reply_link_status WHERE chat_id=?""",arrayOf(result,id.toString(),id))
            }
            val groups=mutableListOf<Long>()
            sql.rawQuery("SELECT b.id FROM bookmark_groups b JOIN merged_chat_sources s ON s.source_chat_id=b.chat_id WHERE s.merged_chat_id=?",arrayOf(result.toString())).use{c->while(c.moveToNext())groups.add(c.getLong(0))}
            groups.forEach{mirrorBookmarkGroup(sql,it)}
            sql.setTransactionSuccessful()
            return result
        }finally{sql.endTransaction()}
    }
    private fun createMediaFavouritesTable(sql:SQLiteDatabase){
        sql.execSQL("CREATE TABLE IF NOT EXISTS media_favourites (chat_id INTEGER NOT NULL, fingerprint TEXT NOT NULL, occurrence INTEGER NOT NULL, PRIMARY KEY(chat_id,fingerprint,occurrence))")
    }
    fun isMediaFavourite(chatId:Long,m:Message):Boolean=readableDatabase.rawQuery(
        "SELECT 1 FROM media_favourites WHERE chat_id=? AND fingerprint=? AND occurrence=? LIMIT 1",
        arrayOf(chatId.toString(),m.fingerprint,m.occurrence.toString())
    ).use{it.moveToFirst()}
    fun setMediaFavourite(chatId:Long,m:Message,enabled:Boolean){
        val sql=writableDatabase
        sql.beginTransaction()
        try{
            for((id,fp,occ) in relatedMessageRefs(sql,chatId,m.fingerprint,m.occurrence)){
                if(enabled)sql.insertWithOnConflict("media_favourites",null,ContentValues().apply{
                    put("chat_id",id);put("fingerprint",fp);put("occurrence",occ)
                },SQLiteDatabase.CONFLICT_IGNORE)
                else sql.delete("media_favourites","chat_id=? AND fingerprint=? AND occurrence=?",arrayOf(id.toString(),fp,occ.toString()))
            }
            sql.setTransactionSuccessful()
        }finally{sql.endTransaction()}
    }
    private fun createAutoSyncTables(sql:SQLiteDatabase) {
        sql.execSQL("CREATE TABLE IF NOT EXISTS auto_sync_batches (id INTEGER PRIMARY KEY AUTOINCREMENT, file_hash TEXT NOT NULL UNIQUE, display_name TEXT NOT NULL, chat_id INTEGER NOT NULL, kind TEXT NOT NULL, added INTEGER NOT NULL DEFAULT 0, duplicates INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL, imported_at INTEGER NOT NULL)")
        sql.execSQL("CREATE TABLE IF NOT EXISTS auto_sync_added (batch_id INTEGER NOT NULL, message_id INTEGER NOT NULL UNIQUE, PRIMARY KEY(batch_id,message_id))")
        sql.execSQL("CREATE TABLE IF NOT EXISTS auto_sync_links (batch_id INTEGER NOT NULL, chat_id INTEGER NOT NULL, reply_fingerprint TEXT NOT NULL, reply_occurrence INTEGER NOT NULL, original_fingerprint TEXT NOT NULL, original_occurrence INTEGER NOT NULL, PRIMARY KEY(batch_id,reply_fingerprint,reply_occurrence))")
        sql.execSQL("CREATE TABLE IF NOT EXISTS manual_import_events (chat_id INTEGER NOT NULL, imported_at INTEGER NOT NULL)")
    }
    private fun createAutoSyncAliases(sql:SQLiteDatabase) {
        sql.execSQL("CREATE TABLE IF NOT EXISTS auto_sync_sources (kind TEXT NOT NULL, source_key TEXT NOT NULL, chat_id INTEGER NOT NULL, PRIMARY KEY(kind,source_key))")
        sql.execSQL("CREATE TABLE IF NOT EXISTS auto_sync_created (chat_id INTEGER PRIMARY KEY)")
    }
    fun sourceOwner(kind:String,key:String):Long?=readableDatabase.rawQuery(
        "SELECT chat_id FROM auto_sync_sources WHERE kind=? AND source_key=?",arrayOf(kind,key)
    ).use{if(it.moveToFirst())it.getLong(0) else null}
    fun sourceNames(chatId:Long):List<Pair<String,String>> =readableDatabase.rawQuery(
        "SELECT kind,source_key FROM auto_sync_sources WHERE chat_id=? ORDER BY kind,source_key",arrayOf(chatId.toString())
    ).use{c->buildList{while(c.moveToNext())add(c.getString(0) to c.getString(1))}}
    fun rememberSource(kind:String,key:String,chatId:Long) {
        require(chats().any{it.id==chatId}){"Conversation no longer exists"}
        val owner=sourceOwner(kind,key)
        require(owner==null || owner==chatId){"This source name is assigned to another conversation"}
        writableDatabase.insertWithOnConflict("auto_sync_sources",null,ContentValues().apply{
            put("kind",kind);put("source_key",key);put("chat_id",chatId)
        },SQLiteDatabase.CONFLICT_IGNORE)
    }
    fun unlinkSource(kind:String,key:String,chatId:Long) {
        writableDatabase.delete("auto_sync_sources","kind=? AND source_key=? AND chat_id=?",arrayOf(kind,key,chatId.toString()))
    }
    fun createAutoChat(name:String):Long {
        val sql=writableDatabase
        sql.beginTransaction()
        try {
            val id=sql.insertOrThrow("chats",null,ContentValues().apply{put("name",name)})
            sql.insertOrThrow("auto_sync_created",null,ContentValues().apply{put("chat_id",id)})
            sql.setTransactionSuccessful()
            return id
        } finally {sql.endTransaction()}
    }
    fun confirmAllAutoCreatedChats():Int {
        val sql=writableDatabase
        val count=sql.delete("auto_sync_created",null,null)
        return count
    }
    /** A clean global QAR rebuild uses one SQLite transaction for the wipe and every
     * source import. A failed import rolls all database QAR changes back. */
    fun <T> atomicQarRebuild(block:()->T):T {
        val sql=writableDatabase
        sql.beginTransaction()
        try {
            val result=block()
            sql.setTransactionSuccessful()
            return result
        }finally{sql.endTransaction()}
    }

    /** Remove ALL QAR state across ALL conversations, including manually confirmed
     * associations, pending reactions, and prior QAR source/import bookkeeping.
     * Chat messages, media, bookmarks, identities and settings are untouched.
     * Coverage for deleted QAR files must be removed, or the timeline would lie. */
    fun clearAllQarForRebuild() {
        val sql=writableDatabase
        sql.execSQL("DELETE FROM reply_links")
        sql.execSQL("DELETE FROM reply_link_status")
        sql.execSQL("DELETE FROM auto_sync_links")
        sql.execSQL("DELETE FROM web_reactions")
        sql.execSQL("DELETE FROM web_second_evidence")
        sql.execSQL("DELETE FROM web_scan_coverage WHERE batch_id IN (SELECT id FROM auto_sync_batches WHERE kind='quote')")
        sql.execSQL("DELETE FROM reply_scan_events")
        sql.execSQL("DELETE FROM web_history_resume")
        sql.execSQL("DELETE FROM auto_sync_sources WHERE kind='quote'")
        sql.execSQL("DELETE FROM auto_sync_batches WHERE kind='quote'")
    }

    fun allQuoteBatchHashes():List<String> = readableDatabase.rawQuery(
        "SELECT file_hash FROM auto_sync_batches WHERE kind='quote' AND status IN ('completed','waiting')",null
    ).use{c->buildList{while(c.moveToNext())add(c.getString(0))}}
    /** Delete only auto-generated QAR associations with unchanged automatic status.
     * User-confirmed and manually edited quoted links are never removed. */
    fun clearAutoQarAssociations(chatId:Long) {
        val sql=writableDatabase
        sql.beginTransaction()
        try {
            sql.execSQL("""DELETE FROM reply_links WHERE chat_id=? AND EXISTS (
                SELECT 1 FROM auto_sync_links a JOIN reply_link_status s
                ON s.chat_id=a.chat_id AND s.reply_fingerprint=a.reply_fingerprint
                AND s.reply_occurrence=a.reply_occurrence AND s.status='auto'
                WHERE a.chat_id=reply_links.chat_id
                AND a.reply_fingerprint=reply_links.reply_fingerprint
                AND a.reply_occurrence=reply_links.reply_occurrence
                AND a.original_fingerprint=reply_links.original_fingerprint
                AND a.original_occurrence=reply_links.original_occurrence
            )""",arrayOf(chatId))
            // Remove no-longer-active auto status rows; never touch confirmed ones.
            sql.execSQL("""DELETE FROM reply_link_status WHERE chat_id=? AND status='auto'
                AND NOT EXISTS (SELECT 1 FROM reply_links l WHERE l.chat_id=reply_link_status.chat_id
                AND l.reply_fingerprint=reply_link_status.reply_fingerprint
                AND l.reply_occurrence=reply_link_status.reply_occurrence)""",arrayOf(chatId))
            // Retain tracking for manual/confirmed links. Drop only associations
            // whose original auto link was removed above.
            sql.execSQL("""DELETE FROM auto_sync_links WHERE chat_id=? AND NOT EXISTS (
                SELECT 1 FROM reply_links r WHERE r.chat_id=auto_sync_links.chat_id
                AND r.reply_fingerprint=auto_sync_links.reply_fingerprint
                AND r.reply_occurrence=auto_sync_links.reply_occurrence
                AND r.original_fingerprint=auto_sync_links.original_fingerprint
                AND r.original_occurrence=auto_sync_links.original_occurrence
            )""",arrayOf(chatId))
            // Existing reactions stay stored as evidence. Their message associations
            // will be recalculated during the new UK-date import pass.
            sql.setTransactionSuccessful()
        }finally{sql.endTransaction()}
    }

    fun confirmAutoCreatedChat(chatId:Long):Boolean {
        // Only remove the review flag; leave the chat, source links, batches and files intact.
        val removed=writableDatabase.delete("auto_sync_created","chat_id=?",arrayOf(chatId.toString()))
        return removed>0 && autoCreatedChats().none{it.id==chatId}
    }
    fun autoCreatedChats():List<Chat> {
        val ids=readableDatabase.rawQuery("SELECT chat_id FROM auto_sync_created",null).use{c->buildSet{while(c.moveToNext())add(c.getLong(0))}}
        return chats().filter{it.id in ids}
    }
    fun removeEmptyAutoCreatedChat(chatId:Long):Boolean {
        val sql=writableDatabase
        sql.beginTransaction()
        try {
            if(!sql.rawQuery("SELECT 1 FROM auto_sync_created WHERE chat_id=?",arrayOf(chatId.toString())).use{it.moveToFirst()})return false
            if(sql.rawQuery("SELECT 1 FROM messages WHERE chat_id=? LIMIT 1",arrayOf(chatId.toString())).use{it.moveToFirst()})return false
            if(sql.rawQuery("SELECT 1 FROM manual_import_events WHERE chat_id=? LIMIT 1",arrayOf(chatId.toString())).use{it.moveToFirst()})return false
            for(table in listOf("bookmark_groups","voice_labels","reply_links")){
                if(sql.rawQuery("SELECT 1 FROM $table WHERE chat_id=? LIMIT 1",arrayOf(chatId.toString())).use{it.moveToFirst()})return false
            }
            sql.delete("auto_sync_sources","chat_id=?",arrayOf(chatId.toString()))
            sql.delete("auto_sync_created","chat_id=?",arrayOf(chatId.toString()))
            sql.delete("auto_sync_batches","chat_id=?",arrayOf(chatId.toString()))
            sql.delete("chats","id=?",arrayOf(chatId.toString()))
            sql.setTransactionSuccessful()
            return true
        } finally {sql.endTransaction()}
    }
    fun mergeAutoCreatedChat(sourceId:Long,destId:Long):String {
        require(sourceId!=destId){"Choose a different destination"}
        val sql=writableDatabase
        sql.beginTransaction()
        try {
            require(sql.rawQuery("SELECT 1 FROM auto_sync_created WHERE chat_id=?",arrayOf(sourceId.toString())).use{it.moveToFirst()}){"Only automatically created chats can be merged here"}
            require(sql.rawQuery("SELECT 1 FROM chats WHERE id=?",arrayOf(destId.toString())).use{it.moveToFirst()}){"Destination missing"}
            for(table in listOf("bookmark_groups","voice_labels","reply_links","sender_names","sender_aliases","manual_import_events")) {
                require(!sql.rawQuery("SELECT 1 FROM $table WHERE chat_id=? LIMIT 1",arrayOf(sourceId.toString())).use{it.moveToFirst()}){
                    "This chat contains manual changes; merge is blocked to protect them"
                }
            }
            require(!sql.rawQuery("SELECT 1 FROM auto_sync_links WHERE chat_id=? LIMIT 1",arrayOf(sourceId.toString())).use{it.moveToFirst()}){"This chat has quoted links; merge is blocked"}
            val sourceMessages=mutableListOf<Pair<Long,Pair<String,Int>>>()
            sql.rawQuery("SELECT id,fingerprint,occurrence FROM messages WHERE chat_id=?",arrayOf(sourceId.toString())).use{c->
                while(c.moveToNext())sourceMessages.add(c.getLong(0) to (c.getString(1) to c.getInt(2)))
            }
            // Distinguish true additions from messages already present in the destination,
            // so undo never treats a pre-existing manual message as auto-imported.
            val presentBefore=mutableSetOf<Pair<String,Int>>()
            sql.rawQuery("SELECT fingerprint,occurrence FROM messages WHERE chat_id=?",arrayOf(destId.toString())).use{c->
                while(c.moveToNext())presentBefore.add(c.getString(0) to c.getInt(1))
            }
            sql.execSQL("INSERT OR IGNORE INTO messages(chat_id,time,sender,body,attachment,fingerprint,occurrence) SELECT ?,time,sender,body,attachment,fingerprint,occurrence FROM messages WHERE chat_id=?",arrayOf(destId,sourceId))
            for((oldId,identity) in sourceMessages) {
                val newId=sql.rawQuery("SELECT id FROM messages WHERE chat_id=? AND fingerprint=? AND occurrence=?",arrayOf(destId.toString(),identity.first,identity.second.toString())).use{c->require(c.moveToFirst());c.getLong(0)}
                // If the destination already had a record, it remains owned by its earlier import.
                val tracked=identity in presentBefore || sql.rawQuery("SELECT 1 FROM auto_sync_added WHERE message_id=?",arrayOf(newId.toString())).use{it.moveToFirst()}
                if(tracked)sql.delete("auto_sync_added","message_id=?",arrayOf(oldId.toString()))
                else sql.execSQL("UPDATE auto_sync_added SET message_id=? WHERE message_id=?",arrayOf(newId,oldId))
            }
            sql.execSQL("UPDATE auto_sync_batches SET chat_id=? WHERE chat_id=?",arrayOf(destId,sourceId))
            sql.execSQL("UPDATE auto_sync_sources SET chat_id=? WHERE chat_id=?",arrayOf(destId,sourceId))
            sql.delete("messages","chat_id=?",arrayOf(sourceId.toString()))
            sql.delete("auto_sync_created","chat_id=?",arrayOf(sourceId.toString()))
            sql.delete("chats","id=?",arrayOf(sourceId.toString()))
            sql.setTransactionSuccessful()
            return "Merged ${sourceMessages.size} source messages into the existing conversation (duplicates skipped). Source filenames will now sync here."
        } finally {sql.endTransaction()}
    }
    internal data class AutoBatch(val id:Long,val fileName:String,val chatId:Long,val kind:String,val added:Int,val duplicates:Int,val status:String,val time:Long)
    fun autoBatch(hash:String):AutoBatch? = readableDatabase.rawQuery("SELECT id,display_name,chat_id,kind,added,duplicates,status,imported_at FROM auto_sync_batches WHERE file_hash=?",arrayOf(hash)).use{c->if(c.moveToFirst())AutoBatch(c.getLong(0),c.getString(1),c.getLong(2),c.getString(3),c.getInt(4),c.getInt(5),c.getString(6),c.getLong(7))else null}
    fun findAutoBatch(hash:String):AutoBatch? = readableDatabase.rawQuery("SELECT id,display_name,chat_id,kind,added,duplicates,status,imported_at FROM auto_sync_batches WHERE file_hash=? LIMIT 1",arrayOf(hash)).use{c->
        if(c.moveToFirst())AutoBatch(c.getLong(0),c.getString(1),c.getLong(2),c.getString(3),c.getInt(4),c.getInt(5),c.getString(6),c.getLong(7)) else null
    }
    fun autoBatchExists(hash:String):Boolean = autoBatch(hash)!=null
    fun addAutoBatch(hash:String,name:String,chatId:Long,kind:String):Long = writableDatabase.insertOrThrow("auto_sync_batches",null,ContentValues().apply{
        put("file_hash",hash);put("display_name",name);put("chat_id",chatId);put("kind",kind);put("status","importing");put("imported_at",System.currentTimeMillis())
    })
    fun finishAutoBatch(batchId:Long,added:Int,duplicates:Int,status:String="completed") {
        writableDatabase.execSQL("UPDATE auto_sync_batches SET added=added+?,duplicates=?,status=? WHERE id=?",arrayOf(added,duplicates,status,batchId))
    }
    fun autoBatches():List<AutoBatch> = readableDatabase.rawQuery("SELECT id,display_name,chat_id,kind,added,duplicates,status,imported_at FROM auto_sync_batches ORDER BY id DESC LIMIT 100",null).use{c->
        buildList{while(c.moveToNext())add(AutoBatch(c.getLong(0),c.getString(1),c.getLong(2),c.getString(3),c.getInt(4),c.getInt(5),c.getString(6),c.getLong(7)))}
    }
    fun scannerQuoteEvidence(chatId:Long,samples:List<Pair<Long,String>>):Int {
        val db=readableDatabase
        var hits=0
        for((time,rawBody) in samples) {
            val base=(time/60000L)*60000L
            val expected=rawBody.trim().replace(Regex("\\s+")," ")
            db.rawQuery("SELECT body FROM messages WHERE chat_id=? AND time>=? AND time<? LIMIT 6",
                arrayOf(chatId.toString(),base.toString(),(base+60000L).toString())).use { cursor ->
                var matched=false
                while(cursor.moveToNext()) {
                    if(cursor.getString(0).trim().replace(Regex("\\s+")," ")==expected)matched=true
                }
                if(matched)hits++
            }
        }
        return hits
    }

    fun autoMatchedMessages(chatId:Long,items:List<Message>):Int {
        if(items.isEmpty())return 0
        val sample=items.filter{it.sender.isNotBlank() && !it.sender.equals("System",true)}.let { if(it.size<=90)it else it.take(45)+it.takeLast(45) }
        var matched=0
        for(m in sample.distinctBy{Triple(it.time,it.sender,it.body)}) {
            readableDatabase.rawQuery("SELECT 1 FROM messages WHERE chat_id=? AND time=? AND body=? AND sender=? LIMIT 1",arrayOf(chatId.toString(),m.time.toString(),m.body,m.sender)).use{if(it.moveToFirst())matched++}
        }
        return matched
    }

    // Web TXT has seconds whereas Android exports normally have minutes. Keep
    // an independent, removable evidence record: changing message.time would
    // invalidate existing fingerprints, bookmarks and merged-chat links.
    private fun createWebEvidence(sql:SQLiteDatabase) {
        sql.execSQL("""CREATE TABLE IF NOT EXISTS web_second_evidence (
            chat_id INTEGER NOT NULL, fingerprint TEXT NOT NULL, occurrence INTEGER NOT NULL,
            source_hash TEXT NOT NULL, exact_time INTEGER NOT NULL,
            PRIMARY KEY(chat_id,fingerprint,occurrence,source_hash))""")
    }
    fun recordWebSeconds(chatId:Long,message:Message,time:Long,sourceHash:String) {
        writableDatabase.insertWithOnConflict("web_second_evidence",null,ContentValues().apply {
            put("chat_id",chatId);put("fingerprint",message.fingerprint);put("occurrence",message.occurrence)
            put("source_hash",sourceHash);put("exact_time",time)
        },SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun webSecond(chatId:Long,message:Message):Long? = readableDatabase.rawQuery(
        "SELECT exact_time FROM web_second_evidence WHERE chat_id=? AND fingerprint=? AND occurrence=? GROUP BY exact_time HAVING COUNT(*)>=1 ORDER BY COUNT(*) DESC LIMIT 1",
        arrayOf(chatId.toString(),message.fingerprint,message.occurrence.toString())
    ).use{c->if(c.moveToFirst())c.getLong(0)else null}
    fun reconcileMarkdownQuote(chatId:Long,reply:Message,original:Message,batchId:Long):String {
        if(reply.fingerprint==original.fingerprint && reply.occurrence==original.occurrence)return "ambiguous"
        val prior=replyTarget(chatId,reply)
        if(prior!=null && prior.fingerprint==original.fingerprint && prior.occurrence==original.occurrence){
            if(replyStatus(chatId,reply)=="auto")updateReplyStatus(chatId,reply,"web_verified")
            return "verified"
        }
        // Never silently replace a manual decision or any link whose provenance
        // is unknown. A WEB disagreement is reported, not guessed away.
        if(prior!=null && replyStatus(chatId,reply) !in listOf("auto","web_verified"))return "conflict"
        if(prior!=null && replyStatus(chatId,reply)=="web_verified")return "conflict"
        if(prior!=null) {
            setReplyLink(chatId,reply,original)
            updateReplyStatus(chatId,reply,"web_verified")
            return "corrected"
        }
        setReplyLink(chatId,reply,original)
        updateReplyStatus(chatId,reply,"web_verified")
        return "added"
    }

    fun autoLinkedReply(chatId:Long,reply:Message,original:Message,batchId:Long):Boolean {
        if(reply.fingerprint==original.fingerprint && reply.occurrence==original.occurrence)return false
        // Automatic syncing never overwrites a user-confirmed or existing association.
        if(replyTarget(chatId,reply)!=null)return false
        val sql=writableDatabase
        sql.beginTransaction()
        try {
            if(replyTarget(chatId,reply)!=null)return false
            setReplyLink(chatId,reply,original)
            updateReplyStatus(chatId,reply,"auto")
            sql.insertOrThrow("auto_sync_links",null,ContentValues().apply{
                put("batch_id",batchId);put("chat_id",chatId);put("reply_fingerprint",reply.fingerprint);put("reply_occurrence",reply.occurrence)
                put("original_fingerprint",original.fingerprint);put("original_occurrence",original.occurrence)
            })
            sql.setTransactionSuccessful()
            return true
        } finally {sql.endTransaction()}
    }
    fun undoAutoBatch(batchId:Long):String {
        val batch=autoBatches().find{it.id==batchId} ?: return "Sync not found"
        if(batch.status !in listOf("completed","pending"))return "This sync is not completed and has no committed changes to undo."
        // Never undo a batch if another successful sync has since used the same conversation.
        val hasLater=readableDatabase.rawQuery("SELECT 1 FROM auto_sync_batches WHERE chat_id=? AND id>? AND status='completed' LIMIT 1",arrayOf(batch.chatId.toString(),batchId.toString())).use{it.moveToFirst()}
        if(hasLater)return "A newer auto sync depends on this conversation. Undo the newer sync first."
        val manualLater=readableDatabase.rawQuery("SELECT 1 FROM manual_import_events WHERE chat_id=? AND imported_at>? LIMIT 1",arrayOf(batch.chatId.toString(),batch.time.toString())).use{it.moveToFirst()}
        if(manualLater)return "A manual import occurred after this sync. Undo is blocked so manually imported messages cannot be lost."
        val sql=writableDatabase
        var removed=0
        sql.beginTransaction()
        try {
            val ids=mutableListOf<Long>()
            sql.rawQuery("SELECT message_id FROM auto_sync_added WHERE batch_id=?",arrayOf(batchId.toString())).use{c->while(c.moveToNext())ids.add(c.getLong(0))}
            for(id in ids) {
                val bookmarked=sql.rawQuery("SELECT 1 FROM bookmark_items WHERE message_id=? LIMIT 1",arrayOf(id.toString())).use{it.moveToFirst()}
                val linked=sql.rawQuery("SELECT 1 FROM messages m JOIN reply_links l ON l.chat_id=m.chat_id AND ((l.reply_fingerprint=m.fingerprint AND l.reply_occurrence=m.occurrence) OR (l.original_fingerprint=m.fingerprint AND l.original_occurrence=m.occurrence)) WHERE m.id=? LIMIT 1",arrayOf(id.toString())).use{it.moveToFirst()}
                if(bookmarked || linked)return "Undo blocked: some messages are bookmarked or linked to quoted messages. Remove those associations first, or keep this sync."
            }
            // Quoted links are removed only if they still point to their original automatic target.
            sql.rawQuery("SELECT reply_fingerprint,reply_occurrence,original_fingerprint,original_occurrence FROM auto_sync_links WHERE batch_id=?",arrayOf(batchId.toString())).use{c->
                while(c.moveToNext()) {
                    val replyFp=c.getString(0);val replyOcc=c.getInt(1);val originalFp=c.getString(2);val originalOcc=c.getInt(3)
                    val unchanged=sql.rawQuery("SELECT 1 FROM reply_links WHERE chat_id=? AND reply_fingerprint=? AND reply_occurrence=? AND original_fingerprint=? AND original_occurrence=? LIMIT 1",arrayOf(batch.chatId.toString(),replyFp,replyOcc.toString(),originalFp,originalOcc.toString())).use{it.moveToFirst()}
                    val status=sql.rawQuery("SELECT status FROM reply_link_status WHERE chat_id=? AND reply_fingerprint=? AND reply_occurrence=?",arrayOf(batch.chatId.toString(),replyFp,replyOcc.toString())).use{if(it.moveToFirst())it.getString(0)else ""}
                    if(unchanged && status!="auto")return "Some quoted links have been reviewed or edited; undo is blocked to protect them."
                }
            }
            sql.execSQL("DELETE FROM reply_link_status WHERE chat_id=? AND EXISTS (SELECT 1 FROM auto_sync_links l WHERE l.batch_id=? AND l.chat_id=reply_link_status.chat_id AND l.reply_fingerprint=reply_link_status.reply_fingerprint AND l.reply_occurrence=reply_link_status.reply_occurrence AND l.original_fingerprint=(SELECT original_fingerprint FROM reply_links WHERE chat_id=l.chat_id AND reply_fingerprint=l.reply_fingerprint AND reply_occurrence=l.reply_occurrence) AND l.original_occurrence=(SELECT original_occurrence FROM reply_links WHERE chat_id=l.chat_id AND reply_fingerprint=l.reply_fingerprint AND reply_occurrence=l.reply_occurrence))",arrayOf(batch.chatId,batchId))
            sql.execSQL("DELETE FROM reply_links WHERE chat_id=? AND EXISTS (SELECT 1 FROM auto_sync_links l WHERE l.batch_id=? AND l.chat_id=reply_links.chat_id AND l.reply_fingerprint=reply_links.reply_fingerprint AND l.reply_occurrence=reply_links.reply_occurrence AND l.original_fingerprint=reply_links.original_fingerprint AND l.original_occurrence=reply_links.original_occurrence)",arrayOf(batch.chatId,batchId))
            sql.delete("auto_sync_links","batch_id=?",arrayOf(batchId.toString()))
            for(id in ids)removed+=sql.delete("messages","id=?",arrayOf(id.toString()))
            sql.delete("auto_sync_added","batch_id=?",arrayOf(batchId.toString()))
            sql.delete("web_scan_coverage","batch_id=?",arrayOf(batchId.toString()))
            sql.update("auto_sync_batches",ContentValues().apply{put("status","undone")},"id=?",arrayOf(batchId.toString()))
            sql.setTransactionSuccessful()
        }finally{sql.endTransaction()}
        return "Undid $removed messages. The original export file was not changed."
    }
    data class ScanCoverage(val batchId:Long,val oldest:Long,val newest:Long,val count:Int,val reason:String,val newestId:String,val oldestId:String)
    private fun createScanCoverage(db:SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS web_scan_coverage (chat_id INTEGER NOT NULL, batch_id INTEGER NOT NULL, oldest INTEGER NOT NULL, newest INTEGER NOT NULL, message_count INTEGER NOT NULL, stop_reason TEXT NOT NULL, newest_id TEXT NOT NULL, oldest_id TEXT NOT NULL, PRIMARY KEY(chat_id,batch_id))")
        db.execSQL("CREATE INDEX IF NOT EXISTS coverage_by_chat ON web_scan_coverage(chat_id,oldest,newest)")
    }
    fun addScanCoverage(chatId:Long,batchId:Long,oldest:Long,newest:Long,newestId:String,oldestId:String,count:Int,reason:String) {
        require(oldest<=newest)
        writableDatabase.insertWithOnConflict("web_scan_coverage",null,ContentValues().apply {
            put("chat_id",chatId);put("batch_id",batchId);put("oldest",oldest);put("newest",newest)
            put("message_count",count);put("stop_reason",reason.take(80));put("newest_id",newestId);put("oldest_id",oldestId)
        },SQLiteDatabase.CONFLICT_REPLACE)
    }
    /** Verified Web TXT message anchors from successfully imported Web ZIPs.
     * Every such source also contains Markdown and was parsed for quote evidence.
     * Keep this separate from reaction coverage: Web exports contain no reactions.
     * These bounds are indicative, not proof of message-by-message completeness. */
    fun webQuoteCoverage(chatId:Long):List<Pair<Long,Long>> = readableDatabase.rawQuery(
        """SELECT MIN(e.exact_time),MAX(e.exact_time)
           FROM web_second_evidence e
           JOIN auto_sync_batches b ON b.file_hash=e.source_hash
           WHERE e.chat_id=? AND b.kind='web' AND b.status='completed'
           GROUP BY e.source_hash ORDER BY MIN(e.exact_time)""",
        arrayOf(chatId.toString())
    ).use { c -> buildList {
        while(c.moveToNext()) if(!c.isNull(0) && !c.isNull(1))add(c.getLong(0) to c.getLong(1))
    } }
    fun scanCoverage(chatId:Long):List<ScanCoverage> = readableDatabase.rawQuery(
        "SELECT batch_id,oldest,newest,message_count,stop_reason,newest_id,oldest_id FROM web_scan_coverage WHERE chat_id=? ORDER BY oldest ASC",
        arrayOf(chatId.toString())).use {c -> buildList {while(c.moveToNext())add(ScanCoverage(c.getLong(0),c.getLong(1),c.getLong(2),c.getInt(3),c.getString(4),c.getString(5),c.getString(6)))}}
    private fun createScanEvents(db:SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS reply_scan_events (id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER NOT NULL, completed INTEGER NOT NULL, scan_time INTEGER, imported_at INTEGER NOT NULL)")
    }
    fun saveScanEvent(chatId:Long,complete:Boolean,time:Long?) {
        writableDatabase.insert("reply_scan_events",null,ContentValues().apply {put("chat_id",chatId);put("completed",if(complete)1 else 0);if(time!=null)put("scan_time",time);put("imported_at",System.currentTimeMillis())})
    }
    fun latestCompleteScanTime(chatId:Long):Long? = readableDatabase.rawQuery("SELECT MAX(scan_time) FROM reply_scan_events WHERE chat_id=? AND completed=1",arrayOf(chatId.toString())).use {c-> if(c.moveToFirst()&&!c.isNull(0))c.getLong(0) else null}
    fun scanEvents(chatId:Long):List<Pair<Boolean,Long?>> = readableDatabase.rawQuery("SELECT completed,scan_time FROM reply_scan_events WHERE chat_id=? ORDER BY id DESC LIMIT 12",arrayOf(chatId.toString())).use {c-> buildList {while(c.moveToNext())add(Pair(c.getInt(0)==1,if(c.isNull(1))null else c.getLong(1)))}}
    private fun createBookmarkTables(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS bookmark_groups (id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER NOT NULL, label TEXT NOT NULL, saved_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS bookmark_items (group_id INTEGER NOT NULL, message_id INTEGER NOT NULL, PRIMARY KEY(group_id,message_id))")
        db.execSQL("CREATE INDEX IF NOT EXISTS bookmark_chat_saved ON bookmark_groups(chat_id,saved_at DESC,id DESC)")
    }
    private fun createVoiceLabelTable(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS voice_labels (chat_id INTEGER NOT NULL, fingerprint TEXT NOT NULL, occurrence INTEGER NOT NULL, label TEXT NOT NULL, PRIMARY KEY(chat_id,fingerprint,occurrence))")
    }
    private fun createReplyLinkTable(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS reply_links (chat_id INTEGER NOT NULL, reply_fingerprint TEXT NOT NULL, reply_occurrence INTEGER NOT NULL, original_fingerprint TEXT NOT NULL, original_occurrence INTEGER NOT NULL, PRIMARY KEY(chat_id,reply_fingerprint,reply_occurrence))")
    }
    private fun createWebCheckpoint(db:SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS web_scan_checkpoint (chat_id INTEGER PRIMARY KEY, message_id TEXT NOT NULL)")
    }
    private fun createHistoryResume(db:SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS web_history_resume (chat_id INTEGER PRIMARY KEY, start_id TEXT NOT NULL, oldest_id TEXT NOT NULL, oldest_time TEXT NOT NULL DEFAULT '')")
    }
    fun historyResume(chatId:Long):Pair<String,String>? = readableDatabase.rawQuery("SELECT start_id,oldest_id FROM web_history_resume WHERE chat_id=?",arrayOf(chatId.toString())).use { c -> if(c.moveToFirst()) Pair(c.getString(0),c.getString(1)) else null }
    fun saveHistoryResume(chatId:Long,start:String,oldest:String) {
        writableDatabase.insertWithOnConflict("web_history_resume",null,ContentValues().apply {put("chat_id",chatId);put("start_id",start);put("oldest_id",oldest)},SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun historyResumeTime(chatId:Long):String = readableDatabase.rawQuery("SELECT oldest_time FROM web_history_resume WHERE chat_id=?",arrayOf(chatId.toString())).use {c->if(c.moveToFirst())c.getString(0) else ""}
    fun saveHistoryResumeTime(chatId:Long,start:String,oldest:String,time:String) {
        writableDatabase.insertWithOnConflict("web_history_resume",null,ContentValues().apply {put("chat_id",chatId);put("start_id",start);put("oldest_id",oldest);put("oldest_time",time)},SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun clearScanState(chatId:Long) {clearHistoryResume(chatId);setWebCheckpoint(chatId,"");writableDatabase.delete("reply_scan_events","chat_id=?",arrayOf(chatId.toString()));writableDatabase.delete("web_scan_coverage","chat_id=?",arrayOf(chatId.toString()))}
    fun clearHistoryResume(chatId:Long) { writableDatabase.delete("web_history_resume","chat_id=?",arrayOf(chatId.toString())) }
    fun webCheckpoint(chatId:Long):String = readableDatabase.rawQuery("SELECT message_id FROM web_scan_checkpoint WHERE chat_id=?",arrayOf(chatId.toString())).use { c ->if(c.moveToFirst())c.getString(0) else "" }
    fun setWebCheckpoint(chatId:Long,value:String) {
        if(value.isBlank()) writableDatabase.delete("web_scan_checkpoint","chat_id=?",arrayOf(chatId.toString()))
        else writableDatabase.insertWithOnConflict("web_scan_checkpoint",null,ContentValues().apply {put("chat_id",chatId);put("message_id",value)},SQLiteDatabase.CONFLICT_REPLACE)
    }
    private fun addReplyConfidence(db:SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS reply_link_status (chat_id INTEGER NOT NULL, reply_fingerprint TEXT NOT NULL, reply_occurrence INTEGER NOT NULL, status TEXT NOT NULL, PRIMARY KEY(chat_id,reply_fingerprint,reply_occurrence))")
    }
    fun replyStatus(chatId:Long, reply:Message):String {
        readableDatabase.rawQuery("SELECT status FROM reply_link_status WHERE chat_id=? AND reply_fingerprint=? AND reply_occurrence=?",arrayOf(chatId.toString(),reply.fingerprint,reply.occurrence.toString())).use {c->if(c.moveToFirst())return c.getString(0)}
        return "confirmed"
    }
    fun updateReplyStatus(chatId:Long, reply:Message, status:String) {
        writableDatabase.insertWithOnConflict("reply_link_status",null,ContentValues().apply{put("chat_id",chatId);put("reply_fingerprint",reply.fingerprint);put("reply_occurrence",reply.occurrence);put("status",status)},SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun countReplyLinks(chatId:Long):Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM reply_links WHERE chat_id=?",arrayOf(chatId.toString())).use{c->c.moveToFirst();c.getInt(0)}
    fun removeReplyLinks(chatId:Long, mode:String) {
        val database=writableDatabase
        database.beginTransaction()
        try {
            when(mode){
                "all" -> {database.delete("reply_links","chat_id=?",arrayOf(chatId.toString())); database.delete("reply_link_status","chat_id=?",arrayOf(chatId.toString()))}
                "uncertain","imported" -> {
                    val statuses=if(mode=="uncertain") listOf("uncertain") else listOf("uncertain","auto")
                    for(status in statuses) {
                        database.execSQL("DELETE FROM reply_links WHERE chat_id=? AND EXISTS (SELECT 1 FROM reply_link_status s WHERE s.chat_id=reply_links.chat_id AND s.reply_fingerprint=reply_links.reply_fingerprint AND s.reply_occurrence=reply_links.reply_occurrence AND s.status=?)",arrayOf(chatId,status))
                        database.delete("reply_link_status","chat_id=? AND status=?",arrayOf(chatId.toString(),status))
                    }
                }
            }
            database.setTransactionSuccessful()
        } finally {database.endTransaction()}
    }
    fun setReplyLink(chatId: Long, reply: Message, original: Message) {
        require(!(reply.fingerprint==original.fingerprint && reply.occurrence==original.occurrence))
        writableDatabase.insertWithOnConflict("reply_links",null,ContentValues().apply {
            put("chat_id",chatId);put("reply_fingerprint",reply.fingerprint);put("reply_occurrence",reply.occurrence)
            put("original_fingerprint",original.fingerprint);put("original_occurrence",original.occurrence)
        },SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun removeReplyLink(chatId:Long, reply:Message) {
        writableDatabase.delete("reply_links","chat_id=? AND reply_fingerprint=? AND reply_occurrence=?",
            arrayOf(chatId.toString(),reply.fingerprint,reply.occurrence.toString()))
        writableDatabase.delete("reply_link_status","chat_id=? AND reply_fingerprint=? AND reply_occurrence=?",arrayOf(chatId.toString(),reply.fingerprint,reply.occurrence.toString()))
    }
    fun replyTarget(chatId:Long, reply:Message):Message? {
        readableDatabase.rawQuery("SELECT m.time,m.sender,m.body,m.attachment,m.fingerprint,m.occurrence FROM reply_links r JOIN messages m ON m.chat_id=r.chat_id AND m.fingerprint=r.original_fingerprint AND m.occurrence=r.original_occurrence WHERE r.chat_id=? AND r.reply_fingerprint=? AND r.reply_occurrence=? LIMIT 1",
            arrayOf(chatId.toString(),reply.fingerprint,reply.occurrence.toString())).use { c ->
            if(c.moveToFirst()) return Message(c.getLong(0),c.getString(1),c.getString(2),if(c.isNull(3)) null else c.getString(3),c.getString(4),c.getInt(5))
        }
        return null
    }
    // Sender aliases are stored separately; original sender strings are never rewritten.
    private fun createIdentityTables(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS sender_aliases (chat_id INTEGER NOT NULL, original TEXT NOT NULL, identity TEXT NOT NULL, PRIMARY KEY(chat_id,original))")
        db.execSQL("CREATE TABLE IF NOT EXISTS sender_names (chat_id INTEGER NOT NULL, identity TEXT NOT NULL, display TEXT NOT NULL, PRIMARY KEY(chat_id,identity))")
    }
    fun senderIdentity(chatId: Long, original: String): String {
        readableDatabase.rawQuery("SELECT identity FROM sender_aliases WHERE chat_id=? AND original=?",arrayOf(chatId.toString(),original)).use { c ->
            if(c.moveToFirst()) return c.getString(0)
        }
        return original
    }
    fun displaySender(chatId: Long, original: String): String {
        val identity=senderIdentity(chatId, original)
        readableDatabase.rawQuery("SELECT display FROM sender_names WHERE chat_id=? AND identity=?",arrayOf(chatId.toString(),identity)).use { c ->
            if(c.moveToFirst()) return c.getString(0)
        }
        return identity
    }
    fun renameIdentity(chatId: Long, original: String, display: String) {
        val identity=senderIdentity(chatId,original)
        require(display.isNotBlank())
        writableDatabase.insertWithOnConflict("sender_names",null,ContentValues().apply {put("chat_id",chatId);put("identity",identity);put("display",display.trim())},SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun resetNames(chatId: Long) { writableDatabase.delete("sender_names","chat_id=?",arrayOf(chatId.toString())) }
    fun connectSender(chatId: Long, alias: String, primary: String) {
        require(alias != primary && alias != "System" && primary != "System")
        val canonical=senderIdentity(chatId,primary)
        // Avoid cycles; resolve all current mappings pointing at alias as well.
        val sql=writableDatabase
        sql.beginTransaction()
        try {
            sql.execSQL("UPDATE sender_aliases SET identity=? WHERE chat_id=? AND identity=?",arrayOf(canonical,chatId,alias))
            sql.insertWithOnConflict("sender_aliases",null,ContentValues().apply {put("chat_id",chatId);put("original",alias);put("identity",canonical)},SQLiteDatabase.CONFLICT_REPLACE)
            sql.setTransactionSuccessful()
        } finally {sql.endTransaction()}
    }
    fun resetAliases(chatId: Long) { writableDatabase.delete("sender_aliases","chat_id=?",arrayOf(chatId.toString())) }
    fun identities(chatId: Long): List<Pair<String,String>> = participants(chatId).map { it to displaySender(chatId,it) }

    fun setVoiceLabel(chatId: Long, message: Message, label: String) {
        val sql=writableDatabase
        sql.beginTransaction()
        try {
            for((id,fp,occ) in relatedMessageRefs(sql,chatId,message.fingerprint,message.occurrence)) {
                if(label.isBlank())sql.delete("voice_labels","chat_id=? AND fingerprint=? AND occurrence=?",arrayOf(id.toString(),fp,occ.toString()))
                else sql.insertWithOnConflict("voice_labels",null,ContentValues().apply{
                    put("chat_id",id);put("fingerprint",fp);put("occurrence",occ);put("label",label)
                },SQLiteDatabase.CONFLICT_REPLACE)
            }
            sql.setTransactionSuccessful()
        }finally{sql.endTransaction()}
    }
    fun voiceLabel(chatId: Long, message: Message): String {
        readableDatabase.rawQuery("SELECT label FROM voice_labels WHERE chat_id=? AND fingerprint=? AND occurrence=?",arrayOf(chatId.toString(),message.fingerprint,message.occurrence.toString())).use { c -> if(c.moveToFirst()) return c.getString(0) }
        return ""
    }
    fun voicePage(chatId: Long, page: Int = 0, pageSize: Int = 48): List<Message> {
        val result=mutableListOf<Message>()
        val extensions=arrayOf("%.opus","%.ogg","%.m4a","%.mp3","%.aac","%.wav","%.amr")
        val where=extensions.joinToString(" OR ") { "LOWER(attachment) LIKE ?" }
        val args=arrayOf(chatId.toString(),*extensions,pageSize.toString(),(page.coerceAtLeast(0)*pageSize).toString())
        readableDatabase.rawQuery("SELECT time,sender,body,attachment,fingerprint,occurrence FROM messages WHERE chat_id=? AND attachment IS NOT NULL AND ($where) ORDER BY time DESC,id DESC LIMIT ? OFFSET ?",args).use { c ->
            while(c.moveToNext())result.add(Message(c.getLong(0),c.getString(1),c.getString(2),if(c.isNull(3))null else c.getString(3),c.getString(4),c.getInt(5)))
        }
        return result
    }
    fun saveBookmark(chatId: Long, label: String, selected: List<Message>) {
        require(label.isNotBlank() && selected.isNotEmpty())
        val sql = writableDatabase
        sql.beginTransaction()
        try {
            val g = ContentValues().apply {put("chat_id",chatId);put("label",label);put("saved_at",System.currentTimeMillis())}
            val groupId = sql.insertOrThrow("bookmark_groups",null,g)
            for (m in selected) {
                sql.rawQuery("SELECT id FROM messages WHERE chat_id=? AND fingerprint=? AND occurrence=? LIMIT 1",arrayOf(chatId.toString(),m.fingerprint,m.occurrence.toString())).use { c ->
                    if(c.moveToFirst()) {
                        val item = ContentValues().apply{put("group_id",groupId);put("message_id",c.getLong(0))}
                        sql.insertWithOnConflict("bookmark_items",null,item,SQLiteDatabase.CONFLICT_IGNORE)
                    }
                }
            }
            mirrorBookmarkGroup(sql,groupId)
            sql.setTransactionSuccessful()
        } finally {sql.endTransaction()}
    }
    fun bookmarks(chatId: Long): List<SavedBookmark> {
        val groups = mutableListOf<SavedBookmark>()
        readableDatabase.rawQuery("SELECT id,label,saved_at FROM bookmark_groups WHERE chat_id=? ORDER BY saved_at DESC,id DESC", arrayOf(chatId.toString())).use { gc ->
            while(gc.moveToNext()) {
                val id=gc.getLong(0)
                val msgs=mutableListOf<Message>()
                readableDatabase.rawQuery("SELECT m.time,m.sender,m.body,m.attachment,m.fingerprint,m.occurrence FROM bookmark_items b JOIN messages m ON m.id=b.message_id WHERE b.group_id=? ORDER BY m.time,m.id",arrayOf(id.toString())).use{mc ->
                    while(mc.moveToNext()) msgs.add(Message(mc.getLong(0),mc.getString(1),mc.getString(2),if(mc.isNull(3)) null else mc.getString(3),mc.getString(4),mc.getInt(5)))
                }
                groups.add(SavedBookmark(id,gc.getString(1),gc.getLong(2),msgs))
            }
        }
        return groups
    }
    fun deleteBookmark(groupId: Long) {
        val sql=writableDatabase
        sql.beginTransaction()
        try {
            val ids=linkedSetOf(groupId)
            sql.rawQuery("SELECT sibling_group_id FROM merged_bookmark_links WHERE group_id=?",arrayOf(groupId.toString())).use{c->while(c.moveToNext())ids.add(c.getLong(0))}
            // Include sibling groups reached through the same canonical source group.
            val first=ids.toList()
            for(id in first)sql.rawQuery("SELECT sibling_group_id FROM merged_bookmark_links WHERE group_id=?",arrayOf(id.toString())).use{c->while(c.moveToNext())ids.add(c.getLong(0))}
            for(id in ids){
                sql.delete("bookmark_items","group_id=?",arrayOf(id.toString()))
                sql.delete("bookmark_groups","id=?",arrayOf(id.toString()))
                sql.delete("merged_bookmark_links","group_id=? OR sibling_group_id=?",arrayOf(id.toString(),id.toString()))
            }
            sql.setTransactionSuccessful()
        }finally{sql.endTransaction()}
    }

    fun renameChat(chatId:Long,newName:String) {
        require(newName.isNotBlank())
        val rows=writableDatabase.update("chats",ContentValues().apply{put("name",newName.trim())},"id=?",arrayOf(chatId.toString()))
        if(rows!=1) throw IllegalStateException("Conversation missing")
    }
    fun chats(): List<Chat> {
        val result = mutableListOf<Chat>()
        readableDatabase.rawQuery("SELECT c.id,c.name,COUNT(m.id),COALESCE(MAX(m.time),0) FROM chats c LEFT JOIN messages m ON m.chat_id=c.id GROUP BY c.id ORDER BY MAX(m.time) DESC", null).use { c ->
            while (c.moveToNext()) result.add(Chat(c.getLong(0),c.getString(1),c.getInt(2),c.getLong(3)))
        }
        return result
    }
    // Delete one archive and its bookmark records. Return media names that are no longer
    // referenced by any remaining conversation; actual file deletion happens afterwards.
    fun deleteChat(chatId: Long): List<String> {
        val sql = writableDatabase
        val orphaned = mutableListOf<String>()
        sql.beginTransaction()
        try {
            val attached = mutableSetOf<String>()
            sql.rawQuery("SELECT DISTINCT attachment FROM messages WHERE chat_id=? AND attachment IS NOT NULL", arrayOf(chatId.toString())).use { c ->
                while (c.moveToNext()) attached.add(c.getString(0))
            }
            sql.execSQL("DELETE FROM bookmark_items WHERE group_id IN (SELECT id FROM bookmark_groups WHERE chat_id=?)", arrayOf(chatId))
            sql.delete("bookmark_groups", "chat_id=?", arrayOf(chatId.toString()))
            sql.delete("voice_labels", "chat_id=?", arrayOf(chatId.toString()))
            sql.delete("media_favourites", "chat_id=?", arrayOf(chatId.toString()))
            sql.delete("sender_aliases", "chat_id=?", arrayOf(chatId.toString()))
            sql.delete("sender_names", "chat_id=?", arrayOf(chatId.toString()))
            sql.delete("web_second_evidence", "chat_id=?", arrayOf(chatId.toString()))
            sql.execSQL("DELETE FROM auto_sync_added WHERE message_id IN (SELECT id FROM messages WHERE chat_id=?)",arrayOf(chatId))
            sql.delete("auto_sync_links","chat_id=?",arrayOf(chatId.toString()))
            sql.delete("auto_sync_batches","chat_id=?",arrayOf(chatId.toString()))
            sql.delete("manual_import_events","chat_id=?",arrayOf(chatId.toString()))
            sql.delete("auto_sync_sources","chat_id=?",arrayOf(chatId.toString()))
            sql.delete("auto_sync_created","chat_id=?",arrayOf(chatId.toString()))
            sql.delete("merged_chat_sources","merged_chat_id=? OR source_chat_id=?",arrayOf(chatId.toString(),chatId.toString()))
            sql.delete("messages", "chat_id=?", arrayOf(chatId.toString()))
            sql.delete("chats", "id=?", arrayOf(chatId.toString()))
            for (name in attached) {
                sql.rawQuery("SELECT 1 FROM messages WHERE attachment=? LIMIT 1", arrayOf(name)).use { c ->
                    if (!c.moveToFirst()) orphaned.add(name)
                }
            }
            sql.setTransactionSuccessful()
        } finally { sql.endTransaction() }
        return orphaned
    }

    fun participants(chatId: Long): List<String> {
        val names = mutableListOf<String>()
        readableDatabase.rawQuery(
            "SELECT sender FROM messages WHERE chat_id=? AND sender <> 'System' AND sender <> '' GROUP BY sender ORDER BY COUNT(*) DESC, sender ASC",
            arrayOf(chatId.toString())
        ).use { cursor -> while (cursor.moveToNext()) names.add(cursor.getString(0)) }
        return names
    }
    // The reply importer uses the newest message actually present in this chat,
    // not the newest timestamp in the WhatsApp Web scan.
    /** The real horizontal bounds of a conversation, not of its imported QAR sources.
     * Includes all archived message rows so a newly imported source cannot rescale
     * the coverage track independently of the conversation. */
    fun conversationTimeBounds(chatId:Long):Pair<Long,Long>? = readableDatabase.rawQuery(
        "SELECT MIN(time),MAX(time) FROM messages WHERE chat_id=?",arrayOf(chatId.toString())
    ).use { c ->
        if(c.moveToFirst() && !c.isNull(0) && !c.isNull(1)) c.getLong(0) to c.getLong(1)
        else null
    }

    /** Counts real archived messages covered by the UNION of timestamp intervals.
     * Callers must supply sorted, merged, disjoint ranges. Counting database rows
     * (not scan-reported counts) prevents double counting overlapping imports.
     * System notices are excluded from both the numerator and denominator. */
    fun archivedCoverageMessageCounts(chatId:Long,ranges:List<Pair<Long,Long>>):Pair<Long,Long> {
        val sql=readableDatabase
        val total=sql.rawQuery(
            "SELECT COUNT(*) FROM messages WHERE chat_id=? AND sender!='System'",
            arrayOf(chatId.toString())
        ).use { c -> if(c.moveToFirst())c.getLong(0) else 0L }
        var covered=0L
        for((start,end) in ranges) {
            if(end<start)continue
            covered+=sql.rawQuery(
                "SELECT COUNT(*) FROM messages WHERE chat_id=? AND sender!='System' AND time>=? AND time<=?",
                arrayOf(chatId.toString(),start.toString(),end.toString())
            ).use { c -> if(c.moveToFirst())c.getLong(0) else 0L }
        }
        return covered.coerceAtMost(total) to total
    }

    /** Message-weighted coverage layout, oldest at the left and newest at the right.
     * Each distinct archived message contributes one equal-width unit. Coverage
     * intervals must be sorted, disjoint and merged before calling this method.
     * Uncovered gaps retain their position in message order, rather than being
     * collapsed into a single grey remainder. */
    fun archivedCoverageMessageSegments(chatId:Long,ranges:List<Pair<Long,Long>>):List<Pair<Boolean,Long>> {
        val segments=mutableListOf<Pair<Boolean,Long>>()
        var interval=0
        readableDatabase.rawQuery(
            "SELECT time FROM messages WHERE chat_id=? AND sender!='System' ORDER BY time,id",
            arrayOf(chatId.toString())
        ).use { c -> while(c.moveToNext()) {
            val time=c.getLong(0)
            while(interval<ranges.size && ranges[interval].second<time)interval++
            val covered=interval<ranges.size && time>=ranges[interval].first
            val last=segments.lastOrNull()
            if(last!=null && last.first==covered)
                segments[segments.lastIndex]=covered to (last.second+1L)
            else segments.add(covered to 1L)
        }}
        return segments
    }

    fun latestArchivedMessageTime(chatId:Long):Long? = readableDatabase.rawQuery(
        "SELECT MAX(time) FROM messages WHERE chat_id=?", arrayOf(chatId.toString())
    ).use { c -> if(c.moveToFirst() && !c.isNull(0)) c.getLong(0) else null }

    /** The sender who speaks after a gap owns that gap. We inspect the complete
     * chronological stream first, then filter the ending message by date/time;
     * filtering first would invent gaps at the excluded boundaries. */
    data class MessageGap(val sender:String,val durationMs:Long,val earlier:Long,val later:Long)
    fun longestMessageGaps(chatId:Long,startDay:Long,endDay:Long,startMinute:Int,endMinute:Int):Map<String,List<MessageGap>> {
        val top=linkedMapOf<String,MutableList<MessageGap>>()
        val cal=java.util.Calendar.getInstance()
        var previous:Long?=null
        readableDatabase.rawQuery(
            "SELECT time,sender FROM messages WHERE chat_id=? AND sender!='System' ORDER BY time,id",arrayOf(chatId.toString())
        ).use { c -> while(c.moveToNext()) {
            val time=c.getLong(0);val sender=c.getString(1).orEmpty()
            val prior=previous
            previous=time
            if(prior==null || time<=prior || sender.isBlank())continue
            cal.timeInMillis=time
            val minute=cal.get(java.util.Calendar.HOUR_OF_DAY)*60+cal.get(java.util.Calendar.MINUTE)
            val inside=if(startMinute<=endMinute) minute in startMinute..endMinute
                       else minute>=startMinute || minute<=endMinute
            if(time<startDay || time>endDay || !inside)continue
            val list=top.getOrPut(sender){mutableListOf()}
            val gap=MessageGap(sender,time-prior,prior,time)
            list.add(gap)
            list.sortWith(compareByDescending<MessageGap>{it.durationMs}.thenBy{it.later})
            if(list.size>5)list.removeAt(5)
        }}
        return top.mapValues{it.value.toList()}
    }

    fun messages(chatId: Long, query: String = ""): List<Message> {
        val out = mutableListOf<Message>()
        val filter = if (query.isEmpty()) "" else " AND (body LIKE ? ESCAPE '\\' OR sender LIKE ? ESCAPE '\\')"
        val q = "%" + query.replace("\\","\\\\").replace("%","\\%").replace("_","\\_") + "%"
        val args = if (query.isEmpty()) arrayOf(chatId.toString()) else arrayOf(chatId.toString(),q,q)
        readableDatabase.rawQuery("SELECT time,sender,body,attachment,fingerprint,occurrence FROM messages WHERE chat_id=?$filter ORDER BY time,id", args).use { c ->
            while(c.moveToNext()) out.add(Message(c.getLong(0),c.getString(1),c.getString(2), if(c.isNull(3)) null else c.getString(3),c.getString(4),c.getInt(5)))
        }
        return out
    }
    // Media gallery is queried directly from SQLite, so large archives are never loaded into memory.
    fun mediaPage(chatId: Long, page: Int = 0, pageSize: Int = 48, favouritesOnly:Boolean=false): List<Message> {
        val result = mutableListOf<Message>()
        val extensions = arrayOf("%.jpg", "%.jpeg", "%.png", "%.webp", "%.gif", "%.heic", "%.mp4", "%.3gp", "%.webm", "%.mov")
        val where = extensions.joinToString(" OR ") { "LOWER(attachment) LIKE ?" }
        val args = arrayOf(chatId.toString(), *extensions, pageSize.toString(), (page * pageSize).toString())
        val favouritesFilter=if(favouritesOnly) " AND EXISTS (SELECT 1 FROM media_favourites f WHERE f.chat_id=messages.chat_id AND f.fingerprint=messages.fingerprint AND f.occurrence=messages.occurrence)" else ""
        readableDatabase.rawQuery("SELECT time,sender,body,attachment,fingerprint,occurrence FROM messages WHERE chat_id=? AND attachment IS NOT NULL AND ($where)$favouritesFilter ORDER BY time DESC,id DESC LIMIT ? OFFSET ?",args).use { c ->
            while(c.moveToNext()) result.add(Message(c.getLong(0),c.getString(1),c.getString(2),if(c.isNull(3))null else c.getString(3),c.getString(4),c.getInt(5)))
        }
        return result
    }
    // Count search hits in exactly the same way as messagesPage, including sender matches.
    fun searchMatchCount(chatId:Long,query:String):Int {
        if(query.isBlank()) return 0
        val escaped="%"+query.replace("\\","\\\\").replace("%","\\%").replace("_","\\_")+"%"
        return readableDatabase.rawQuery(
            "SELECT COUNT(*) FROM messages WHERE chat_id=? AND (body LIKE ? ESCAPE '\\' OR sender LIKE ? ESCAPE '\\')",
            arrayOf(chatId.toString(),escaped,escaped)
        ).use { c-> if(c.moveToFirst()) c.getInt(0) else 0 }
    }
    // Find the first message on or after the requested local calendar day without scanning the archive in memory.
    fun messageOnOrAfter(chatId:Long,query:String,dayStart:Long):Message? {
        val sql="SELECT time,sender,body,attachment,fingerprint,occurrence FROM messages WHERE chat_id=? AND time>=? ORDER BY time ASC,id ASC LIMIT 1"
        return readableDatabase.rawQuery(sql,arrayOf(chatId.toString(),dayStart.toString())).use { c ->
            if(c.moveToFirst()) Message(c.getLong(0),c.getString(1),c.getString(2),if(c.isNull(3))null else c.getString(3),c.getString(4),c.getInt(5)) else null
        }
    }

    // Direct month navigation: indexed timestamp range query, earliest message in the selected calendar month.
    fun firstMessageInMonth(chatId:Long,start:Long,endExclusive:Long):Message? = readableDatabase.rawQuery(
        "SELECT time,sender,body,attachment,fingerprint,occurrence FROM messages WHERE chat_id=? AND time>=? AND time<? ORDER BY time ASC,id ASC LIMIT 1",
        arrayOf(chatId.toString(),start.toString(),endExclusive.toString())
    ).use { c ->
        if(c.moveToFirst()) Message(c.getLong(0),c.getString(1),c.getString(2),if(c.isNull(3))null else c.getString(3),c.getString(4),c.getInt(5)) else null
    }

    // A bounded, moveable 300-message window for continuous chat scrolling.
    fun messagesWindow(chatId:Long,query:String,offset:Int,limit:Int):List<Message> {
        if(offset%300==0 && limit==300) return messagesPage(chatId,query,offset/300,300)
        val escaped="%"+query.replace("\\","\\\\").replace("%","\\%").replace("_","\\_")+"%"
        val filter=if(query.isBlank()) "" else " AND (body LIKE ? ESCAPE '\\' OR sender LIKE ? ESCAPE '\\')"
        val args=mutableListOf(chatId.toString())
        if(query.isNotBlank()) {args.add(escaped);args.add(escaped)}
        args.add(limit.coerceAtMost(1200).toString());args.add(offset.coerceAtLeast(0).toString())
        return readableDatabase.rawQuery("SELECT time,sender,body,attachment,fingerprint,occurrence FROM messages WHERE chat_id=?$filter ORDER BY time DESC,id DESC LIMIT ? OFFSET ?",args.toTypedArray()).use { c ->
            val out=ArrayList<Message>()
            while(c.moveToNext()) out.add(Message(c.getLong(0),c.getString(1),c.getString(2),if(c.isNull(3))null else c.getString(3),c.getString(4),c.getInt(5)))
            out
        }
    }

    // Show one page of recent messages at a time rather than constructing tens of thousands of views.
    fun messagesPage(chatId: Long, query: String = "", page: Int = 0, pageSize: Int = 300): List<Message> {
        val escaped = "%" + query.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        val filter = if (query.isEmpty()) "" else " AND (body LIKE ? ESCAPE '\\' OR sender LIKE ? ESCAPE '\\')"
        val params = mutableListOf(chatId.toString())
        if (query.isNotEmpty()) { params.add(escaped); params.add(escaped) }
        params.add(pageSize.toString())
        params.add((page.coerceAtLeast(0) * pageSize).toString())
        val results = mutableListOf<Message>()
        readableDatabase.rawQuery(
            "SELECT time,sender,body,attachment,fingerprint,occurrence FROM messages WHERE chat_id=?$filter ORDER BY time DESC,id DESC LIMIT ? OFFSET ?",
            params.toTypedArray()
        ).use { c ->
            while (c.moveToNext()) results.add(Message(c.getLong(0),c.getString(1),c.getString(2),if(c.isNull(3)) null else c.getString(3),c.getString(4),c.getInt(5)))
        }
        return results
    }

    // Search a wider interval: WhatsApp Web and chat exports sometimes disagree
    // about the exact displayed minute. Ranking happens in MainActivity.
    fun replyCandidates(chatId:Long, time:Long, sender:String):List<Message> {
        val all=mutableListOf<Message>()
        readableDatabase.rawQuery("SELECT time,sender,body,attachment,fingerprint,occurrence FROM messages WHERE chat_id=? AND time BETWEEN ? AND ? ORDER BY ABS(time - ?) LIMIT 500",arrayOf(chatId.toString(),(time-300000).toString(),(time+300000).toString(),time.toString())).use {c->
            while(c.moveToNext()) {
                val item=Message(c.getLong(0),c.getString(1),c.getString(2),if(c.isNull(3))null else c.getString(3),c.getString(4),c.getInt(5))
                if(item.sender.equals(sender,true)||displaySender(chatId,item.sender).equals(sender,true))all.add(item)
            }
        }
        return all
    }
    private fun normalisedQuoteSearch(value:String):String = value
        .replace("\u200e", "").replace("\u200f", "")
        .replace(Regex("""[\p{Punct}\p{Z}\s]+""")," ").trim().lowercase(Locale.ROOT)

    // Use backwards-in-time windows, with strict quote-text validation. Do not
    // allow a common opening word to turn hundreds of messages into candidates.
    fun originalCandidates(chatId:Long, prefix:String, sender:String, before:Long?):List<Message> {
        if(before==null)return emptyList()
        val query=normalisedQuoteSearch(prefix).removeSuffix("...").trim()
        if(query.length<3)return emptyList()
        val terms=query.split(' ').filter{it.isNotBlank()}
        val seed=terms.firstOrNull{it.length>=5} ?: terms.firstOrNull{it.length>=3} ?: return emptyList()
        val escaped=seed.replace("\\","\\\\").replace("%","\\%").replace("_","\\_")
        val windows=listOf(1L,2L,7L,36500L)
        for(days in windows) {
            val minTime=before-days*86400000L
            val options=mutableListOf<Pair<Message,Double>>()
            readableDatabase.rawQuery("SELECT time,sender,body,attachment,fingerprint,occurrence FROM messages WHERE chat_id=? AND time<=? AND time>=? AND body LIKE ? ESCAPE '\\' ORDER BY time DESC LIMIT 12000",
                arrayOf(chatId.toString(),before.toString(),minTime.toString(),"%$escaped%")).use {c ->
                while(c.moveToNext()) {
                    val item=Message(c.getLong(0),c.getString(1),c.getString(2),if(c.isNull(3))null else c.getString(3),c.getString(4),c.getInt(5))
                    if(sender.isNotBlank() && !item.sender.equals(sender,true) && !displaySender(chatId,item.sender).equals(sender,true))continue
                    val actual=normalisedQuoteSearch(item.body)
                    val similarity=when {
                        actual==query -> 1.0
                        actual.contains(query) -> 0.99
                        query.length>=18 && query.contains(actual) && actual.length>=query.length*0.8 -> 0.91
                        else -> {
                            val qWords=query.split(' ');val aWords=actual.split(' ')
                            val common=qWords.zip(aWords).takeWhile{it.first==it.second}.size
                            val prefixRatio=common.toDouble()/qWords.size.coerceAtLeast(1)
                            // Truncated quotes often end in an ellipsis; they still
                            // need a substantial exact opening sequence.
                            if(query.length>=35 && common>=6 && prefixRatio>=0.75) 0.88 else 0.0
                        }
                    }
                    val threshold=if(query.length<18)0.99 else 0.87
                    if(similarity>=threshold)options.add(item to similarity)
                }
            }
            if(options.isNotEmpty())return options.sortedWith(compareByDescending<Pair<Message,Double>>{it.second}.thenBy {before-it.first.time}).take(6).map{it.first}
        }
        return emptyList()
    }
    // Find the page containing a bookmarked message using the same ordering as messagesPage.
    // This avoids loading the complete archive into memory.
    fun pageForMessage(chatId: Long, message: Message, pageSize: Int = 300): Int? {
        val sql = readableDatabase
        sql.rawQuery(
            "SELECT id,time FROM messages WHERE chat_id=? AND fingerprint=? AND occurrence=? LIMIT 1",
            arrayOf(chatId.toString(),message.fingerprint,message.occurrence.toString())
        ).use { target ->
            if (!target.moveToFirst()) return null
            val messageId = target.getLong(0)
            val time = target.getLong(1)
            sql.rawQuery(
                "SELECT COUNT(*) FROM messages WHERE chat_id=? AND (time > ? OR (time = ? AND id > ?))",
                arrayOf(chatId.toString(),time.toString(),time.toString(),messageId.toString())
            ).use { newer ->
                if (newer.moveToFirst()) return (newer.getLong(0) / pageSize).toInt()
            }
        }
        return null
    }

    fun insert(name: String, items: List<Message>, autoBatchId:Long?=null): Pair<Int,Int> {
        val db = writableDatabase
        var inserted = 0
        db.beginTransaction()
        try {
            val chatValues = ContentValues().apply { put("name",name) }
            db.insertWithOnConflict("chats",null,chatValues,SQLiteDatabase.CONFLICT_IGNORE)
            val chatId = db.rawQuery("SELECT id FROM chats WHERE name=?",arrayOf(name)).use { c -> c.moveToFirst(); c.getLong(0) }
            // Count occurrences of identical messages already present under any mapped sender alias.
            // Exported WhatsApp records have no stable message ID, so exact repeats can remain ambiguous.
            val seenInBatch=mutableMapOf<String,Int>()
            val existingCounts=mutableMapOf<String,Int>()
            for (m in items) {
                val identity=senderIdentity(chatId,m.sender)
                val key="${m.time}\u0000${identity}\u0000${m.body}"
                val ordinal=(seenInBatch[key] ?: 0)+1
                seenInBatch[key]=ordinal
                val old=existingCounts.getOrPut(key) {
                    var count=0
                    db.rawQuery("SELECT sender FROM messages WHERE chat_id=? AND time=? AND body=?",arrayOf(chatId.toString(),m.time.toString(),m.body)).use { c ->
                        while(c.moveToNext()) if(senderIdentity(chatId,c.getString(0))==identity) count++
                    }
                    count
                }
                if(ordinal<=old) continue
                val v = ContentValues().apply { put("chat_id",chatId);put("time",m.time);put("sender",m.sender);put("body",m.body);put("attachment",m.attachment);put("fingerprint",m.fingerprint);put("occurrence",m.occurrence) }
                val rowId=db.insertWithOnConflict("messages",null,v,SQLiteDatabase.CONFLICT_IGNORE)
                if(rowId!=-1L){inserted++;if(autoBatchId!=null)db.insert("auto_sync_added",null,ContentValues().apply{put("batch_id",autoBatchId);put("message_id",rowId)})}
            }
            if(autoBatchId==null)db.insert("manual_import_events",null,ContentValues().apply{put("chat_id",chatId);put("imported_at",System.currentTimeMillis())})
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return inserted to (items.size - inserted)
    }
    /** Portable state not covered by the legacy per-chat JSON snapshot. */
    fun portableExtras():JSONObject {
        val sql=readableDatabase
        val tables=listOf("chats","messages","web_reactions","auto_sync_sources","auto_sync_batches",
            "auto_sync_added","auto_sync_links","auto_sync_created","manual_import_events","reply_scan_events",
            "crypt_chat_links","crypt_message_ids","crypt_sync_events")
        val result=JSONObject()
        for(table in tables) {
            val records=JSONArray()
            sql.rawQuery(if(table=="messages") "SELECT id,chat_id,fingerprint,occurrence FROM messages" else "SELECT * FROM $table",null).use {cursor ->
                while(cursor.moveToNext()) {
                    val item=JSONObject()
                    for(i in 0 until cursor.columnCount) {
                        val key=cursor.getColumnName(i)
                        when(cursor.getType(i)) {
                            android.database.Cursor.FIELD_TYPE_NULL -> item.put(key,JSONObject.NULL)
                            android.database.Cursor.FIELD_TYPE_INTEGER -> item.put(key,cursor.getLong(i))
                            android.database.Cursor.FIELD_TYPE_FLOAT -> item.put(key,cursor.getDouble(i))
                            else -> item.put(key,cursor.getString(i))
                        }
                    }
                    records.put(item)
                }
            }
            result.put(table,records)
        }
        return result
    }
    fun portableChatIdMap(extras:JSONObject):Map<Long,Long> {
        val current=chats().associateBy { it.name }
        val mapping=mutableMapOf<Long,Long>()
        val old=extras.optJSONArray("chats") ?: return emptyMap()
        for(i in 0 until old.length()) {
            val entry=old.getJSONObject(i)
            val found=current[entry.getString("name")]?:continue
            mapping[entry.getLong("id")]=found.id
        }
        return mapping
    }
    fun restorePortableExtras(extras:JSONObject) {
        val sql=writableDatabase
        val chatMapping=portableChatIdMap(extras)
        val oldMessageToNew=mutableMapOf<Long,Long>()
        val oldMessages=extras.optJSONArray("messages") ?: JSONArray()
        for(i in 0 until oldMessages.length()) {
            val old=oldMessages.getJSONObject(i)
            val id=chatMapping[old.optLong("chat_id")]?:continue
            sql.rawQuery("SELECT id FROM messages WHERE chat_id=? AND fingerprint=? AND occurrence=? LIMIT 1",
                arrayOf(id.toString(),old.getString("fingerprint"),old.getInt("occurrence").toString())).use { cursor ->
                if(cursor.moveToFirst())oldMessageToNew[old.getLong("id")]=cursor.getLong(0)
            }
        }
        val oldToNewBatch=mutableMapOf<Long,Long>()
        val tables=listOf("web_reactions","auto_sync_sources","auto_sync_batches","auto_sync_added",
            "auto_sync_links","auto_sync_created","manual_import_events","reply_scan_events",
            "crypt_chat_links","crypt_message_ids","crypt_sync_events")
        sql.beginTransaction()
        try {
            for(table in tables)sql.delete(table,null,null)
            for(table in tables) {
                val rows=extras.optJSONArray(table) ?: continue
                for(i in 0 until rows.length()) {
                    val item=rows.getJSONObject(i)
                    val values=ContentValues()
                    var skip=false
                    val keys=item.keys()
                    while(keys.hasNext()) {
                        val key=keys.next()
                        if((table=="auto_sync_batches" || table=="reply_scan_events" || table=="crypt_sync_events") && key=="id")continue
                        if(key=="chat_id") {
                            val mapped=chatMapping[item.getLong(key)]
                            if(mapped==null){skip=true;break}
                            values.put(key,mapped)
                        } else if(key=="message_id" && table=="auto_sync_added") {
                            val mapped=oldMessageToNew[item.getLong(key)]
                            if(mapped==null){skip=true;break}
                            values.put(key,mapped)
                        } else if(key=="batch_id") {
                            // Batch rows are processed before dependent entries.
                            val mapped=oldToNewBatch[item.getLong(key)]
                            if(mapped==null){skip=true;break}
                            values.put(key,mapped)
                        } else if(item.isNull(key))values.putNull(key)
                        else when(val value=item.get(key)) {
                            is Int -> values.put(key,value)
                            is Long -> values.put(key,value)
                            is Double -> values.put(key,value)
                            is Boolean -> values.put(key,if(value)1 else 0)
                            else -> values.put(key,value.toString())
                        }
                    }
                    if(skip)continue
                    val newId=sql.insertWithOnConflict(table,null,values,SQLiteDatabase.CONFLICT_REPLACE)
                    if(newId>=0 && table=="auto_sync_batches")oldToNewBatch[item.getLong("id")]=newId
                }
            }
            sql.setTransactionSuccessful()
        } finally {sql.endTransaction()}
    }

    fun snapshot(): JSONObject {
        val root = JSONObject().put("format",2)
        val chats = JSONArray()
        for (chat in chats()) {
            val msgs = JSONArray()
            for (m in messages(chat.id)) msgs.put(JSONObject().put("time",m.time).put("sender",m.sender).put("body",m.body).put("attachment",m.attachment ?: JSONObject.NULL).put("fingerprint",m.fingerprint).put("occurrence",m.occurrence))
            val marks=JSONArray()
            for (mark in bookmarks(chat.id)) {
                val items=JSONArray()
                for (m in mark.messages) items.put(JSONObject().put("fingerprint",m.fingerprint).put("occurrence",m.occurrence))
                marks.put(JSONObject().put("label",mark.label).put("saved_at",mark.savedAt).put("items",items))
            }
            val voiceLabels=JSONArray()
            for(m in voicePage(chat.id,0,Int.MAX_VALUE)) {
                val label=voiceLabel(chat.id,m)
                if(label.isNotBlank()) voiceLabels.put(JSONObject().put("fingerprint",m.fingerprint).put("occurrence",m.occurrence).put("label",label))
            }
            val aliases=JSONArray()
            readableDatabase.rawQuery("SELECT original,identity FROM sender_aliases WHERE chat_id=?",arrayOf(chat.id.toString())).use { c ->
                while(c.moveToNext()) aliases.put(JSONObject().put("original",c.getString(0)).put("identity",c.getString(1)))
            }
            val names=JSONArray()
            readableDatabase.rawQuery("SELECT identity,display FROM sender_names WHERE chat_id=?",arrayOf(chat.id.toString())).use { c ->
                while(c.moveToNext()) names.put(JSONObject().put("identity",c.getString(0)).put("display",c.getString(1)))
            }
            val replyLinks=JSONArray()
            readableDatabase.rawQuery("SELECT reply_fingerprint,reply_occurrence,original_fingerprint,original_occurrence FROM reply_links WHERE chat_id=?",arrayOf(chat.id.toString())).use {c ->
                while(c.moveToNext()) replyLinks.put(JSONObject().put("reply_fingerprint",c.getString(0)).put("reply_occurrence",c.getInt(1)).put("original_fingerprint",c.getString(2)).put("original_occurrence",c.getInt(3)))
            }
            val replyStatuses=JSONArray()
            readableDatabase.rawQuery("SELECT reply_fingerprint,reply_occurrence,status FROM reply_link_status WHERE chat_id=?",arrayOf(chat.id.toString())).use{c->while(c.moveToNext())replyStatuses.put(JSONObject().put("reply_fingerprint",c.getString(0)).put("reply_occurrence",c.getInt(1)).put("status",c.getString(2)))}
            val favourites=JSONArray()
            readableDatabase.rawQuery("SELECT fingerprint,occurrence FROM media_favourites WHERE chat_id=?",arrayOf(chat.id.toString())).use {c->
                while(c.moveToNext()) favourites.put(JSONObject().put("fingerprint",c.getString(0)).put("occurrence",c.getInt(1)))
            }
            val mergedSources=JSONArray()
            readableDatabase.rawQuery("SELECT c.name,s.source_key FROM merged_chat_sources s JOIN chats c ON c.id=s.source_chat_id WHERE s.merged_chat_id=?",arrayOf(chat.id.toString())).use{c->
                while(c.moveToNext())mergedSources.put(JSONObject().put("source_name",c.getString(0)).put("source_key",c.getString(1)))
            }
            val webRanges=JSONArray()
            for(range in scanCoverage(chat.id)) webRanges.put(JSONObject().put("batch_id",range.batchId).put("oldest",range.oldest).put("newest",range.newest).put("message_count",range.count).put("stop_reason",range.reason).put("newest_id",range.newestId).put("oldest_id",range.oldestId))
            chats.put(JSONObject().put("web_scan_coverage",webRanges).put("merged_sources",mergedSources).put("media_favourites",favourites).put("web_history_start",historyResume(chat.id)?.first ?: "").put("web_history_oldest",historyResume(chat.id)?.second ?: "").put("web_history_oldest_time",historyResumeTime(chat.id)).put("web_checkpoint",webCheckpoint(chat.id)).put("reply_link_status",replyStatuses).put("reply_links",replyLinks).put("name",chat.name).put("messages",msgs).put("bookmarks",marks).put("voice_labels",voiceLabels).put("sender_aliases",aliases).put("sender_names",names))
        }
        root.put("chats",chats)
        return root
    }
    fun restore(snapshot: JSONObject) {
        require(snapshot.getInt("format") in 1..2) { "Unsupported archive format" }
        val entries = snapshot.getJSONArray("chats")
        // Validate entire JSON before mutating the database.
        val parsed = mutableListOf<Pair<String,List<Message>>>()
        val bookmarkSets=mutableListOf<JSONArray>()
        val voiceLabelSets=mutableListOf<JSONArray>()
        val aliasSets=mutableListOf<JSONArray>()
        val nameSets=mutableListOf<JSONArray>()
        val replyLinkSets=mutableListOf<JSONArray>()
        val replyStatusSets=mutableListOf<JSONArray>()
        val favouriteSets=mutableListOf<JSONArray>()
        for (i in 0 until entries.length()) {
            val entry = entries.getJSONObject(i)
            val name = entry.getString("name")
            val arr = entry.getJSONArray("messages")
            val msgs = mutableListOf<Message>()
            for (j in 0 until arr.length()) {
                val obj = arr.getJSONObject(j)
                msgs.add(Message(obj.getLong("time"),obj.getString("sender"),obj.getString("body"),if(obj.isNull("attachment")) null else obj.getString("attachment"),obj.getString("fingerprint"),obj.getInt("occurrence")))
            }
            parsed.add(name to msgs)
            bookmarkSets.add(entry.optJSONArray("bookmarks") ?: JSONArray())
            voiceLabelSets.add(entry.optJSONArray("voice_labels") ?: JSONArray())
            aliasSets.add(entry.optJSONArray("sender_aliases") ?: JSONArray())
            nameSets.add(entry.optJSONArray("sender_names") ?: JSONArray())
            replyLinkSets.add(entry.optJSONArray("reply_links") ?: JSONArray())
            replyStatusSets.add(entry.optJSONArray("reply_link_status") ?: JSONArray())
            favouriteSets.add(entry.optJSONArray("media_favourites") ?: JSONArray())
        }
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("web_scan_checkpoint",null,null)
            db.delete("web_scan_coverage",null,null)
            db.delete("web_history_resume",null,null)
            db.delete("reply_link_status",null,null)
            db.delete("reply_links",null,null)
            db.delete("sender_aliases",null,null); db.delete("sender_names",null,null)
            db.delete("voice_labels",null,null)
            db.delete("media_favourites",null,null)
            db.delete("bookmark_items",null,null);db.delete("bookmark_groups",null,null)
            db.delete("merged_chat_sources",null,null)
            db.delete("messages",null,null); db.delete("chats",null,null)
            for ((position, pair) in parsed.withIndex()) {
                val (name,msgs)=pair
                val cv = ContentValues().apply{put("name",name)}
                val id = db.insertOrThrow("chats",null,cv)
                val checkpoint=entries.getJSONObject(position).optString("web_checkpoint","")
                if(checkpoint.isNotBlank())db.insertOrThrow("web_scan_checkpoint",null,ContentValues().apply{put("chat_id",id);put("message_id",checkpoint)})
                val historyStart=entries.getJSONObject(position).optString("web_history_start","")
                val historyOldest=entries.getJSONObject(position).optString("web_history_oldest","")
                val historyTime=entries.getJSONObject(position).optString("web_history_oldest_time","")
                if(historyStart.isNotBlank() && historyOldest.isNotBlank()) db.insertOrThrow("web_history_resume",null,ContentValues().apply{put("chat_id",id);put("start_id",historyStart);put("oldest_id",historyOldest);put("oldest_time",historyTime)})
                val ranges=entries.getJSONObject(position).optJSONArray("web_scan_coverage")
                if(ranges!=null)for(k in 0 until ranges.length()) {
                    val r=ranges.optJSONObject(k)?:continue
                    if(r.optLong("newest")<r.optLong("oldest"))continue
                    db.insertWithOnConflict("web_scan_coverage",null,ContentValues().apply {
                        put("chat_id",id);put("batch_id",r.optLong("batch_id",k.toLong()))
                        put("oldest",r.optLong("oldest"));put("newest",r.optLong("newest"))
                        put("message_count",r.optInt("message_count"));put("stop_reason",r.optString("stop_reason"))
                        put("newest_id",r.optString("newest_id"));put("oldest_id",r.optString("oldest_id"))
                    },SQLiteDatabase.CONFLICT_REPLACE)
                }
                for (m in msgs) {
                    val v = ContentValues().apply {put("chat_id",id);put("time",m.time);put("sender",m.sender);put("body",m.body);put("attachment",m.attachment);put("fingerprint",m.fingerprint);put("occurrence",m.occurrence)}
                    db.insertOrThrow("messages",null,v)
                }
                for(k in 0 until aliasSets[position].length()) {
                    val item=aliasSets[position].getJSONObject(k)
                    db.insertOrThrow("sender_aliases",null,ContentValues().apply{put("chat_id",id);put("original",item.getString("original"));put("identity",item.getString("identity"))})
                }
                for(k in 0 until nameSets[position].length()) {
                    val item=nameSets[position].getJSONObject(k)
                    db.insertOrThrow("sender_names",null,ContentValues().apply{put("chat_id",id);put("identity",item.getString("identity"));put("display",item.getString("display"))})
                }
                val labels=voiceLabelSets[position]
                for(k in 0 until labels.length()) {
                    val item=labels.getJSONObject(k)
                    db.insertWithOnConflict("voice_labels",null,ContentValues().apply {put("chat_id",id);put("fingerprint",item.getString("fingerprint"));put("occurrence",item.getInt("occurrence"));put("label",item.getString("label"))},SQLiteDatabase.CONFLICT_REPLACE)
                }
                val statuses=replyStatusSets[position]
                for(k in 0 until statuses.length()) {
                    val obj=statuses.getJSONObject(k)
                    db.insertWithOnConflict("reply_link_status",null,ContentValues().apply {put("chat_id",id);put("reply_fingerprint",obj.getString("reply_fingerprint"));put("reply_occurrence",obj.getInt("reply_occurrence"));put("status",obj.getString("status"))},SQLiteDatabase.CONFLICT_REPLACE)
                }
                val links=replyLinkSets[position]
                for (k in 0 until links.length()) {
                    val obj=links.getJSONObject(k)
                    db.insertWithOnConflict("reply_links",null,ContentValues().apply {
                        put("chat_id",id);put("reply_fingerprint",obj.getString("reply_fingerprint"));put("reply_occurrence",obj.getInt("reply_occurrence"))
                        put("original_fingerprint",obj.getString("original_fingerprint"));put("original_occurrence",obj.getInt("original_occurrence"))
                    },SQLiteDatabase.CONFLICT_REPLACE)
                }
                val favouriteEntries=favouriteSets[position]
                for(k in 0 until favouriteEntries.length()){
                    val item=favouriteEntries.getJSONObject(k)
                    db.insertWithOnConflict("media_favourites",null,ContentValues().apply{
                        put("chat_id",id);put("fingerprint",item.getString("fingerprint"));put("occurrence",item.getInt("occurrence"))
                    },SQLiteDatabase.CONFLICT_IGNORE)
                }
                val marks=bookmarkSets[position]
                for (k in 0 until marks.length()) {
                    val mark=marks.getJSONObject(k)
                    val g=ContentValues().apply{put("chat_id",id);put("label",mark.getString("label"));put("saved_at",mark.getLong("saved_at"))}
                    val groupId=db.insertOrThrow("bookmark_groups",null,g)
                    val items=mark.getJSONArray("items")
                    for (j in 0 until items.length()) {
                        val item=items.getJSONObject(j)
                        db.rawQuery("SELECT id FROM messages WHERE chat_id=? AND fingerprint=? AND occurrence=?",arrayOf(id.toString(),item.getString("fingerprint"),item.getInt("occurrence").toString())).use { c ->
                            if(c.moveToFirst()) db.insertOrThrow("bookmark_items",null,ContentValues().apply{put("group_id",groupId);put("message_id",c.getLong(0))})
                        }
                    }
                }
            }
            // Reconnect live merges by name after all restored chats exist.
            for (i in 0 until entries.length()) {
                val entry=entries.getJSONObject(i)
                val sources=entry.optJSONArray("merged_sources") ?: continue
                val mergedId=db.rawQuery("SELECT id FROM chats WHERE name=?",arrayOf(entry.getString("name"))).use{c->if(c.moveToFirst())c.getLong(0) else -1L}
                if(mergedId<0)continue
                for(j in 0 until sources.length()) {
                    val obj=sources.getJSONObject(j)
                    val srcId=db.rawQuery("SELECT id FROM chats WHERE name=?",arrayOf(obj.getString("source_name"))).use{c->if(c.moveToFirst())c.getLong(0) else -1L}
                    if(srcId>=0)db.insertWithOnConflict("merged_chat_sources",null,ContentValues().apply{
                        put("merged_chat_id",mergedId);put("source_chat_id",srcId);put("source_key",obj.getString("source_key"))
                    },SQLiteDatabase.CONFLICT_IGNORE)
                }
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
    fun isMediaReferenced(name:String):Boolean=readableDatabase.rawQuery("SELECT 1 FROM messages WHERE attachment=? LIMIT 1",arrayOf(name)).use{it.moveToFirst()}
    // Merge is strictly additive. Existing messages, display names and existing metadata
    // are never overwritten. Return IDs/rowids for a precise undo of this import only.
    fun mergeBackup(snapshot:JSONObject, mediaNames:Map<String,String>):JSONObject {
        require(snapshot.getInt("format") in 1..2) { "Unsupported backup format" }
        val chatsIn=snapshot.getJSONArray("chats")
        val sql=writableDatabase
        val receipt=JSONObject().put("new_chats",JSONArray()).put("messages",JSONArray())
            .put("metadata",JSONArray()).put("bookmarks",JSONArray())
        var addedMessages=0;var ignored=0;var newChats=0
        fun add(table:String,values:ContentValues,log:Boolean=true):Long {
            val id=sql.insertWithOnConflict(table,null,values,SQLiteDatabase.CONFLICT_IGNORE)
            if(id>=0 && log)receipt.getJSONArray("metadata").put(JSONObject().put("table",table).put("id",id))
            return id
        }
        sql.beginTransaction()
        try {
            for(index in 0 until chatsIn.length()) {
                val chat=chatsIn.getJSONObject(index)
                val name=chat.getString("name").trim()
                require(name.isNotEmpty()) { "Backup contains an unnamed chat" }
                var id=sql.rawQuery("SELECT id FROM chats WHERE name=?",arrayOf(name)).use{c->if(c.moveToFirst())c.getLong(0) else -1L}
                val fresh=id<0
                if(fresh){
                    id=sql.insertOrThrow("chats",null,ContentValues().apply{put("name",name)})
                    receipt.getJSONArray("new_chats").put(id);newChats++
                }
                val msgs=chat.getJSONArray("messages")
                for(j in 0 until msgs.length()) {
                    val m=msgs.getJSONObject(j)
                    val attachment=if(m.isNull("attachment"))null else m.getString("attachment")
                    // A missing attachment remains missing; never fabricate or silently remap it.
                    val actual=attachment?.let{mediaNames[it] ?: it}
                    val values=ContentValues().apply{
                        put("chat_id",id);put("time",m.getLong("time"));put("sender",m.getString("sender"));put("body",m.getString("body"))
                        put("attachment",actual);put("fingerprint",m.getString("fingerprint"));put("occurrence",m.getInt("occurrence"))
                    }
                    val row=sql.insertWithOnConflict("messages",null,values,SQLiteDatabase.CONFLICT_IGNORE)
                    if(row>=0){receipt.getJSONArray("messages").put(row);addedMessages++}else ignored++
                }
                val importedFavourites=chat.optJSONArray("media_favourites") ?: JSONArray()
                for(k in 0 until importedFavourites.length()) {
                    val item=importedFavourites.getJSONObject(k)
                    sql.insertWithOnConflict("media_favourites",null,ContentValues().apply{
                        put("chat_id",id);put("fingerprint",item.getString("fingerprint"));put("occurrence",item.getInt("occurrence"))
                    },SQLiteDatabase.CONFLICT_IGNORE)
                }
                // Preserve current identity choices, bookmarks, and quote decisions.
                for((jsonKey,table,columns) in listOf(
                    Triple("sender_aliases","sender_aliases",listOf("original","identity")),
                    Triple("sender_names","sender_names",listOf("identity","display")),
                    Triple("voice_labels","voice_labels",listOf("fingerprint","occurrence","label")),
                    Triple("reply_link_status","reply_link_status",listOf("reply_fingerprint","reply_occurrence","status")),
                    Triple("reply_links","reply_links",listOf("reply_fingerprint","reply_occurrence","original_fingerprint","original_occurrence"))
                )) {
                    val items=chat.optJSONArray(jsonKey) ?: JSONArray()
                    for(j in 0 until items.length()) {
                        val item=items.getJSONObject(j)
                        val v=ContentValues().apply{put("chat_id",id)}
                        for(col in columns){if(col.endsWith("occurrence"))v.put(col,item.getInt(col)) else v.put(col,item.getString(col))}
                        // A quoted link is only valid when both endpoints exist here.
                        if(table=="reply_links"){
                            var present=true
                            for(prefix in listOf("reply","original")){
                                val found=sql.rawQuery("SELECT 1 FROM messages WHERE chat_id=? AND fingerprint=? AND occurrence=? LIMIT 1",arrayOf(id.toString(),item.getString(prefix+"_fingerprint"),item.getInt(prefix+"_occurrence").toString())).use{it.moveToFirst()}
                                if(!found)present=false
                            }
                            if(!present)continue
                        }
                        add(table,v)
                    }
                }
                val groups=chat.optJSONArray("bookmarks") ?: JSONArray()
                for(j in 0 until groups.length()) {
                    val mark=groups.getJSONObject(j)
                    val label=mark.getString("label");val saved=mark.getLong("saved_at")
                    val already=sql.rawQuery("SELECT id FROM bookmark_groups WHERE chat_id=? AND label=? AND saved_at=?",arrayOf(id.toString(),label,saved.toString())).use{it.moveToFirst()}
                    if(already)continue
                    val groupId=sql.insertOrThrow("bookmark_groups",null,ContentValues().apply{put("chat_id",id);put("label",label);put("saved_at",saved)})
                    receipt.getJSONArray("bookmarks").put(groupId)
                    val items=mark.getJSONArray("items")
                    for(k in 0 until items.length()){
                        val m=items.getJSONObject(k)
                        val target=sql.rawQuery("SELECT id FROM messages WHERE chat_id=? AND fingerprint=? AND occurrence=? LIMIT 1",arrayOf(id.toString(),m.getString("fingerprint"),m.getInt("occurrence").toString())).use{c->if(c.moveToFirst())c.getLong(0)else -1L}
                        if(target>=0)sql.insertWithOnConflict("bookmark_items",null,ContentValues().apply{put("group_id",groupId);put("message_id",target)},SQLiteDatabase.CONFLICT_IGNORE)
                    }
                }
                // Only restore progress for newly created chats; existing checkpoints take priority.
                if(fresh){
                    val checkpoint=chat.optString("web_checkpoint","")
                    if(checkpoint.isNotBlank())add("web_scan_checkpoint",ContentValues().apply{put("chat_id",id);put("message_id",checkpoint)})
                    val start=chat.optString("web_history_start","");val oldest=chat.optString("web_history_oldest","")
                    if(start.isNotBlank() && oldest.isNotBlank())add("web_history_resume",ContentValues().apply{put("chat_id",id);put("start_id",start);put("oldest_id",oldest);put("oldest_time",chat.optString("web_history_oldest_time",""))})
                }
            }
            sql.setTransactionSuccessful()
        } finally {sql.endTransaction()}
        receipt.put("added",addedMessages).put("duplicates",ignored).put("new_chat_count",newChats)
        return receipt
    }
    fun undoBackupMerge(receipt:JSONObject){
        val sql=writableDatabase
        sql.beginTransaction()
        try {
            val meta=receipt.getJSONArray("metadata")
            val allowed=setOf("sender_aliases","sender_names","voice_labels","reply_link_status","reply_links","web_scan_checkpoint","web_history_resume")
            for(i in meta.length()-1 downTo 0){val v=meta.getJSONObject(i);val table=v.getString("table");require(table in allowed)
                sql.delete(table,"rowid=?",arrayOf(v.getLong("id").toString()))}
            val groups=receipt.getJSONArray("bookmarks")
            for(i in 0 until groups.length()){
                val key=groups.getLong(i).toString();sql.delete("bookmark_items","group_id=?",arrayOf(key));sql.delete("bookmark_groups","id=?",arrayOf(key))
            }
            val msgs=receipt.getJSONArray("messages")
            for(i in 0 until msgs.length())sql.delete("messages","id=?",arrayOf(msgs.getLong(i).toString()))
            val fresh=receipt.getJSONArray("new_chats")
            for(i in 0 until fresh.length()){
                val key=fresh.getLong(i).toString()
                require(sql.rawQuery("SELECT COUNT(*) FROM messages WHERE chat_id=?",arrayOf(key)).use{it.moveToFirst();it.getInt(0)}==0){"New activity exists in a merged conversation. Undo blocked to protect it."}
                sql.delete("chats","id=?",arrayOf(key))
            }
            sql.setTransactionSuccessful()
        }finally{sql.endTransaction()}
    }
    companion object {
        fun hash(time: Long,sender: String,body: String): String {
            val raw = "$time\u0000$sender\u0000$body"
            return MessageDigest.getInstance("SHA-256").digest(raw.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
        }
    }
}
