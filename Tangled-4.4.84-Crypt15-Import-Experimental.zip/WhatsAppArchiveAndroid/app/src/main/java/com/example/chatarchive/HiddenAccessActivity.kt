package com.example.chatarchive

import android.app.Activity
import android.app.AlertDialog
import android.app.StatusBarManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.service.quicksettings.TileService
import android.view.Gravity
import android.view.View
import android.widget.*

/** Dedicated security settings; the main activity checks authentication before opening. */
class HiddenAccessActivity:Activity() {
    private val prefs by lazy { getSharedPreferences("tangled_hidden_entry",MODE_PRIVATE) }
    private val green=Color.rgb(7,94,84)
    private val choices=arrayOf("Tangled knot","Grid","Sliders","Circle")
    private val icons=intArrayOf(R.drawable.tangled_tile_large,R.drawable.tile_grid,R.drawable.tile_sliders,R.drawable.tile_circle)
    private fun dp(v:Int)=(resources.displayMetrics.density*v+.5f).toInt()
    private fun bg(color:Int,r:Int=14)=GradientDrawable().apply {setColor(color);cornerRadius=dp(r).toFloat()}
    private fun launcher()=ComponentName(this,"$packageName.LauncherEntry")
    private fun visible()=packageManager.getComponentEnabledSetting(launcher())!=PackageManager.COMPONENT_ENABLED_STATE_DISABLED
    private fun setLauncherIconVisible(v:Boolean) {packageManager.setComponentEnabledSetting(launcher(),if(v)PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,PackageManager.DONT_KILL_APP)}
    override fun onCreate(savedInstanceState:Bundle?) {super.onCreate(savedInstanceState);showPage()}
    private fun line(col:LinearLayout):LinearLayout {val x=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(10),0,dp(10))};col.addView(x);return x}
    private fun label(value:String,size:Float=15f,heavy:Boolean=false):TextView=TextView(this).apply{text=value;textSize=size;setTextColor(Color.rgb(35,43,49));if(heavy)setTypeface(null,Typeface.BOLD)}
    private fun button(text:String,onClick:()->Unit)=Button(this).apply {this.text=text;isAllCaps=false;setOnClickListener{onClick()}}
    private fun card(root:LinearLayout):LinearLayout {val box=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(12),dp(16),dp(12));background=bg(Color.WHITE)};root.addView(box,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(12)});return box}
    private fun section(root:LinearLayout,title:String,sub:String?=null):LinearLayout {val box=card(root);box.addView(label(title,18f,true));if(sub!=null){val t=label(sub,13f);t.setTextColor(Color.DKGRAY);t.setPadding(0,dp(5),0,dp(5));box.addView(t)};return box}
    private fun switchRow(box:LinearLayout,title:String,detail:String,checked:Boolean,onChange:(Boolean)->Unit){val r=line(box);val t=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL};t.addView(label(title,15f,true));t.addView(label(detail,12f));r.addView(t,LinearLayout.LayoutParams(0,-2,1f));val c=Switch(this).apply{isChecked=checked;setOnCheckedChangeListener{_,v->onChange(v)}};r.addView(c)}
    private fun refreshTile() {
        if(Build.VERSION.SDK_INT>=29)try {TileService.requestListeningState(this,ComponentName(this,TangledQuickTileService::class.java))}catch(_:Exception){}
    }
    private fun showPage() {
        val scroll=ScrollView(this).apply{isFillViewport=true;setBackgroundColor(Color.rgb(244,247,247))}
        val body=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(12),dp(16),dp(24))}
        scroll.addView(body)
        setContentView(scroll)
        val header=line(body)
        header.addView(button("‹ Back"){finish()})
        header.addView(label("Hidden App Access",21f,true))
        val access=section(body,"Ways to open Tangled","At least one access method must remain available.")
        switchRow(access,"App icon","Show Tangled in the app drawer",visible()) { enabled ->
            if(!enabled && !prefs.getBoolean("tile_enabled",false)) {
                AlertDialog.Builder(this).setTitle("Keep an access method").setMessage("Enable the Shortcuts Quick Settings tile before hiding Tangled. Your app icon is still visible.").setPositiveButton("OK"){_,_->showPage()}.show()
            }else if(!enabled) {
                AlertDialog.Builder(this).setTitle("Hide Tangled icon?").setMessage("Make sure Shortcuts has been added to Android Quick Settings and opens Tangled. Your icon will disappear from the launcher; Settings > Apps can still find Tangled.")
                    .setNegativeButton("Cancel"){_,_->showPage()}.setPositiveButton("Hide icon"){_,_->setLauncherIconVisible(false);showPage()}.show()
            }else {setLauncherIconVisible(true);showPage()}
        }
        switchRow(access,"Quick Settings shortcut","Open Tangled using the Shortcuts tile",prefs.getBoolean("tile_enabled",false)) { enabled ->
            if(!enabled && !visible()){
                AlertDialog.Builder(this).setMessage("Restore the app icon before disabling the only enabled access method.").setPositiveButton("OK"){_,_->showPage()}.show()
            } else {prefs.edit().putBoolean("tile_enabled",enabled).apply();refreshTile();showPage()}
        }
        val short=section(body,"Quick Settings appearance","Choose a tile icon and the label shown under it.")
        val current= prefs.getString("tile_label","Shortcuts")?:"Shortcuts"
        short.addView(label("Tile label",13f,true))
        val edit=EditText(this).apply{setSingleLine(true);setText(current);hint="Shortcuts";filters=arrayOf(android.text.InputFilter.LengthFilter(24))}
        short.addView(edit)
        short.addView(button("Save label"){val v=edit.text.toString().trim().ifBlank{"Shortcuts"};prefs.edit().putString("tile_label",v).apply();refreshTile();showPage()})
        short.addView(label("Icon",13f,true))
        val names=choices
        val choice=prefs.getInt("tile_icon",0).coerceIn(0,3)
        val preview=line(short)
        // Preview uses the selected icon, with the real Tangled knot enlarged.
        val tilePreview=LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(13),dp(9),dp(16),dp(9))
            background=bg(Color.rgb(222,235,249),28)
        }
        val previewIcon=ImageView(this).apply {
            setImageResource(icons[choice])
        }
        tilePreview.addView(previewIcon,LinearLayout.LayoutParams(dp(60),dp(60)))
        val previewTitle=label(current,16f,true)
        previewTitle.setPadding(dp(8),0,0,0)
        tilePreview.addView(previewTitle)
        preview.addView(tilePreview)
        short.addView(label("Preview only; Android controls the actual tile shape and colour.",12f))
        short.addView(button("Choose icon · ${names[choice]}"){
            AlertDialog.Builder(this).setTitle("Shortcut icon").setSingleChoiceItems(names,choice){dialog,n->prefs.edit().putInt("tile_icon",n).apply();dialog.dismiss();refreshTile();showPage()}.setNegativeButton("Cancel",null).show()
        })
        short.addView(button("Add Shortcuts tile to Quick Settings"){
            if(!prefs.getBoolean("tile_enabled",false)){Toast.makeText(this,"Enable Quick Settings shortcut first",Toast.LENGTH_LONG).show();return@button}
            if(Build.VERSION.SDK_INT>=33){val manager=getSystemService(StatusBarManager::class.java);manager.requestAddTileService(ComponentName(this,TangledQuickTileService::class.java),prefs.getString("tile_label","Shortcuts")?:"Shortcuts",Icon.createWithResource(this,icons[prefs.getInt("tile_icon",0).coerceIn(0,3)]),mainExecutor){result->runOnUiThread{Toast.makeText(this,"Tile request: $result",Toast.LENGTH_LONG).show()}}}
            else Toast.makeText(this,"Edit Android Quick Settings and add Shortcuts",Toast.LENGTH_LONG).show()
        })
        val reminder=section(body,"Recovery","The app icon is visible by default. You cannot hide it unless Quick Settings access is enabled, and you cannot disable Quick Settings while the icon is hidden.")
        reminder.addView(button("Restore app icon now"){setLauncherIconVisible(true);showPage()})
    }
}
