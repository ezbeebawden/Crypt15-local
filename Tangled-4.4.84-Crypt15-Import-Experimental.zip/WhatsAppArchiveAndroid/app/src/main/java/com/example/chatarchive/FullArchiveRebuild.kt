package com.example.chatarchive

import android.content.Context
import java.io.File
import java.security.MessageDigest

/** New archive is built and checked before the live SQLite data is replaced. */
internal class FullArchiveRebuild(private val context:Context,private val live:ArchiveDb) {
    private val vault=SyncedVault(context)
    private fun hash(f:File):String {
        val md=MessageDigest.getInstance("SHA-256")
        f.inputStream().use{ input ->
            val b=ByteArray(65536)
            while(true){val n=input.read(b);if(n<0)break;if(n>0)md.update(b,0,n)}
        }
        return md.digest().joinToString(""){ "%02x".format(it.toInt() and 255) }
    }
    fun rebuild(preserveAnnotations:Boolean=true):String {
        val annotations=if(preserveAnnotations) AnnotationPreserver().also{it.capture(live)} else null
        val sources=vault.list()
        val chats=sources.filter{it.kind=="chat"}.sortedBy{it.name}
        require(chats.isNotEmpty()) { "No conversation ZIP/TXT files remain in Private Files. Nothing changed." }
        // Verify each source, including QARs, BEFORE touching the live archive.
        for(item in sources){
            val f=File(context.filesDir,"synced_source_vault/${item.id}")
            require(f.isFile && f.length()==item.bytes && hash(f)==item.hash) {
                "Private source missing or damaged: ${item.name}. Nothing changed."
            }
        }
        val name="archive_fresh_rebuild.db"
        context.deleteDatabase(name)
        val stagedMedia=File(context.cacheDir,"archive_fresh_media").also {it.deleteRecursively();it.mkdirs()}
        val stage=ArchiveDb(context,name)
        try {
            val import=ArchiveIO(context,stage,stagedMedia)
            val sourceNames=AutoSync(context,stage,import)
            var added=0
            for(item in chats) {
                val chatName=sourceNames.suggestedChatName(item.name)
                require(chatName.isNotBlank()) { "Cannot determine conversation name for ${item.name}" }
                val result=import.importChat(vault.uri(item),chatName,originalName=item.name)
                added+=result.first
            }
            require(stage.chats().isNotEmpty()) { "No conversations rebuilt" }
            val qar=sourceNames.importPrivateQarIntoFreshArchive()
            val web=sourceNames.importPrivateWebIntoFreshArchive()
            val annotationReport=annotations?.restore(stage)
            val rebuiltChats=stage.chats().size
            val databasePath=context.getDatabasePath(name).absolutePath
            stage.close()
            // Media and database have separate storage. Stage media before DB commit;
            // preserve originals until the new database is successfully installed.
            val media=File(context.filesDir,"media").apply{mkdirs()}
            val newlyAdded=mutableListOf<File>()
            try {
                for(file in stagedMedia.listFiles().orEmpty().filter{it.isFile}) {
                    val target=File(media,file.name)
                    if(!target.exists()){
                        file.copyTo(target)
                        newlyAdded.add(target)
                    } else if(hash(target)!=hash(file)) {
                        error("Existing media collision ${file.name}; original archive left unchanged")
                    }
                }
                live.replaceWithStagedArchive(databasePath)
            }catch(t:Throwable){newlyAdded.forEach{it.delete()};throw t}
            // Save any unmatched personal annotations for recovery, without reintroducing missing conversations.
            if(preserveAnnotations && annotationReport!=null) {
                runCatching {
                    val recovery=File(context.filesDir,"tangled-unmatched-annotations.json")
                    if(annotationReport.unmatched>0)recovery.writeText(annotationReport.unmatchedJson.toString(2))
                    else recovery.delete()
                }
            } else if(!preserveAnnotations) File(context.filesDir,"tangled-unmatched-annotations.json").delete()
            // Stale association preferences refer to old chat IDs and must not be
            // carried into the freshly allocated ID space. Keep folder/lock settings.
            val preferences=context.getSharedPreferences("tangled_auto_sync",Context.MODE_PRIVATE)
            val edit=preferences.edit()
            for(key in preferences.all.keys) {
                if(key.startsWith("assoc_") || key.startsWith("blocked_") || key.startsWith("wait_") ||
                    key.startsWith("undo_checkpoint_"))edit.remove(key)
            }
            edit.apply()
            val mainPrefs=context.getSharedPreferences("MainActivity",Context.MODE_PRIVATE)
            val mainEdit=mainPrefs.edit()
            for(key in mainPrefs.all.keys)if(key.startsWith("sender_"))mainEdit.remove(key)
            mainEdit.apply()
            // The prior vault index chat IDs are stale after the rebuild.
            // Resolve fresh IDs using the surviving filenames, never old IDs.
            val freshByName=live.chats().associateBy{it.name.trim().lowercase(java.util.Locale.ROOT)}
            for(item in sources){
                val candidateName=if(item.kind=="chat")sourceNames.suggestedChatName(item.name)
                else {
                    val stem=item.name.substringBeforeLast('.')
                    Regex("^(.+)-\\d{12,17}$").matchEntire(stem)?.groupValues?.get(1)
                        ?: Regex("(?i)^(.+?)-quoted-(?:history|update|replies)$").matchEntire(stem)?.groupValues?.get(1).orEmpty()
                }
                val found=freshByName[candidateName.trim().lowercase(java.util.Locale.ROOT)]?.id ?: -1L
                if(item.chatId!=found)runCatching{vault.setChat(item,found)}
            }
            // Remove orphan media only AFTER the replacement is committed.
            val valid=stagedMedia.listFiles().orEmpty().map{it.name}.toSet()
            var removed=0
            for(old in media.listFiles().orEmpty().filter{it.isFile && it.name !in valid}){
                if(old.delete())removed++
            }
            return "Entire archive rebuilt from Private Files: $rebuiltChats conversations, $added new messages, $qar, $web. " +
                "Excluded deleted private sources; $removed unused media files cleared. " +
                (annotationReport?.toString()?.plus(". ") ?: "Personal annotations reset. ") + "All source files retained."
        } finally {
            runCatching{stage.close()}
            context.deleteDatabase(name)
            stagedMedia.deleteRecursively()
        }
    }
}
