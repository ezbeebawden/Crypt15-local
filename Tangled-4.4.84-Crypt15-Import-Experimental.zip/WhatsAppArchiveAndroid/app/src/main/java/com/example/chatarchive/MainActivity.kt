package com.example.chatarchive

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.ComponentName
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.media.ThumbnailUtils
import android.provider.MediaStore
import android.provider.DocumentsContract
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.widget.MediaController
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.content.res.Configuration
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import android.os.Build
import android.hardware.biometrics.BiometricPrompt
import android.hardware.biometrics.BiometricManager
import android.os.CancellationSignal
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.StyleSpan
import android.text.style.RelativeSizeSpan
import android.text.style.ReplacementSpan
import android.text.style.ForegroundColorSpan
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Calendar
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {
    // At most one chat voice note plays at a time. Releasing on stop prevents
    // orphaned players when switching conversations or leaving the app.
    private var inChatPlayer: MediaPlayer? = null
    private var inChatUpdate: Runnable? = null
    private val inChatHandler = Handler(Looper.getMainLooper())
    private fun stopInChatAudio() {
        inChatUpdate?.let { inChatHandler.removeCallbacks(it) }
        inChatUpdate = null
        inChatPlayer?.let { try { it.stop() } catch (_: Exception) {}; it.release() }
        inChatPlayer = null
    }
    private fun audioClock(milliseconds: Int): String {
        val seconds = (milliseconds.coerceAtLeast(0) / 1000)
        return "%d:%02d".format(Locale.UK, seconds / 60, seconds % 60)
    }
    private fun addInlineVoicePlayer(bubble: LinearLayout, file: File, mine: Boolean) {
        val accent = if (mine) Color.rgb(7, 132, 105) else Color.rgb(157, 87, 173)
        val row = LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(4),dp(6),dp(4),dp(4))
            minimumWidth=dp(230)
        }
        val play=TextView(this).apply {
            text="▶"; textSize=23f; gravity=Gravity.CENTER
            setTextColor(Color.WHITE); background=bg(accent,30)
            contentDescription="Play voice note"
        }
        row.addView(play,LinearLayout.LayoutParams(dp(42),dp(42)))
        val right=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        val seek=SeekBar(this).apply {
            max=1000; progress=0
            progressTintList=android.content.res.ColorStateList.valueOf(accent)
            thumbTintList=android.content.res.ColorStateList.valueOf(accent)
            progressBackgroundTintList=android.content.res.ColorStateList.valueOf(Color.LTGRAY)
        }
        right.addView(seek,LinearLayout.LayoutParams(-1,dp(30)))
        val timing=text("0:00 / --:--",11f,if(darkMode)Color.LTGRAY else Color.DKGRAY).apply{
            setPadding(dp(15),0,0,0)
        }
        right.addView(timing)
        row.addView(right,LinearLayout.LayoutParams(dp(185),-2))
        bubble.addView(row)
        // Duration metadata is read lazily; never decode the entire audio stream
        // just to display a chat bubble.
        try {
            val retriever=MediaMetadataRetriever()
            try {
                retriever.setDataSource(file.absolutePath)
                val dur=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toIntOrNull()
                if(dur!=null) timing.text="0:00 / ${audioClock(dur)}"
            } finally { retriever.release() }
        } catch (_: Exception) {}
        var current: MediaPlayer?=null
        fun startPlayback() {
            val p = current
            if(p != null && p === inChatPlayer) {
                if(p.isPlaying) {p.pause();play.text="▶";play.contentDescription="Resume voice note"}
                else {p.start();play.text="❚❚";play.contentDescription="Pause voice note"}
                return
            }
            stopInChatAudio()
            try {
                val player=MediaPlayer()
                player.setDataSource(file.absolutePath)
                player.prepare()
                current=player
                inChatPlayer=player
                play.text="❚❚"; play.contentDescription="Pause voice note"
                player.setOnCompletionListener {
                    if(inChatPlayer===player) {
                        play.text="▶"; play.contentDescription="Replay voice note"
                        seek.progress=0
                        timing.text="0:00 / ${audioClock(player.duration)}"
                        player.seekTo(0)
                        // Keep the prepared player for replay. It is released when
                        // another clip starts or the Activity stops.
                        inChatUpdate?.let{inChatHandler.removeCallbacks(it)}
                        inChatUpdate=null
                    }
                }
                val updater=object:Runnable {
                    override fun run() {
                        if(inChatPlayer!==player) return
                        val duration=player.duration.coerceAtLeast(1)
                        val position=player.currentPosition.coerceIn(0,duration)
                        seek.progress=(position.toLong()*1000/duration).toInt()
                        timing.text="${audioClock(position)} / ${audioClock(duration)}"
                        inChatHandler.postDelayed(this,180)
                    }
                }
                inChatUpdate=updater
                player.start()
                inChatHandler.post(updater)
            } catch(e:Exception) {
                stopInChatAudio()
                current=null
                play.text="▶"
                alert("Unable to play this voice note: ${e.localizedMessage ?: "unsupported audio"}")
            }
        }
        play.setOnClickListener { startPlayback() }
        seek.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar:SeekBar, progress:Int, fromUser:Boolean) {
                if(!fromUser)return
                val p=current
                if(p!=null && p===inChatPlayer && p.duration>0) {
                    val target=(p.duration.toLong()*progress/1000).toInt()
                    p.seekTo(target)
                    timing.text="${audioClock(target)} / ${audioClock(p.duration)}"
                }
            }
            override fun onStartTrackingTouch(bar:SeekBar) {}
            override fun onStopTrackingTouch(bar:SeekBar) {}
        })
    }
    private val senderGraphColors=intArrayOf(Color.rgb(7,132,105),Color.rgb(157,87,173),Color.rgb(49,143,196),Color.rgb(218,139,64))
    private var authenticated = false
    private var showingUnlock = false
    private fun securityPrefs() = getSharedPreferences("chatarchive_security",MODE_PRIVATE)
    private fun pinHash(secret: String, salt: ByteArray): String {
        val spec=PBEKeySpec(secret.toCharArray(),salt,120000,256)
        return try {Base64.encodeToString(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded,Base64.NO_WRAP)} finally {spec.clearPassword()}
    }
    private fun enabledLock()=securityPrefs().contains("hash")

// Every successful unlock must perform the folder check that onResume skipped
// while the archive was locked (notably when returning from Chrome).
private fun onArchiveUnlocked() {
    authenticated=true
    showingUnlock=false
    showHome()
    // Run after the unlocked screen is installed; never scan private files locked.
    autoHandler.post { if(authenticated && !isFinishing && !externalFilePickerOpen) {
        startAutoSync(false)
    } }
}
private fun unlock() {
    if(!enabledLock()) {onArchiveUnlocked();return}
    if(showingUnlock)return
    showingUnlock=true
    if(Build.VERSION.SDK_INT >= 28 && securityPrefs().getBoolean("biometric", false)) {
        showBiometricUnlockScreen()
    } else {
        showPinUnlockDialog()
    }
}
private fun verifySecret(secret: String): Boolean {
    val prefs=securityPrefs()
    val saltString=prefs.getString("salt","") ?: ""
    if(saltString.isBlank()) return false
    val salt=Base64.decode(saltString,Base64.NO_WRAP)
    return pinHash(secret,salt)==prefs.getString("hash","")
}
private fun showPinUnlockDialog() {
    val entry=EditText(this).apply{hint="PIN or password";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
    val dialog=AlertDialog.Builder(this).setTitle("Unlock Tangled").setView(entry).setCancelable(false)
        .setPositiveButton("Unlock",null)
        .setNegativeButton("Cancel") { _, _ -> finishAffinity() }
        .setNeutralButton(if(Build.VERSION.SDK_INT >= 28 && securityPrefs().getBoolean("biometric",false)) "Try fingerprint again" else "",null).create()
    dialog.setOnShowListener {
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            if(verifySecret(entry.text.toString())) {dialog.dismiss();onArchiveUnlocked()}
            else entry.error="Incorrect PIN/password"
        }
        val neutral=dialog.getButton(AlertDialog.BUTTON_NEUTRAL)
        if(Build.VERSION.SDK_INT < 28 || !securityPrefs().getBoolean("biometric",false)) neutral.visibility=View.GONE
        else neutral.setOnClickListener { dialog.dismiss(); showingUnlock=false; showBiometricUnlockScreen() }
    }
    dialog.show()
}
private fun showBiometricUnlockScreen() {
    root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(green);setPadding(dp(20),dp(24),dp(20),dp(24));gravity=Gravity.CENTER_HORIZONTAL}
    setContentView(root)
    root.addView(Space(this), LinearLayout.LayoutParams(-1,0,1f))
    val logo=ImageView(this).apply {
        setImageResource(com.example.chatarchive.R.mipmap.ic_launcher)
        scaleType=ImageView.ScaleType.CENTER_CROP
        background=GradientDrawable().apply { shape=GradientDrawable.OVAL }
        clipToOutline=true
    }
    root.addView(logo, LinearLayout.LayoutParams(dp(92),dp(92)))
    root.addView(text("Tangled",24f,Color.WHITE,true).apply{gravity=Gravity.CENTER_HORIZONTAL})
    val card=LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL
        gravity=Gravity.CENTER_HORIZONTAL
        setPadding(dp(20),dp(28),dp(20),dp(28))
        background=outlinedBg(Color.argb(35,255,255,255), Color.argb(110,255,255,255), 18)
    }
    card.addView(text("⌁",40f,Color.WHITE,true).apply{gravity=Gravity.CENTER_HORIZONTAL})
    card.addView(text("Unlock with fingerprint",17f,Color.WHITE,true).apply{gravity=Gravity.CENTER_HORIZONTAL})
    card.addView(text("Touch the fingerprint sensor",13f,Color.argb(220,255,255,255)).apply{gravity=Gravity.CENTER_HORIZONTAL})
    root.addView(card, LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(30)})
    val pinFallback=text("Use PIN instead",14f,Color.WHITE,false).apply {
        gravity=Gravity.CENTER_HORIZONTAL
        setPadding(dp(8),dp(26),dp(8),dp(8))
        paint.isUnderlineText=true
        setOnClickListener { showingUnlock=false; showPinUnlockDialog() }
    }
    root.addView(pinFallback)
    root.addView(Space(this), LinearLayout.LayoutParams(-1,0,1f))
    root.post { biometricUnlock() }
}
private fun biometricUnlock() {
    if(Build.VERSION.SDK_INT < 28) {showingUnlock=false; showPinUnlockDialog(); return}
    val prompt=BiometricPrompt.Builder(this).setTitle("Unlock Tangled").setSubtitle("Use your fingerprint")
        .setNegativeButton("Use PIN instead",mainExecutor){_,_-> runOnUiThread { if(showingUnlock) { showingUnlock=false; showPinUnlockDialog() } } }.build()
    prompt.authenticate(CancellationSignal(),mainExecutor,object:BiometricPrompt.AuthenticationCallback(){
        override fun onAuthenticationSucceeded(result:BiometricPrompt.AuthenticationResult) {onArchiveUnlocked()}
        override fun onAuthenticationError(errorCode:Int,errString:CharSequence) {
            if(errorCode != 13 && errorCode != 5 && errorCode != 10) {
                Toast.makeText(this@MainActivity, errString, Toast.LENGTH_SHORT).show()
                showingUnlock=false
                showPinUnlockDialog()
            }
        }
    })
}
    private fun continuousScrollEnabled() = getPreferences(MODE_PRIVATE).getBoolean("continuous_scroll", true)

    private fun showSettings() {
        val options=arrayOf("Paged chat scrolling", "Continuous chat scrolling (default)", "Archive maintenance · Rebuild entire archive")
        val installedVersion=try {packageManager.getPackageInfo(packageName,0).versionName ?: "Unknown"}catch(_:Exception){"Unknown"}
        AlertDialog.Builder(this).setTitle("Settings · Tangled $installedVersion")
            .setSingleChoiceItems(options,if(continuousScrollEnabled())1 else 0) {dialog,which->
                if(which==2){dialog.dismiss();showArchiveMaintenance();return@setSingleChoiceItems}
                getPreferences(MODE_PRIVATE).edit().putBoolean("continuous_scroll",which==1).apply()
                dialog.dismiss()
                AlertDialog.Builder(this).setTitle("Settings")
                    .setMessage("Tangled $installedVersion\n\nScroll method saved. It will apply when you next open a conversation.\n\nApp lock settings are also available here.")
                    .setPositiveButton("Done",null)
                    .setNeutralButton("App lock settings"){_,_->securitySettings()}.show()
            }.setNeutralButton("App lock settings"){_,_->securitySettings()}
            .setPositiveButton("Hidden app access"){_,_->hiddenAppSettings()}
            .setNegativeButton("Cancel",null).show()
    }

    private fun selectChatDate(id:Long, query:String) {
        val calendar=Calendar.getInstance()
        android.app.DatePickerDialog(this,{_,year,month,day->
            val selected=Calendar.getInstance().apply {set(Calendar.YEAR,year);set(Calendar.MONTH,month);set(Calendar.DAY_OF_MONTH,day);set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}.timeInMillis
            val target=db.messageOnOrAfter(id,query,selected)
            if(target==null) {alert("There are no messages on or after that date.");return@DatePickerDialog}
            val destination=db.pageForMessage(id,target) ?: 0
            showChat("",destination,"${target.fingerprint}:${target.occurrence}")
            if(target.time>=selected+86400000L) {
                Toast.makeText(this,"Showing the next available message: ${dayFormat.format(Date(target.time))}",Toast.LENGTH_LONG).show()
            }
        },calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun securitySettings() {
        val opts=if(enabledLock()) arrayOf("Change PIN/password","Turn fingerprint ${if(securityPrefs().getBoolean("biometric",false)) "off" else "on"}","Disable app lock","Hidden app access") else arrayOf("Enable PIN/password lock","Hidden app access")
        AlertDialog.Builder(this).setTitle("App lock").setItems(opts){_,which->
            if((enabledLock() && which==3) || (!enabledLock() && which==1)) {hiddenAppSettings();return@setItems}
            if(!enabledLock() || which==0) {
                val entry=EditText(this).apply{hint="New PIN (4+ digits) or password";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
                AlertDialog.Builder(this).setTitle("Set app lock").setView(entry).setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->
                    val pw=entry.text.toString()
                    if(pw.length<4) {alert("Use at least four characters.")} else {
                        val salt=ByteArray(16).also{SecureRandom().nextBytes(it)}
                        securityPrefs().edit().putString("salt",Base64.encodeToString(salt,Base64.NO_WRAP)).putString("hash",pinHash(pw,salt)).apply()
                        alert("App lock enabled. Remember your PIN/password; losing it may prevent access to your archive.")
                    }
                }.show()
            } else if(which==1) {
                if(Build.VERSION.SDK_INT<28) alert("Fingerprint requires Android 9 or newer.")
                else {val next=!securityPrefs().getBoolean("biometric",false); securityPrefs().edit().putBoolean("biometric",next).apply();alert(if(next)"Fingerprint enabled (with PIN/password fallback)." else "Fingerprint disabled.")}
            } else AlertDialog.Builder(this).setTitle("Disable app lock?").setNegativeButton("Cancel",null).setPositiveButton("Disable"){_,_->securityPrefs().edit().clear().apply()}.show()
        }.show()
    }
    private lateinit var db: ArchiveDb
    private lateinit var io: ArchiveIO
    private lateinit var autoSync: AutoSync
    private var latestAutoReport:AutoSync.ScanReport?=null
    private val scanningAuto=java.util.concurrent.atomic.AtomicBoolean(false)
    private val autoHandler=android.os.Handler(android.os.Looper.getMainLooper())
    private var syncedFilesRefreshGeneration=0
    private val periodicAuto=object:Runnable {
        override fun run(){
            if(authenticated && !isFinishing) startAutoSync(false)
            autoHandler.postDelayed(this,90_000L)
        }
    }
    private lateinit var root: LinearLayout
    private var chatId: Long? = null
    private var chatName = ""
    private var mySender = ""
    private var pendingReply: Message? = null
    private var selectingReply = false
    private var externalFilePickerOpen = false
    private var searchExpanded = false
    private var searchSelectionQuery = ""
    private var searchSelectionIndex = 0
    // Retain the exact chat page when visiting statistics, including Android Back.
    private var statsVisible = false
    // Explicitly track screens: system gesture Back and the visible arrow use the same route.
    private var currentScreen = "home"
    private val mergeSelection = linkedSetOf<Long>()
    private var autoSyncReturnToChat = false
    private var systemBackCallback: android.window.OnBackInvokedCallback? = null
    private var previousChatQuery = ""
    private var previousChatPage = 0
    private val compactTimeFormat = SimpleDateFormat("HH:mm",Locale.UK)

    private fun senderPreference(id: Long) = "sender_$id"
    private fun selectSender(id: Long) {
        val saved = getPreferences(MODE_PRIVATE).getString(senderPreference(id), null)
        mySender = saved ?: db.participants(id).firstOrNull().orEmpty()
    }
    private val green = Color.rgb(7,94,84)
    private val dateFormat = SimpleDateFormat("d MMM yyyy · HH:mm",Locale.UK)
    private val dayFormat = SimpleDateFormat("EEEE, d MMMM yyyy",Locale.UK)
    private val importCode=101; private val backupCode=102; private val restoreCode=103; private val replyJsonCode=104; private val folderCode=105; private val mergeCode=106; private val vaultExportCode=107; private val vaultRestoreAllCode=108; private val cryptImportCode=109
    private val cryptSync by lazy { Crypt15Sync(this,db) }
    private var exportingPrivateSource:SyncedVault.Item?=null
    private var movingPrivateSource=false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        restoreLauncherOn455Upgrade()
        db=ArchiveDb(this); io=ArchiveIO(this,db);autoSync=AutoSync(this,db,io)
        chatId=savedInstanceState?.getLong("tangled_chat_id")?.takeIf { it>0L }
        chatName=savedInstanceState?.getString("tangled_chat_name").orEmpty()
        if(chatId!=null)selectSender(chatId!!)
        // Android 13+ gesture navigation dispatches through OnBackInvokedDispatcher.
        // Older Android versions continue to use onBackPressed below.
        if (Build.VERSION.SDK_INT >= 33) {
            val callback = android.window.OnBackInvokedCallback { runOnUiThread { navigateBack() } }
            systemBackCallback = callback
            onBackInvokedDispatcher.registerOnBackInvokedCallback(
                android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, callback
            )
        }
    }
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // A singleTop Activity may receive onNewIntent without a subsequent
        // onResume. Post the verification to the visible Activity's UI loop.
        window.decorView.post {
            if(hasWindowFocus()) verifyVisibleEntry(intent)
        }
    }
    private fun privateEntryPrefs()=getSharedPreferences("tangled_hidden_entry",MODE_PRIVATE)
    private fun verifyVisibleEntry(intent:Intent?) {
        val prefs=privateEntryPrefs()
        when {
            intent?.getBooleanExtra("tangled_from_tile",false)==true &&
                prefs.getBoolean("tile_enabled",false) &&
                prefs.getLong("tile_pressed_at",0L)>0L &&
                android.os.SystemClock.elapsedRealtime()-prefs.getLong("tile_pressed_at",0L)<30000L -> {
                prefs.edit().putBoolean("tile_tested",true).remove("tile_pressed_at").apply()
            }
            intent?.action==Intent.ACTION_VIEW && intent.data?.scheme=="tangled" &&
                intent.data?.host=="open" && prefs.getBoolean("link_enabled",true) -> {
                // An actual external navigation to this activity, not a test button
                // inside Tangled. Chrome may not support typing custom URL schemes.
                prefs.edit().putBoolean("link_tested",true).apply()
            }
        }
        // Avoid replaying a previously verified click on every resume.
        if(intent?.getBooleanExtra("tangled_from_tile",false)==true) {
            intent.removeExtra("tangled_from_tile")
        }
    }
    // Force safe recovery once after upgrading: Android preserves launcher
    // component state even across APK updates. No chat or vault data is touched.
    private fun restoreLauncherOn455Upgrade() {
        val prefs=privateEntryPrefs()
        if(!prefs.getBoolean("launcher_recovered_455",false)) {
            setLauncherVisible(true)
            prefs.edit().putBoolean("launcher_recovered_455",true)
                .putBoolean("tile_tested",false).remove("tile_pressed_at").apply()
        }
        // Repair tile service disabled by older versions. The service remains
        // installed and registered even when the tile toggle is turned off.
        val component=ComponentName(this,TangledQuickTileService::class.java)
        if(packageManager.getComponentEnabledSetting(component)==PackageManager.COMPONENT_ENABLED_STATE_DISABLED) {
            packageManager.setComponentEnabledSetting(component,
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,PackageManager.DONT_KILL_APP)
        }
    }
    private fun launcherComponent()=ComponentName(this,"$packageName.LauncherEntry")
    private fun launcherVisible():Boolean = packageManager.getComponentEnabledSetting(launcherComponent())!=PackageManager.COMPONENT_ENABLED_STATE_DISABLED
    private fun setLauncherVisible(visible:Boolean) {
        packageManager.setComponentEnabledSetting(launcherComponent(),
            if(visible)PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP)
    }
    private fun setTileEnabled(enabled:Boolean) {
        // Do not disable the TileService component: Android may remove an
        // already user-added Quick Settings tile when its service is disabled.
        // Keep it registered and control eligibility for hiding the icon with
        // the preference and a real observed tile launch.
        privateEntryPrefs().edit().putBoolean("tile_enabled",enabled).apply()
        if(!enabled)privateEntryPrefs().edit().putBoolean("tile_tested",false).apply()
    }
    private fun hiddenAppSettings() {
        if(!authenticated) { alert("Unlock Tangled before changing access methods."); return }
        startActivity(Intent(this,HiddenAccessActivity::class.java))
    }
    override fun onDestroy() {
        stopInChatAudio()
        if (Build.VERSION.SDK_INT >= 33) {
            systemBackCallback?.let { onBackInvokedDispatcher.unregisterOnBackInvokedCallback(it) }
            systemBackCallback = null
        }
        super.onDestroy()
    }
    override fun onSaveInstanceState(outState:Bundle) {
        super.onSaveInstanceState(outState)
        outState.putLong("tangled_chat_id",chatId ?: 0L)
        outState.putString("tangled_chat_name",chatName)
    }
    override fun onStop() {
        stopInChatAudio()
        super.onStop()
        autoHandler.removeCallbacks(periodicAuto)
        // Android's document picker is part of an in-progress import, not a
        // return from another app. Do not replace its result with the lock screen.
        if(enabledLock() && !externalFilePickerOpen) {
            authenticated=false
            showingUnlock=false
        }
    }
    override fun onResume() {
        super.onResume()
        verifyVisibleEntry(intent)
        if(!::db.isInitialized) return
        autoHandler.removeCallbacks(periodicAuto)
        autoHandler.postDelayed(periodicAuto,90_000L)
        if(!authenticated && !showingUnlock) unlock()
        if(authenticated && !externalFilePickerOpen){startAutoSync(false)}
        if(!authenticated && showingUnlock && securityPrefs().getBoolean("biometric",false)) {
            // Show the system prompt only after the Activity reaches RESUMED state.
            window.decorView.post { if(!authenticated && showingUnlock && !isFinishing) biometricUnlock() }
        }
    }
    private fun dp(value:Int)= (resources.displayMetrics.density*value).toInt()
    private val darkMode:Boolean get()=(resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES
    private val pageColor:Int get()=if(darkMode)Color.rgb(0,0,0) else Color.rgb(242,245,243)
    private val cardColor:Int get()=if(darkMode)Color.rgb(24,29,27) else Color.WHITE
    private val bodyColor:Int get()=if(darkMode)Color.WHITE else Color.BLACK
    private val mutedColor:Int get()=if(darkMode)Color.rgb(195,205,200) else Color.DKGRAY
    private val accentColor:Int get()=if(darkMode)Color.rgb(112,220,180) else green
    private fun adaptColor(color:Int):Int=when {
        !darkMode -> color
        color==Color.WHITE -> cardColor
        color==Color.BLACK -> bodyColor
        color==Color.DKGRAY || color==Color.GRAY -> mutedColor
        color==Color.rgb(242,245,243) -> pageColor
        color==Color.rgb(216,248,202) -> Color.rgb(26,67,49)
        color==Color.rgb(236,244,239) -> Color.rgb(32,48,42)
        color==Color.rgb(255,236,179) -> Color.rgb(79,61,27)
        else -> color
    }
    private fun bg(color:Int,radius:Int=12)=GradientDrawable().apply{setColor(adaptColor(color));cornerRadius=dp(radius).toFloat()}
    private fun outlinedBg(fill:Int, stroke:Int = Color.argb(55,0,0,0), radius:Int=12, strokeDp:Int=1)=GradientDrawable().apply{
        setColor(adaptColor(fill))
        cornerRadius=dp(radius).toFloat()
        setStroke(dp(strokeDp), if(darkMode && Color.red(stroke)<100 && Color.green(stroke)<100 && Color.blue(stroke)<100) Color.rgb(70,86,78) else stroke)
    }
    // Preserve original message bytes in SQLite; format only when displaying.
    // Whatsapp *bold* and _italic_ use single-character delimiters.
    private fun formattedMessage(raw: String): CharSequence {
        // Display-only formatting: keep the original stored message untouched.
        // Remove optional directional marks and angle brackets from the exported edit annotation.
        val editedTag = Regex("(?i)[\\u200e\\u200f\\u202a-\\u202e]*[ \t]*\\(?<?this message was edited>?\\)?")
        // Use a private marker until spans are applied so ordinary occurrences of
        // the word "edited" in a message are never mistaken for an edit notice.
        val editMarker = "\uE000TANGLED_EDIT\uE001"
        val markerPattern = Regex.escape(editMarker)
        val cleaned = editedTag.replace(raw) { editMarker }
            .replace(Regex("[ \t]*\n[ \t]*(?=$markerPattern)"), "\n\n")
            .replace(Regex("(?<!\n)$markerPattern"), "\n\n$editMarker")
            .replace(Regex("\n{3,}"), "\n\n")
            .trimStart('\n')
        val pattern = Regex("(?<!\\w)([*_])([^\\n]+?)\\1(?!\\w)")
        val out = SpannableStringBuilder()
        var cursor = 0
        for (match in pattern.findAll(cleaned)) {
            out.append(cleaned.substring(cursor, match.range.first))
            val start = out.length
            out.append(match.groupValues[2])
            out.setSpan(StyleSpan(if (match.groupValues[1] == "*") Typeface.BOLD else Typeface.ITALIC), start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            cursor = match.range.last + 1
        }
        out.append(cleaned.substring(cursor))
        // Replace only verified WhatsApp edit annotations, display-only.
        // Iterate backwards to retain correct offsets when multiple notices exist.
        for (match in Regex(Regex.escape(editMarker)).findAll(out.toString()).toList().asReversed()) {
            val start = match.range.first
            out.replace(start, match.range.last + 1, "edited")
            out.setSpan(StyleSpan(Typeface.ITALIC), start, start + "edited".length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return out
    }

    private fun text(value:String,size:Float=16f,color:Int=Color.BLACK,bold:Boolean=false)=TextView(this).apply {
        this.text=value; textSize=size;setTextColor(if(darkMode && color==green)accentColor else if(darkMode && color==Color.WHITE)Color.WHITE else adaptColor(color));setPadding(dp(4),dp(4),dp(4),dp(4)); if(bold) setTypeface(null,Typeface.BOLD)
    }
    private fun button(label:String, action:()->Unit)=Button(this).apply{
        text=label; isAllCaps=false; textSize=13f
        setTextColor(accentColor); background=outlinedBg(Color.WHITE,Color.argb(90,7,94,84),12)
        minHeight=dp(44); minimumHeight=dp(44); elevation=0f
        setPadding(dp(9),dp(7),dp(9),dp(7))
        setOnClickListener{action()}
    }
    private fun renameMenu(id:Long, query:String, page:Int) {
        val choices=arrayOf("Rename conversation", "Change sides (choose sender)", "Rename participants", "Match identities", "Restore original names", "Remove identity matches")
        AlertDialog.Builder(this).setTitle("Chat Edits").setItems(choices) { _,choice ->
            if(choice==0) {
                val field=EditText(this).apply{setSingleLine(true);setText(chatName);selectAll()}
                AlertDialog.Builder(this).setTitle("Rename conversation").setView(field)
                    .setNegativeButton("Cancel",null).setPositiveButton("Save") { _,_->
                        val newName=field.text.toString().trim()
                        if(newName.isNotEmpty()) {
                            try {
                                val oldName=chatName
                                db.renameChat(id,newName)
                                chatName=newName
                                // Keep old source aliases while renaming the current and archived ZIPs.
                                thread {
                                    val warning=runCatching{autoSync.renameStoredFiles(id,oldName,newName)}.getOrElse{"ZIP renaming needs review: ${it.message}"}
                                    if(!warning.isNullOrBlank())runOnUiThread{alert(warning)}
                                }
                                showChat(query,page)
                            }
                            catch(e:Exception){alert("Unable to rename: the name may already exist.")}
                        }
                    }.show()
            } else if(choice==1) chooseChatSender(id,query,page)
            else manageNames(id,query,page,choice-2)
        }.show()
    }
    private fun chooseChatSender(id:Long,query:String,page:Int) {
        val people=db.participants(id)
        if(people.isEmpty()) {alert("No participants found");return}
        AlertDialog.Builder(this).setTitle("Whose messages appear on the right?")
            .setSingleChoiceItems(people.toTypedArray(),people.indexOf(mySender).coerceAtLeast(0)) {dialog,index->
                mySender=people[index]
                getPreferences(MODE_PRIVATE).edit().putString(senderPreference(id),mySender).apply()
                dialog.dismiss();showChat(query,page)
            }.setNegativeButton("Cancel",null).show()
    }
    private fun miniIcon(symbol:String,description:String,action:()->Unit):TextView = TextView(this).apply {
        text=symbol;textSize=24f;gravity=Gravity.CENTER;setTextColor(accentColor)
        contentDescription=description
        background=outlinedBg(Color.WHITE,Color.argb(90,7,94,84),12)
        setOnClickListener {action()}
    }
    private fun pageNavigation(page:Int, canOlder:Boolean, older:()->Unit, newer:()->Unit, label:String="Page ${page+1}"):LinearLayout {
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setBackgroundColor(cardColor);setPadding(dp(7),dp(2),dp(7),dp(4))}
        val olderLabel=if(canOlder) "↑  Older" else ""
        row.addView(text(olderLabel,13f,green,true).apply{gravity=Gravity.CENTER;setOnClickListener{if(canOlder)older()}},LinearLayout.LayoutParams(0,dp(42),1f))
        row.addView(text(label,12f,Color.DKGRAY).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(0,dp(42),1f))
        row.addView(text(if(page>0)"Newer  ↓" else "",13f,green,true).apply{gravity=Gravity.CENTER;setOnClickListener{if(page>0)newer()}},LinearLayout.LayoutParams(0,dp(42),1f))
        return row
    }
    private fun screen(title:String, subtitle:String="", back:Boolean=false, backToChat:Boolean=false):LinearLayout {
        root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(pageColor)}
        setContentView(root)
        window.statusBarColor=if(darkMode)Color.BLACK else green
        window.navigationBarColor=if(darkMode)Color.BLACK else Color.BLACK
        val bar=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(12),dp(16),dp(12));setBackgroundColor(if(darkMode)Color.BLACK else green)}
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        if(back) row.addView(TextView(this).apply {
            text="←";textSize=24f;gravity=Gravity.CENTER;setTextColor(Color.WHITE)
            contentDescription="Back";setOnClickListener{navigateBack()}
        },LinearLayout.LayoutParams(dp(30),dp(36)).apply { rightMargin=dp(6) })
        val logo=ImageView(this).apply {
            setImageResource(com.example.chatarchive.R.mipmap.ic_launcher)
            scaleType=ImageView.ScaleType.CENTER_CROP
            background=GradientDrawable().apply { shape=GradientDrawable.OVAL }
            clipToOutline=true
            contentDescription="Tangled logo"
        }
        row.addView(logo,LinearLayout.LayoutParams(dp(40),dp(40)).apply { rightMargin=dp(10) })
        row.addView(text(title,23f,Color.WHITE,true),LinearLayout.LayoutParams(0,dp(52),1f))
        bar.addView(row)
        if(subtitle.isNotBlank())bar.addView(text(subtitle,12f,Color.WHITE))
        root.addView(bar)
        currentScreen = when(title) {
            "Tangled" -> "home"
            "Chat Stats" -> "stats"
            "Auto Sync" -> "autoSync"
            "Quoted Message Sync" -> "quotedSync"
            "Quotes & Reactions" -> "quotedSync"
            "Reply import results" -> "replyResults"
            else -> if(chatId != null) "chatSub" else "home"
        }
        return root
    }
    private fun navigateBack() {
        if(!authenticated) {
            if(!showingUnlock)unlock()
            return
        }
        when(currentScreen) {
            "home" -> moveTaskToBack(true)
            "chat" -> showHome()
            "vault" -> showAutoSync()
            "autoSync" -> if(autoSyncReturnToChat && chatId!=null) showChat(previousChatQuery,previousChatPage) else showHome()
            "stats", "quotedSync", "replyResults", "chatSub" -> if(chatId!=null) showChat(previousChatQuery,previousChatPage) else showHome()
            else -> if(chatId!=null) showChat(previousChatQuery,previousChatPage) else showHome()
        }
    }
    private fun scroller(parent:LinearLayout):LinearLayout {
        val scroll=ScrollView(this).apply{isFillViewport=true}
        val body=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(10),dp(12),dp(20))}
        scroll.addView(body);parent.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        return body
    }
    private fun showHome() {
        statsVisible=false
        chatId=null
        selectingReply=false;pendingReply=null
        val parent=screen("Tangled","Private, offline WhatsApp export archive")
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(8),dp(4),dp(8),dp(4))}
        actions.addView(button("Import chat") {chooseImport()},LinearLayout.LayoutParams(0,-2,1f))
        actions.addView(button("Complete backup") {createBackup()},LinearLayout.LayoutParams(0,-2,1f))
        actions.addView(button("Restore backup") {confirmRestore()},LinearLayout.LayoutParams(0,-2,1f))
        parent.addView(actions)
        if(mergeSelection.isNotEmpty()) {
            val mergeRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(8),dp(6),dp(8),dp(6))}
            mergeRow.addView(text("${mergeSelection.size} selected",15f,green,true),LinearLayout.LayoutParams(0,-2,1f))
            if(mergeSelection.size>=2)mergeRow.addView(button("Merge selected") {promptMergeSelected()})
            mergeRow.addView(button("Cancel") {mergeSelection.clear();showHome()})
            parent.addView(mergeRow)
        }
        val list=scroller(parent)
        val chats=db.chats()
        if(chats.isEmpty()) {
            list.addView(text("No conversations yet. Export a WhatsApp conversation (with or without media), then tap Import chat.",16f,Color.DKGRAY))
        }
        for(chat in chats){
            val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(12),dp(16),dp(12));background=outlinedBg(Color.WHITE,Color.argb(45,0,0,0),14);elevation=0f}
            card.addView(text(chat.name,19f,Color.BLACK,true))
            card.addView(text("${chat.count} messages  ·  ${if(chat.lastTime>0) dateFormat.format(Date(chat.lastTime)) else "Empty"}",13f,Color.DKGRAY))
            if(chat.id in mergeSelection) card.background=outlinedBg(Color.argb(35,0,130,100),green,14)
            card.setOnLongClickListener {
                if(db.isMergedChat(chat.id)) {
                    // A merged chat cannot be used as a source for another live merge.
                    AlertDialog.Builder(this).setTitle(chat.name)
                        .setItems(arrayOf("Delete chat", "Show source chats")){_,choice->
                            if(choice==0)confirmDeleteChat(chat)
                            else alert(db.mergedSourceNames(chat.id).joinToString("\n"))
                        }.show()
                } else {
                    AlertDialog.Builder(this).setTitle(chat.name)
                        .setItems(arrayOf("Delete chat", "Merge with another")){_,choice->
                            when(choice) {
                                0 -> confirmDeleteChat(chat)
                                1 -> { mergeSelection.clear(); mergeSelection.add(chat.id); showHome() }
                            }
                        }.show()
                }
                true
            }
            card.setOnClickListener{
                if(mergeSelection.isNotEmpty()) {
                    if(!db.isMergedChat(chat.id)) {
                        if(!mergeSelection.add(chat.id))mergeSelection.remove(chat.id)
                    }else Toast.makeText(this,"Choose original chats to merge",Toast.LENGTH_SHORT).show()
                    showHome()
                } else {chatId=chat.id;chatName=chat.name;selectSender(chat.id);showChat()}
            }
            list.addView(card,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(10)})
        }
        list.addView(text("Your archive is stored in the app's private storage. Make backups regularly: uninstalling or clearing app data can erase it.",12f,Color.DKGRAY))
        // Persistent bottom settings row, underneath the scrollable conversation list.
        val settingsRow=LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL
            setPadding(dp(8),dp(5),dp(8),dp(8))
        }
        settingsRow.addView(button("Auto Sync") {showAutoSync()},LinearLayout.LayoutParams(0,-2,1f).apply{rightMargin=dp(4)})
        settingsRow.addView(button("Settings") {showSettings()},LinearLayout.LayoutParams(0,-2,1f).apply{leftMargin=dp(4)})
        parent.addView(settingsRow)
    }
    private fun confirmDeleteChat(chat:Chat) {
        val associated=runCatching {autoSync.associatedCurrentZips(chat.id)}.getOrDefault(emptyList())
        val names=if(associated.isEmpty())"No linked source ZIPs currently in the private vault." else
            "${associated.size} associated private source ZIP(s)."
        val choices=arrayOf("Delete chat only (private ZIPs stay)",
            "Delete chat and unlink private ZIPs", "Delete chat and permanently delete private ZIPs")
        AlertDialog.Builder(this).setTitle("Delete ${chat.name}?")
            .setMessage("$names\n\nSaved scanner JSON files will not be deleted. Back up the conversation first.")
            .setSingleChoiceItems(choices,1){_,_->}
            .setNegativeButton("Cancel",null)
            .setPositiveButton("Continue",null).create().also{dialog->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val selected=dialog.listView.checkedItemPosition.let{if(it in 0..2)it else 1}
                        dialog.dismiss()
                        val action=when(selected){0->"Keep source ZIPs";1->"Unlink source ZIPs in the private vault";else->"Permanently delete private source ZIPs"}
                        AlertDialog.Builder(this).setTitle("Confirm chat deletion")
                            .setMessage("$action and delete ${chat.name}?\n\nThis cannot be undone without a backup." )
                            .setNegativeButton("Cancel",null)
                            .setPositiveButton("Delete"){_,_->
                                try {
                                    if(selected!=0)autoSync.handleChatDeleteZips(chat.id,selected==1)
                                    val removed=db.deleteChat(chat.id)
                                    for(name in removed)io.mediaFile(name)?.delete()
                                    mergeSelection.remove(chat.id);showHome()
                                }catch(e:Exception){alert("Deletion stopped: ${e.message}. Check private source files before trying again.")}
                            }.show()
                    }
                }
                dialog.show()
            }
    }
    private fun promptMergeSelected() {
        val ids=mergeSelection.toList()
        if(ids.size<2)return
        val input=EditText(this).apply{setSingleLine(true);setText("Merged conversation");selectAll()}
        AlertDialog.Builder(this).setTitle("Create a live merged chat")
            .setMessage("Combine ${ids.size} chats in timestamp order. Originals stay unchanged. New messages imported or auto-synced into either original will also appear in the merged chat.")
            .setView(input).setNegativeButton("Cancel",null).setPositiveButton("Merge"){_,_->
                try {
                    val mergedId=db.createLiveMergedChat(input.text.toString(),ids)
                    mergeSelection.clear()
                    val merged=db.chats().first{it.id==mergedId}
                    chatId=merged.id;chatName=merged.name;selectSender(merged.id);showChat()
                }catch(e:Exception){alert("Merge could not complete: ${e.message}")}
            }.show()
    }
    private fun manageNames(id: Long, query: String, page: Int, directChoice: Int? = null) {
        val participants=db.participants(id)
        if(participants.isEmpty()) {alert("No participants found");return}
        val options=arrayOf("Rename a participant", "Match two sender names", "Restore original display names", "Remove all identity matches")
        val executeChoice: (Int)->Unit = { choice ->
            when(choice) {
                0 -> AlertDialog.Builder(this).setTitle("Choose participant")
                    .setItems(participants.map { "${db.displaySender(id,it)}  (original: $it)" }.toTypedArray()) { _,idx ->
                        val source=participants[idx]
                        val field=EditText(this).apply {setSingleLine(true);setText(db.displaySender(id,source));selectAll()}
                        AlertDialog.Builder(this).setTitle("Display name for $source").setView(field)
                            .setNegativeButton("Cancel",null).setPositiveButton("Save") { _,_->
                                if(field.text.toString().isNotBlank()){db.renameIdentity(id,source,field.text.toString());showChat(query,page)}
                            }.show()
                    }.show()
                1 -> AlertDialog.Builder(this).setTitle("Name used in the newer export")
                    .setItems(participants.toTypedArray()) { _,aliasIdx ->
                        val alias=participants[aliasIdx]
                        val possible=participants.filter {it!=alias && db.senderIdentity(id,it)!=alias}
                        AlertDialog.Builder(this).setTitle("Same person as which original name?")
                            .setItems(possible.toTypedArray()) { _,primaryIdx ->
                                val primary=possible[primaryIdx]
                                AlertDialog.Builder(this).setTitle("Confirm identity match")
                                    .setMessage("Treat '$alias' and '$primary' as the SAME person for display and future imports? Check carefully: this cannot identify people automatically.")
                                    .setNegativeButton("Cancel",null).setPositiveButton("Match") { _,_->
                                        db.connectSender(id,alias,primary);showChat(query,page)
                                    }.show()
                            }.show()
                    }.show()
                2 -> AlertDialog.Builder(this).setMessage("Restore original display names?")
                    .setNegativeButton("Cancel",null).setPositiveButton("Restore") { _,_->db.resetNames(id);showChat(query,page)}.show()
                3 -> AlertDialog.Builder(this).setMessage("Remove all sender identity matches for this chat? Names saved in original messages are preserved.")
                    .setNegativeButton("Cancel",null).setPositiveButton("Reset") { _,_->db.resetAliases(id);showChat(query,page)}.show()
            }
        }
        if(directChoice != null) executeChoice(directChoice)
        else AlertDialog.Builder(this).setTitle("Names & identities").setItems(options) { _, choice -> executeChoice(choice) }.show()
    }

    private fun manageReplyLink(id:Long, reply:Message, query:String, page:Int) {
        val current=db.replyStatus(id,reply)
        val options=arrayOf("Confirm link ✓", "Change linked message", "Remove this link")
        AlertDialog.Builder(this).setTitle(if(current=="uncertain") "Uncertain quoted message link" else "Manage reply link")
            .setItems(options){_,which->when(which){
                0 -> {db.updateReplyStatus(id,reply,"confirmed");showChat(query,page)}
                1 -> {pendingReply=reply; selectingReply=false;showChat(query,page);alert("Navigate to the correct original message and tap its bubble to change the link.")}
                2 -> AlertDialog.Builder(this).setTitle("Remove quoted message link?").setMessage("This will not remove either message.")
                    .setNegativeButton("Cancel",null).setPositiveButton("Remove"){_,_->db.removeReplyLink(id,reply);showChat(query,page)}.show()
            }}.show()
    }
    private fun manageAllReplyLinks(id:Long,query:String,page:Int) {
        AlertDialog.Builder(this).setTitle("Manage quoted messages (${db.countReplyLinks(id)})")
            .setItems(arrayOf("Remove all uncertain links", "Remove all imported links", "Remove all reply links")){_,which->
                val mode=listOf("uncertain","imported","all")[which]
                AlertDialog.Builder(this).setTitle("Remove ${listOf("uncertain","imported","all")[which]} reply links?")
                    .setMessage("This removes reply links, not messages. Removing ALL links also resets historical and new-message scan checkpoints so the next scan starts fresh. Make a backup first.")
                    .setNegativeButton("Cancel",null).setPositiveButton("Remove"){_,_->db.removeReplyLinks(id,mode);if(mode=="all")db.clearScanState(id);showChat(query,page)}.show()
            }.show()
    }
    // Search navigation uses the same newest-first ordering and 300-result pages as the chat.
    // Only one result is retrieved for a jump; never materialise the entire conversation.
    private fun navigateSearchMatch(query:String,index:Int) {
        val id=chatId ?: return
        val count=db.searchMatchCount(id,query)
        if(count==0) {searchSelectionQuery=query;searchSelectionIndex=0;showChat(query,0);return}
        val target=index.coerceIn(0,count-1)
        val page=target/300
        val message=db.messagesPage(id,query,page,300).getOrNull(target%300)
        searchSelectionQuery=query
        searchSelectionIndex=target
        showChat(query,page,message?.let{"${it.fingerprint}:${it.occurrence}"})
    }
    private fun showChat(query:String="", page:Int=0, focusKey:String?=null, startAtTop:Boolean=false, anchorOffset:Int?=null, focusAtTop:Boolean=false) {
        val id=chatId ?: return showHome()
        statsVisible=false
        previousChatQuery=query
        previousChatPage=page
        val parent=screen(chatName,"",true)
        currentScreen="chat"
        // Search stays collapsed unless opened from the header magnifying glass.
        val header=parent.getChildAt(0) as LinearLayout
        header.setPadding(dp(10),dp(3),dp(10),dp(3))
        val headerRow=header.getChildAt(0) as LinearLayout
        val findIcon=miniIcon("⌕","Expand search") {searchExpanded=true;showChat(query,page)}
        findIcon.setTextColor(Color.WHITE)
        findIcon.background=null
        headerRow.addView(findIcon,LinearLayout.LayoutParams(dp(40),dp(42)))
        val controls=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(8),dp(2),dp(8),dp(2))}
        val search=EditText(this).apply{hint="Search this conversation";setSingleLine(true);setText(query)}
        controls.addView(search,LinearLayout.LayoutParams(0,-2,1f))
        controls.addView(button("Find") {
            val term=search.text.toString().trim()
            searchSelectionQuery=term
            searchSelectionIndex=0
            if(term.isEmpty()) showChat("",0) else navigateSearchMatch(term,0)
        })
        controls.addView(miniIcon("×","Collapse search") {searchExpanded=false;searchSelectionQuery="";searchSelectionIndex=0;showChat("",0)},LinearLayout.LayoutParams(dp(42),dp(48)))
        if(searchExpanded || query.isNotBlank())parent.addView(controls)
        if(query.isNotBlank()) {
            if(searchSelectionQuery!=query) {searchSelectionQuery=query;searchSelectionIndex=0}
            val count=db.searchMatchCount(id,query)
            searchSelectionIndex=searchSelectionIndex.coerceIn(0,(count-1).coerceAtLeast(0))
            val searchNav=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(5),dp(2),dp(5),dp(2))}
            fun addSearchNav(label:String,enabled:Boolean,index:Int) {
                val view=button(label) { if(enabled) navigateSearchMatch(query,index) }
                view.isEnabled=enabled
                view.alpha=if(enabled)1f else 0.45f
                searchNav.addView(view,LinearLayout.LayoutParams(0,dp(43),1f).apply{marginEnd=dp(3)})
            }
            addSearchNav("Oldest",count>0 && searchSelectionIndex<count-1,count-1)
            addSearchNav("‹ Older",count>0 && searchSelectionIndex<count-1,searchSelectionIndex+1)
            addSearchNav("Newer ›",searchSelectionIndex>0,searchSelectionIndex-1)
            addSearchNav("Newest",searchSelectionIndex>0,0)
            parent.addView(searchNav)
            parent.addView(text(if(count==0) "No matches" else "Match ${searchSelectionIndex+1} of $count · newest first",12f,Color.DKGRAY).apply{gravity=Gravity.CENTER})
        }
        chatTabs(parent,"Messages")
        val selected=linkedMapOf<String,Message>()
        val pageSize=300
        val continuous=continuousScrollEnabled() && query.isBlank()
        // Four pages max; advancing this window does not accumulate an unbounded number of views.
        val newestWindowPage=if(continuous)(page-3).coerceAtLeast(0) else page
        val windowSize=if(continuous && page==0 && focusKey==null) 150 else if(continuous)(page-newestWindowPage+1)*pageSize else pageSize
        val all=db.messagesWindow(id,query,newestWindowPage*pageSize,windowSize)
        // Show the date of the bottommost VISIBLE message, updating while scrolling.
        // This is a viewport indicator, not the date of the newest message in the page.
        val viewportDateFormat=SimpleDateFormat("d MMM yyyy",Locale.UK)
        val initialDate=all.firstOrNull()?.let { viewportDateFormat.format(Date(it.time)) } ?: "No messages"
        val navigation=pageNavigation(page,all.size==windowSize,{showChat(query,page+1)},{showChat(query,page-1,startAtTop=true)},initialDate)
        // Reuse the exact existing three-control navigation row in both modes.
        // In continuous mode the outer controls refer to adjacent calendar months.
        parent.addView(navigation)
        val dateIndicator=navigation.getChildAt(1) as TextView
        val previousMonthButton=navigation.getChildAt(0) as TextView
        val nextMonthButton=navigation.getChildAt(2) as TextView
        var visibleMonthTime=all.firstOrNull()?.time ?: System.currentTimeMillis()
        fun monthStart(timestamp:Long,delta:Int):Calendar = Calendar.getInstance().apply {
            timeInMillis=timestamp
            set(Calendar.DAY_OF_MONTH,1)
            set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)
            add(Calendar.MONTH,delta)
        }
        fun jumpOneMonth(delta:Int) {
            val start=monthStart(visibleMonthTime,delta)
            val end=start.clone() as Calendar
            end.add(Calendar.MONTH,1)
            val target=db.firstMessageInMonth(id,start.timeInMillis,end.timeInMillis)
            if(target==null) {
                Toast.makeText(this,"No messages in ${SimpleDateFormat("MMMM yyyy",Locale.UK).format(start.time)}",Toast.LENGTH_SHORT).show()
            } else {
                val targetPage=db.pageForMessage(id,target) ?: 0
                showChat("",targetPage,"${target.fingerprint}:${target.occurrence}",focusAtTop=true)
            }
        }
        fun updateMonthControls(time:Long) {
            if(!continuous) return
            visibleMonthTime=time
            val labelFormat=SimpleDateFormat("MMM",Locale.UK)
            previousMonthButton.text="↑  ${labelFormat.format(monthStart(time,-1).time)}"
            nextMonthButton.text="${labelFormat.format(monthStart(time,1).time)}  ↓"
            previousMonthButton.contentDescription="Jump to earliest message in previous month"
            nextMonthButton.contentDescription="Jump to earliest message in next month"
        }
        if(continuous) {
            previousMonthButton.setOnClickListener { jumpOneMonth(-1) }
            nextMonthButton.setOnClickListener { jumpOneMonth(1) }
            updateMonthControls(visibleMonthTime)
        }
        dateIndicator.setOnClickListener {selectChatDate(id,query)}
        dateIndicator.contentDescription="Jump to date"
        val list=scroller(parent)
        val messagePositions=ArrayList<Pair<View,Long>>(all.size)
        if(selectingReply || pendingReply != null) {
            val label=if(selectingReply) "Tap the message that contains the reply" else "Tap the original message to link · use Older/Newer to find it"
            list.addView(text(label,14f,green,true))
            list.addView(button("Cancel linking") {selectingReply=false;pendingReply=null;showChat(query,page)})
        }
        if(all.isEmpty())list.addView(text("No messages found."))
        var previousDay=""
        // After any sender identity merges, only label bubbles for group chats.
        val namedParticipants=db.participants(id).map{db.senderIdentity(id,it)}.distinct().size
        val showSenderNames=namedParticipants>2
        val reactionLookup=db.reactionsByMessage(id)
        val selfDisplay=getSharedPreferences("tangled_user",MODE_PRIVATE).getString("your_name","You").orEmpty().ifBlank { "You" }
        // Keep the newest page first, but display each page chronologically: oldest at the top, newest at the bottom.
        for(m in all.asReversed()) {
            val day=dayFormat.format(Date(m.time))
            if(day!=previousDay){
                val divider=text(day,12f,Color.DKGRAY).apply{gravity=Gravity.CENTER}
                list.addView(divider,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(12);bottomMargin=dp(8)})
                previousDay=day
            }
            val mine=mySender.isNotBlank() && db.senderIdentity(id,m.sender)==db.senderIdentity(id,mySender)
            val bubble=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(9),dp(5),dp(9),dp(5));background=outlinedBg(if(mine)Color.rgb(216,248,202) else Color.WHITE, if(mine) Color.rgb(156,190,140) else Color.argb(55,0,0,0), 14);elevation=0f}
            if(showSenderNames)bubble.addView(text(db.displaySender(id,m.sender),12f,green,true).apply{setPadding(0,0,0,dp(2))})
            db.replyTarget(id,m)?.let {original ->
                val quote=LinearLayout(this).apply {
                    orientation=LinearLayout.VERTICAL
                    background=outlinedBg(Color.rgb(236,244,239),Color.rgb(123,166,151),9)
                    setPadding(dp(9),dp(5),dp(9),dp(5))
                }
                val quoteHead=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                quoteHead.addView(text("↩  " + db.displaySender(id,original.sender),12f,green,true),LinearLayout.LayoutParams(0,-2,1f))
                val status=db.replyStatus(id,m)
                val symbol=when(status){"uncertain" -> "?";"confirmed" -> "✓";else -> "✓"}
                val badge=text(symbol,15f,if(status=="uncertain") Color.rgb(171,108,0) else green,true).apply {
                    contentDescription=if(status=="uncertain") "Uncertain quoted message link, tap to manage" else "Quoted message, tap to manage"
                    setPadding(dp(12),dp(3),dp(12),dp(3))
                    setOnClickListener { manageReplyLink(id,m,query,page) }
                }
                quoteHead.addView(badge)
                quote.addView(quoteHead)
                quote.addView(text(original.body.replace('\n',' ').take(130),12f,Color.DKGRAY))
                quote.setOnClickListener {jumpToMessage(original)}
                quote.setOnLongClickListener {manageReplyLink(id,m,query,page);true}
                bubble.addView(quote,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(5)})
            }
            // A trailing ReplacementSpan reserves a clock-sized slot in the
            // text's natural line wrapping, then paints the time flush-right.
            // This keeps short bubbles compact and moves the clock to a new
            // line only if it cannot fit after the final word (WhatsApp style).
            // Existing bold/italic body spans are preserved unchanged.
            val file=io.mediaFile(m.attachment)
            // Remove only standalone export placeholders/filenames, never actual captions.
            val rawCaption=m.body.trim()
            val attachmentName=m.attachment.orEmpty().substringAfterLast('/')
            val exportedName=WhatsAppParser.attachmentName(m.body)
            // The stored media filename can differ from the original filename
            // when a ZIP import renames conflicting files. Strip either marker.
            var withoutFilename=m.body
            if(file!=null) for(name in listOfNotNull(attachmentName.takeIf{it.isNotBlank()},exportedName).distinct()) {
                val marker=Regex("(?i)(?<![\\w.-])"+Regex.escape(name)+"(?:\\s*\\(file attached\\))?")
                withoutFilename=marker.replace(withoutFilename,"")
            }
            val displayBody=if(file!=null) withoutFilename
                .replace(Regex("(?im)^\\s*(?:<Media omitted>|(?:image|video|audio|voice message)(?: omitted)?)\\s*$"), "")
                .replace(Regex("(?m)^[ \t]*\\(file attached\\)[ \t]*$"), "")
                .trim() else m.body

            val content=SpannableStringBuilder(formattedMessage(displayBody))
            val messageText=text("",15f,bodyColor).apply {
                setPadding(0,0,0,0)
                setLineSpacing(0f,1.02f)
                includeFontPadding=false
            }
            if(file==null) {
                val timeStart=content.length
                content.append("  "+compactTimeFormat.format(Date(m.time)))
                val stamp=compactTimeFormat.format(Date(m.time))
                val stampColor=if(darkMode)Color.LTGRAY else Color.DKGRAY
                content.setSpan(object:ReplacementSpan() {
                    override fun getSize(paint:Paint, cs:CharSequence, start:Int, end:Int,
                                         fm:Paint.FontMetricsInt?):Int {
                        return (paint.measureText(stamp)*0.73f+dp(9)).toInt()
                    }
                    override fun draw(canvas:Canvas, cs:CharSequence, start:Int, end:Int,
                                      x:Float, top:Int, y:Int, bottom:Int, paint:Paint) {
                        val oldColor=paint.color
                        val oldSize=paint.textSize
                        paint.textSize=oldSize*0.73f
                        paint.color=stampColor
                        val width=paint.measureText(stamp)
                        val right=messageText.width-messageText.paddingRight.toFloat()
                        canvas.drawText(stamp,maxOf(x+dp(4),right-width),y.toFloat(),paint)
                        paint.color=oldColor
                        paint.textSize=oldSize
                    }
                },timeStart,content.length,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            if(content.isNotEmpty()) {
                messageText.text=content
                bubble.addView(messageText)
            }
            if(file != null) {
                if(file.extension.lowercase(Locale.ROOT) in setOf("jpg","jpeg","png","webp","gif")) {
                    try {
                        val opts=android.graphics.BitmapFactory.Options().apply{inJustDecodeBounds=true}
                        BitmapFactory.decodeFile(file.path,opts)
                        opts.inSampleSize=maxOf(1,maxOf(opts.outWidth/480,opts.outHeight/480)); opts.inJustDecodeBounds=false
                        val bitmap=BitmapFactory.decodeFile(file.path,opts)
                        if(bitmap!=null) {
                            val image=ImageView(this).apply{setImageBitmap(bitmap);adjustViewBounds=true;maxHeight=dp(228);minimumWidth=dp(226);background=bg(Color.TRANSPARENT,12);clipToOutline=true}
                            bubble.addView(image,LinearLayout.LayoutParams(-1,-2))
                            image.setOnClickListener { showImage(file) }
                        }
                    } catch(_:Exception) { bubble.addView(text("Attachment: ${file.name}",12f)) }
                } else if(file.extension.lowercase(Locale.ROOT) in setOf("mp4","3gp","webm","mov")) {
                    val preview=android.widget.FrameLayout(this).apply{background=bg(Color.TRANSPARENT,12);clipToOutline=true}
                    val image=ImageView(this).apply{scaleType=ImageView.ScaleType.CENTER_CROP}
                    try {
                        @Suppress("DEPRECATION")
                        val thumbnail=ThumbnailUtils.createVideoThumbnail(file.absolutePath,MediaStore.Video.Thumbnails.MINI_KIND)
                        if(thumbnail!=null)image.setImageBitmap(thumbnail) else image.setBackgroundColor(Color.DKGRAY)
                    }catch(_:Exception){image.setBackgroundColor(Color.DKGRAY)}
                    preview.addView(image,android.widget.FrameLayout.LayoutParams(dp(225),dp(140)))
                    preview.addView(text("▶",30f,Color.WHITE,true).apply{gravity=Gravity.CENTER},android.widget.FrameLayout.LayoutParams(dp(225),dp(140)))
                    bubble.addView(preview)
                    preview.setOnClickListener{openAttachment(file)}
                } else if(file.extension.lowercase(Locale.ROOT) in setOf("mp3","m4a","aac","ogg","opus","wav","amr")) {
                    addInlineVoicePlayer(bubble,file,mine)
                } else bubble.addView(text("▶  Open attachment",14f,green).apply {
                    setPadding(dp(8),dp(6),dp(8),dp(6))
                    setOnClickListener { openAttachment(file) }
                })
                // Media retains a small trailing clock, below the thumbnail/player.
                bubble.addView(text(compactTimeFormat.format(Date(m.time)),10.5f,if(darkMode)Color.LTGRAY else Color.DKGRAY).apply{
                    gravity=Gravity.END
                    setPadding(0,dp(1),0,0)
                })
            }
            // Bare attachments sit edge-to-edge rather than inside a large text bubble.
            val mediaOnly = file != null && displayBody.isBlank()
            if(mediaOnly) {
                bubble.setPadding(dp(1),dp(1),dp(1),dp(1))
                bubble.background=bg(Color.TRANSPARENT,14)
            }
            // Select messages for a labelled bookmark: long-press to begin, tap to add/remove.
            val selectionKey="${m.fingerprint}:${m.occurrence}"
            fun updateSelectedAppearance() {
                val isSelected=selected.containsKey(selectionKey)
                bubble.background=if(!isSelected && mediaOnly) bg(Color.TRANSPARENT,14) else outlinedBg(if(isSelected) Color.rgb(255,236,179) else if(mine) Color.rgb(216,248,202) else Color.WHITE, if(isSelected) Color.rgb(214,167,54) else if(mine) Color.rgb(156,190,140) else Color.argb(55,0,0,0), 14)
            }
            bubble.setOnLongClickListener {
                if(db.replyTarget(id,m)!=null && pendingReply==null && !selectingReply && selected.isEmpty()) {
                    AlertDialog.Builder(this).setTitle("Message options")
                        .setItems(arrayOf("Select for bookmark", "Remove quoted message link")) {_, option ->
                            if(option==0) {selected[selectionKey]=m;updateSelectedAppearance()}
                            else {db.removeReplyLink(id,m);showChat(query,page)}
                        }.show()
                } else if(selected.containsKey(selectionKey)) {
                    val field=EditText(this).apply{hint="Bookmark label";setSingleLine(true)}
                    AlertDialog.Builder(this).setTitle("Bookmark ${selected.size} selected message(s)")
                        .setView(field).setNegativeButton("Cancel",null)
                        .setPositiveButton("Save") { _,_->
                            val label=field.text.toString().trim()
                            if(label.isBlank())alert("Enter a bookmark label")
                            else {db.saveBookmark(id,label,selected.values.toList());showBookmarks()}
                        }.show()
                } else {
                    selected[selectionKey]=m
                    updateSelectedAppearance()
                    android.widget.Toast.makeText(this,"Tap other messages to select; long-press the selected message again to bookmark",android.widget.Toast.LENGTH_LONG).show()
                }
                true
            }
            bubble.setOnClickListener {
                if(selectingReply) {
                    pendingReply=m;selectingReply=false;showChat(query,page)
                } else if(pendingReply!=null) {
                    val reply=pendingReply!!
                    if(reply.fingerprint==m.fingerprint && reply.occurrence==m.occurrence) alert("Choose a different original message.")
                    else AlertDialog.Builder(this).setTitle("Link reply?")
                        .setMessage("Show this message as the quoted original above the selected reply?")
                        .setNegativeButton("Cancel",null).setPositiveButton("Link") {_,_->
                            db.setReplyLink(id,reply,m);db.updateReplyStatus(id,reply,"confirmed");pendingReply=null;jumpToMessage(reply)
                        }.show()
                } else if(selected.isNotEmpty()) {
                    if(selected.containsKey(selectionKey)) selected.remove(selectionKey) else selected[selectionKey]=m
                    updateSelectedAppearance()
                }
            }

            // Leave a genuine gutter on the opposite side of every bubble.
            // LinearLayout measures wrap-content bubbles within the remaining
            // ~80% of the screen, so small messages are not stretched.
            val sideGutter=(resources.displayMetrics.widthPixels*0.20f).toInt()
            val wrap=LinearLayout(this).apply{
                gravity=if(mine)Gravity.END else Gravity.START
                setPadding(if(mine)sideGutter else 0,0,if(mine)0 else sideGutter,0)
            }
            // Overlay the reaction badge on the lower outside edge of its message,
            // matching WhatsApp: left for incoming, right for outgoing messages.
            val messageFrame=FrameLayout(this).apply { clipChildren=false;clipToPadding=false }
            val reactionsForMessage=reactionLookup[selectionKey].orEmpty().distinct()
            val hasReactions=reactionsForMessage.isNotEmpty()
            messageFrame.addView(bubble,FrameLayout.LayoutParams(-2,-2).apply {
                if(hasReactions) bottomMargin=dp(24)
            })
            if(hasReactions) {
                val grouped=reactionsForMessage.groupBy { it.second }
                val caption=grouped.entries.joinToString("  ") { (emoji, people) ->
                    if(people.size==1) emoji else "$emoji ${people.size}"
                }
                val chip=text(caption,13f,Color.rgb(56,67,65),true).apply {
                    gravity=Gravity.CENTER
                    setPadding(dp(9),dp(3),dp(9),dp(3))
                    background=outlinedBg(Color.WHITE,Color.rgb(200,207,205),18)
                    elevation=dp(2).toFloat()
                    contentDescription="View who reacted"
                    setOnClickListener {
                        val names=reactionsForMessage.joinToString("\n") { (actor,emoji) ->
                            val display=if(actor=="self")selfDisplay else actor
                            "$emoji  $display"
                        }
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle("Reactions")
                            .setMessage(names)
                            .setPositiveButton("Close",null)
                            .show()
                    }
                }
                // Keep the entire reaction chip below the text and timestamp. Its
                // top edge just touches the lower edge of the message bubble.
                messageFrame.addView(chip,FrameLayout.LayoutParams(-2,dp(24),
                    Gravity.BOTTOM or (if(mine)Gravity.RIGHT else Gravity.LEFT)).apply {
                    if(mine) rightMargin=dp(7) else leftMargin=dp(7)
                })
            }
            wrap.addView(messageFrame,LinearLayout.LayoutParams(-2,-2))
            list.addView(wrap,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(if(hasReactions) 6 else 4)})
            messagePositions.add(wrap to m.time)
            if (focusKey == selectionKey) {
                bubble.background=outlinedBg(Color.rgb(255,236,179), Color.rgb(214,167,54), 14)
                // Scroll after layout so the saved message is visible even on older pages.
                wrap.post {
                    val scroll=list.parent as? ScrollView
                    if(anchorOffset!=null) scroll?.scrollTo(0,(wrap.top-anchorOffset).coerceAtLeast(0))
                    else if(focusAtTop) scroll?.scrollTo(0,wrap.top.coerceAtLeast(0))
                    else scroll?.smoothScrollTo(0,(wrap.top - dp(30)).coerceAtLeast(0))
                }
            }
        }
        // Track the bottommost message actually visible in the scroll viewport.
        // Message positions are in chronological screen order, allowing a fast
        // binary search rather than checking all 300 bubbles on every scroll event.
        (list.parent as? ScrollView)?.let { scroll ->
            var displayedDate=""
            fun updateViewportDate() {
                if(messagePositions.isEmpty()) return
                val viewportBottom=scroll.scrollY+scroll.height-scroll.paddingBottom
                var low=0
                var high=messagePositions.size-1
                var candidate=-1
                while(low<=high) {
                    val mid=(low+high) ushr 1
                    if(messagePositions[mid].first.top < viewportBottom) {
                        candidate=mid
                        low=mid+1
                    } else high=mid-1
                }
                if(candidate<0) candidate=0
                val visibleDate=viewportDateFormat.format(Date(messagePositions[candidate].second))
                if(visibleDate!=displayedDate) {
                    displayedDate=visibleDate
                    dateIndicator.text=visibleDate
                    updateMonthControls(messagePositions[candidate].second)
                }
            }
            var changingWindow=false
            var lastScrollY=-1
            // Start shifting before the viewer reaches either end.  The 100-message
            // prefetch margin is measured in messages, not pixels (bubble heights vary).
            // Rebuilds retain an anchored message and its pixel offset, so the screen
            // stays in the same place after the bounded 300-message window advances.
            scroll.setOnScrollChangeListener { _, _, scrollY, _, _ ->
                updateViewportDate()
                if(!continuous || changingWindow || scroll.height<=0 || messagePositions.isEmpty()) return@setOnScrollChangeListener
                val direction=when {
                    lastScrollY<0 -> 0
                    scrollY<lastScrollY -> -1
                    scrollY>lastScrollY -> 1
                    else -> 0
                }
                lastScrollY=scrollY
                if(direction==0) return@setOnScrollChangeListener

                val visibleTop=scrollY+dp(20)
                var low=0
                var high=messagePositions.size-1
                var firstVisible=messagePositions.size-1
                while(low<=high) {
                    val mid=(low+high) ushr 1
                    if(messagePositions[mid].first.bottom>visibleTop) {
                        firstVisible=mid
                        high=mid-1
                    } else low=mid+1
                }
                val prefetchMessages=minOf(100,maxOf(30,messagePositions.size/4))
                val approachingOlder=direction<0 && firstVisible<=prefetchMessages &&
                    all.size==windowSize && page<100000
                val approachingNewer=direction>0 && newestWindowPage>0 &&
                    firstVisible>=messagePositions.size-1-prefetchMessages
                if(approachingOlder || approachingNewer) {
                    changingWindow=true
                    val anchorView=messagePositions[firstVisible].first
                    val anchorMessage=all.asReversed().getOrNull(firstVisible)
                    val key=anchorMessage?.let {"${it.fingerprint}:${it.occurrence}"}
                    val offset=anchorView.top-scrollY
                    scroll.post {
                        showChat(query,if(approachingOlder)page+1 else page-1,key,anchorOffset=offset)
                    }
                }
            }
            // Covers the initial positioning and explicit bookmark jumps too.
            scroll.post { updateViewportDate() }
        }
        if(continuous && page>0) {
            val latest=button("↓  Return to latest") {showChat("",0)}
            parent.addView(latest)
        }
        parent.addView(chatActionFooter(id,query,page))
        // Open at the most recent (bottom) message of this page, except when jumping
        // to a bookmark, which scrolls directly to the highlighted message above.
        if (focusKey == null) {
            (list.parent as? ScrollView)?.let { scroll ->
                scroll.post {
                    if (startAtTop) scroll.scrollTo(0,0)
                    else scroll.scrollTo(0,scroll.getChildAt(0).height)
                }
            }
        }
    }
    private fun quotedMenu(id:Long,query:String,page:Int) {
        AlertDialog.Builder(this).setTitle("Quoted Messages")
            .setItems(arrayOf("Link messages manually","Quoted Message Sync","Manage all quoted messages")) {_,which->
                when(which) {0->{pendingReply=null;selectingReply=true;showChat(query,page)};1->replyExporterGuide();else->manageAllReplyLinks(id,query,page)}
            }.show()
    }
    // Purpose-drawn icons use the same 48-unit geometry in every toolbar cell.
    private fun footerIcon(kind:String):View = object:View(this) {
        private val ink=Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color=accentColor;strokeWidth=3.6f;strokeJoin=Paint.Join.ROUND;strokeCap=Paint.Cap.ROUND
        }
        override fun onDraw(c:Canvas) {
            super.onDraw(c)
            c.save()
            val scale=minOf(width,height)/48f
            c.translate((width-48f*scale)/2f,(height-48f*scale)/2f)
            c.scale(scale,scale)
            ink.color=accentColor
            when(kind){
                "edit" -> {
                    ink.style=Paint.Style.STROKE
                    val path=android.graphics.Path().apply {moveTo(10f,34f);lineTo(31f,13f);lineTo(37f,19f);lineTo(16f,40f);lineTo(9f,41f);close()}
                    c.drawPath(path,ink)
                    c.drawLine(27f,17f,33f,23f,ink)
                }
                "sync" -> {
                    ink.style=Paint.Style.STROKE
                    ink.strokeWidth=4f
                    // Circular double-arrow sync glyph, with arrowheads on the arc ends.
                    c.drawArc(8f,8f,40f,40f,200f,145f,false,ink)
                    c.drawArc(8f,8f,40f,40f,20f,145f,false,ink)
                    // End of upper arc (at roughly 39,20): clockwise arrowhead.
                    c.drawLine(39.5f,19.9f,39.8f,10.1f,ink)
                    c.drawLine(39.5f,19.9f,30.2f,17.2f,ink)
                    // End of lower arc (at roughly 8.5,28): clockwise arrowhead.
                    c.drawLine(8.5f,28.1f,8.2f,37.9f,ink)
                    c.drawLine(8.5f,28.1f,17.8f,30.8f,ink)
                }
                "stats" -> {
                    ink.style=Paint.Style.STROKE
                    ink.strokeWidth=3.8f
                    // Four outlined bars of varied heights: clearly a chart,
                    // not three rising mobile-signal-strength bars.
                    c.drawRoundRect(5f,24f,12f,41f,1.8f,1.8f,ink)
                    c.drawRoundRect(16f,11f,23f,41f,1.8f,1.8f,ink)
                    c.drawRoundRect(27f,20f,34f,41f,1.8f,1.8f,ink)
                    c.drawRoundRect(38f,6f,45f,41f,1.8f,1.8f,ink)
                }
                "import" -> {
                    ink.style=Paint.Style.STROKE
                    c.drawLine(24f,6f,24f,30f,ink)
                    c.drawLine(13f,20f,24f,31f,ink)
                    c.drawLine(35f,20f,24f,31f,ink)
                    c.drawLine(8f,39f,40f,39f,ink)
                }
            }
            c.restore()
        }
    }
    private fun syncImportMenu() {
        AlertDialog.Builder(this).setTitle("Sync & Import")
            .setItems(arrayOf("Import More","Sync Now","Quotes & Reactions")) { _, which ->
                when(which) {
                    0 -> importMoreMenu()
                    1 -> startAutoSync(true)
                    2 -> replyExporterGuide()
                }
            }.show()
    }
    private fun chatActionFooter(id:Long,query:String="",page:Int=0):LinearLayout {
        val footer=LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER
            setPadding(dp(6),dp(2),dp(6),dp(2));setBackgroundColor(cardColor)
        }
        fun action(kind:String,label:String,run:()->Unit) {
            val tile=LinearLayout(this).apply {
                orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER
                background=outlinedBg(if(darkMode)cardColor else Color.WHITE,Color.argb(80,7,94,84),12)
                contentDescription=label
                isFocusable=true
                setOnClickListener{run()}
            }
            tile.addView(footerIcon(kind),LinearLayout.LayoutParams(dp(25),dp(25)))
            footer.addView(tile,LinearLayout.LayoutParams(0,dp(42),1f).apply{setMargins(dp(3),0,dp(3),0)})
        }
        action("edit","Chat Edits"){renameMenu(id,query,page)}
        action("sync","Sync & Import"){syncImportMenu()}
        action("stats","Chat Stats"){showChatStats()}
        return footer
    }
    private fun showChatStats() {
        val id=chatId ?: return showHome()
        statsVisible=true
        val parent=screen("Chat Stats","",true,backToChat=true)
        val body=scroller(parent)
        // Same four icon drawings, order and labels as the conversation.
        parent.addView(chatActionFooter(id,previousChatQuery,previousChatPage))
        body.addView(text("Preparing your chat highlights…",18f,green,true))
        // Keep SQLite scans and any cache rebuild off the Android UI thread.
        thread {
            try {
                val result=db.cachedChatStats(id)
                runOnUiThread {
                    if(isFinishing || chatId!=id || body.parent==null)return@runOnUiThread
                    body.removeAllViews()
                    renderChatStats(body,result.first,result.second,result.third)
                }
            }catch(e:Exception){runOnUiThread{if(body.parent!=null){body.removeAllViews();body.addView(text("Couldn't load statistics: ${e.message}"))}}}
        }
    }
    /** Live, sender-by-sender top-five gaps, with inclusive date and end-message
     * time-of-day filters. Underlying chronological neighbours are never filtered. */
    private fun renderLongestMessageGaps(body:LinearLayout,id:Long,first:Long?,last:Long?) {
        if(first==null || last==null){body.addView(text("No messages to analyse"));return}
        fun dayStart(t:Long)=Calendar.getInstance().apply{
            timeInMillis=t;set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0)
            set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)
        }.timeInMillis
        fun dayEnd(t:Long)=Calendar.getInstance().apply{
            timeInMillis=t;set(Calendar.HOUR_OF_DAY,23);set(Calendar.MINUTE,59)
            set(Calendar.SECOND,59);set(Calendar.MILLISECOND,999)
        }.timeInMillis
        val gapPrefs=getSharedPreferences("tangled_gap_filters",MODE_PRIVATE)
        val prefix="chat_${id}_"
        var start=gapPrefs.getLong(prefix+"start",dayStart(first))
        var end=gapPrefs.getLong(prefix+"end",dayEnd(last))
        var from=gapPrefs.getInt(prefix+"from",0).coerceIn(0,1439)
        var to=gapPrefs.getInt(prefix+"to",1439).coerceIn(0,1439)
        fun persistRange(){gapPrefs.edit().putLong(prefix+"start",start).putLong(prefix+"end",end).putInt(prefix+"from",from).putInt(prefix+"to",to).apply()}
        val shortDate=SimpleDateFormat("d MMM yyyy",Locale.UK)
        fun timeText(minutes:Int)="%02d:%02d".format(Locale.UK,minutes/60,minutes%60)
        val controls=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val dates=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val times=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val results=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        fun control(label:String):TextView=text(label,13f,accentColor,true).apply{
            gravity=Gravity.CENTER;setPadding(dp(7),dp(11),dp(7),dp(11))
            background=outlinedBg(if(darkMode)Color.rgb(26,47,43) else Color.rgb(226,247,240),Color.argb(80,7,94,84),9)
        }
        val startButton=control("");val endButton=control("")
        val fromButton=control("");val toButton=control("")
        dates.addView(startButton,LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(0,0,dp(4),0)})
        dates.addView(endButton,LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(dp(4),0,0,0)})
        times.addView(fromButton,LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(0,0,dp(4),0)})
        times.addView(toButton,LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(dp(4),0,0,0)})
        controls.addView(text("SEARCH RANGE · remembered for this conversation",13f,accentColor,true))
        controls.addView(text("Choose the ending message's date and time. Each gap starts at the actual previous message, even outside these filters.",12f,mutedColor))
        controls.addView(dates,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(5)})
        controls.addView(times,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(7)})
        body.addView(controls)
        body.addView(results)
        var revision=0
        fun refreshLabels(){
            startButton.text="From: ${shortDate.format(Date(start))}"
            endButton.text="To: ${shortDate.format(Date(end))}"
            fromButton.text="From: ${timeText(from)}"
            toButton.text="To: ${timeText(to)}"
        }
        fun refresh(){
            refreshLabels();revision++;val token=revision
            results.removeAllViews()
            if(start>end){results.addView(text("Start date must be before end date",12f,mutedColor));return}
            results.addView(text("Calculating longest gaps…",12f,mutedColor))
            val a=start;val b=end;val x=from;val y=to
            thread {
                val outcome=runCatching{db.longestMessageGaps(id,a,b,x,y)}
                runOnUiThread {
                    if(token!=revision || chatId!=id || results.parent==null)return@runOnUiThread
                    results.removeAllViews()
                    if(outcome.isFailure){results.addView(text("Unable to calculate gaps: ${outcome.exceptionOrNull()?.message}"));return@runOnUiThread}
                    val grouped=outcome.getOrThrow()
                    if(grouped.isEmpty())results.addView(text("No qualifying gaps in this range",13f,mutedColor))
                    val stamp=SimpleDateFormat("d MMM yyyy · HH:mm",Locale.UK)
                    val palette=intArrayOf(Color.rgb(20,137,124),Color.rgb(118,112,185),Color.rgb(199,126,68))
                    for((senderIndex,entry) in grouped.entries.withIndex()){
                        val sender=entry.key;val gaps=entry.value
                        val shade=palette[senderIndex%palette.size]
                        results.addView(text(sender,16f,shade,true),LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(15)})
                        val longest=gaps.maxOfOrNull{it.durationMs}?.coerceAtLeast(1L)?:1L
                        gaps.forEachIndexed { index,g ->
                            val gapDurationMs=g.durationMs
                            val mins=gapDurationMs/60000L
                            val duration=when {
                                mins>=1440 -> "${mins/1440}d ${mins%1440/60}h ${mins%60}m"
                                mins>=60 -> "${mins/60}h ${mins%60}m"
                                else -> "${mins}m"
                            }
                            val item=LinearLayout(this).apply{
                                orientation=LinearLayout.VERTICAL
                                setPadding(dp(7),dp(8),dp(7),dp(9))
                                background=outlinedBg(if(darkMode)Color.rgb(28,35,35) else Color.rgb(247,249,248),Color.argb(45,90,120,120),8)
                                setOnClickListener {
                                    val target=db.statsMessageAt(id,g.later) ?: db.messageOnOrAfter(id,"",g.later)
                                    if(target!=null)jumpToMessage(target)
                                }
                            }
                            val heading=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                            heading.addView(text("${index+1}.  ${stamp.format(Date(g.later))}",12f,mutedColor),LinearLayout.LayoutParams(0,-2,1f))
                            heading.addView(text(duration,14f,shade,true))
                            item.addView(heading)
                            val track=LinearLayout(this).apply{
                                orientation=LinearLayout.HORIZONTAL
                                background=outlinedBg(if(darkMode)Color.rgb(55,61,61) else Color.rgb(224,230,227),Color.TRANSPARENT,4)
                            }
                            val fraction=(gapDurationMs.toDouble()/longest.toDouble()).coerceIn(0.01,1.0)
                            val fill=View(this).apply{background=outlinedBg(shade,shade,4)}
                            track.addView(fill,LinearLayout.LayoutParams(0,dp(11),fraction.toFloat()))
                            track.addView(View(this),LinearLayout.LayoutParams(0,dp(11),(1.0-fraction).toFloat()))
                            item.addView(track,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(7)})
                            results.addView(item,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(5)})
                        }
                    }
                }
            }
        }
        fun pickDate(isStart:Boolean){
            val cal=Calendar.getInstance().apply{timeInMillis=if(isStart)start else end}
            android.app.DatePickerDialog(this,{_,year,month,day->
                val selected=Calendar.getInstance().apply{
                    timeInMillis=if(isStart)start else end
                    set(Calendar.YEAR,year);set(Calendar.MONTH,month);set(Calendar.DAY_OF_MONTH,day)
                }.timeInMillis
                if(isStart)start=dayStart(selected) else end=dayEnd(selected)
                persistRange();refresh()
            },cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH)).show()
        }
        fun pickTime(isStart:Boolean){
            val minute=if(isStart)from else to
            android.app.TimePickerDialog(this,{_,hour,min->
                if(isStart)from=hour*60+min else to=hour*60+min
                persistRange();refresh()
            },minute/60,minute%60,true).show()
        }
        startButton.setOnClickListener{pickDate(true)}
        endButton.setOnClickListener{pickDate(false)}
        fromButton.setOnClickListener{pickTime(true)}
        toButton.setOnClickListener{pickTime(false)}
        refresh()
    }

    private fun renderVisualHighlights(body:LinearLayout,visual:ArchiveDb.VisualStats,which:String) {
        fun heading(value:String,description:String) {
            body.addView(text(value,19f,accentColor,true),LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(16)})
            body.addView(text(description,12f,mutedColor),LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(7)})
        }
        fun jump(time:Long,day:Boolean=false){
            val id=chatId ?: return
            val target=db.statsMessageAt(id,time,day) ?: db.messageOnOrAfter(id,"",time)
            if(target!=null)jumpToMessage(target) else alert("No message found for this date.")
        }
        if(which=="clock") {
        heading("🕒 Your 24-hour clock","Hourly activity around the clock · tap an hour for sender breakdown")
        if(visual.hourCounts.any{it>0}) {
            val hourInfo=text("Tap an hour on the clock",13f,bodyColor,true)
            val clock=object:View(this) {
                private val pen=Paint(Paint.ANTI_ALIAS_FLAG)
                override fun onDraw(canvas:Canvas){
                    super.onDraw(canvas)
                    val size=minOf(width,height).toFloat();val cx=width/2f;val cy=height/2f
                    val outer=size*.43f;val inner=size*.20f
                    // Each person's ring always retains the same colour as Flow and other comparisons.
                    val max=visual.hourCounts.maxOrNull()?.coerceAtLeast(1)?:1
                    for(hour in 0..23){
                        val theta=(hour-6)*Math.PI/12
                        for(senderIndex in visual.hoursBySender.indices.take(2)){
                            val count=visual.hoursBySender[senderIndex].second.getOrElse(hour){0}
                            val length=(outer-inner-dp(6))*(count.toFloat()/max).coerceAtLeast(.025f)
                            pen.strokeWidth=dp(5).toFloat();pen.strokeCap=Paint.Cap.ROUND
                            pen.color=senderGraphColors[senderIndex%senderGraphColors.size]
                            val radius=inner+senderIndex*dp(7)
                            val sx=cx+radius*kotlin.math.cos(theta).toFloat();val sy=cy+radius*kotlin.math.sin(theta).toFloat()
                            canvas.drawLine(sx,sy,cx+(radius+length)*kotlin.math.cos(theta).toFloat(),cy+(radius+length)*kotlin.math.sin(theta).toFloat(),pen)
                        }
                    }
                    pen.style=Paint.Style.FILL;pen.textAlign=Paint.Align.CENTER;pen.color=bodyColor;pen.textSize=dp(15).toFloat()
                    canvas.drawText("24 hours",cx,cy+dp(5),pen)
                    pen.textSize=dp(10).toFloat();pen.color=mutedColor
                    canvas.drawText("00",cx,cy-outer-dp(4),pen);canvas.drawText("06",cx+outer+dp(10),cy+dp(4),pen)
                    canvas.drawText("12",cx,cy+outer+dp(15),pen);canvas.drawText("18",cx-outer-dp(11),cy+dp(4),pen)
                }
                override fun onTouchEvent(event:android.view.MotionEvent):Boolean {
                    if(event.action==android.view.MotionEvent.ACTION_UP){
                        val theta=kotlin.math.atan2((event.y-height/2f).toDouble(),(event.x-width/2f).toDouble())
                        val hour=((kotlin.math.round((theta+Math.PI/2)*12/Math.PI).toInt()%24)+24)%24
                        val count=visual.hourCounts[hour]
                        val by=visual.hoursBySender.joinToString(" · "){(sender,values)->"$sender ${values[hour]}"}
                        hourInfo.text="%02d:00–%02d:59 · %,d messages\n%s".format(Locale.UK,hour,hour,count,by)
                        performClick();return true
                    }
                    return true
                }
                override fun performClick():Boolean {super.performClick();return true}
            }
            body.addView(clock,LinearLayout.LayoutParams(dp(256),dp(256)).apply{gravity=Gravity.CENTER_HORIZONTAL})
            body.addView(hourInfo)
        }
        }
        if(which=="rhythm") {
        // Keep this plot inside the existing Conversation rhythm section;
        // do not add a second heading with the same name.
        body.addView(text("Message activity over the whole history · colours show each participant · tap a period",12f,mutedColor),LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(7);bottomMargin=dp(7)})
        if(visual.rhythm.isNotEmpty()){
            val horizontal=HorizontalScrollView(this).apply{isHorizontalScrollBarEnabled=true}
            val chart=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.BOTTOM;setPadding(dp(6),dp(9),dp(6),dp(9))}
            val peak=visual.rhythm.maxOf{it.counts.sum()}.coerceAtLeast(1)
            visual.rhythm.forEachIndexed{idx,bucket->
                val total=bucket.counts.sum()
                val stack=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.BOTTOM}
                val height=(dp(155).toFloat()*total/peak).toInt().coerceAtLeast(if(total>0)dp(2) else 0)
                bucket.counts.forEachIndexed{senderIndex,count->
                    if(count>0){val part=(height.toFloat()*count/total).toInt().coerceAtLeast(1)
                        stack.addView(View(this).apply{setBackgroundColor(senderGraphColors[senderIndex % senderGraphColors.size])},LinearLayout.LayoutParams(dp(12),part))}
                }
                val cell=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.BOTTOM;contentDescription="Period ${idx+1}: $total messages"}
                cell.addView(stack,LinearLayout.LayoutParams(dp(12),dp(160)))
                cell.setOnClickListener{if(total>0)jump(bucket.startTime)}
                chart.addView(cell,LinearLayout.LayoutParams(dp(17),dp(160)))
            }
            horizontal.addView(chart);body.addView(horizontal,LinearLayout.LayoutParams(-1,dp(185)))
            val visibleRange=text("",11f,mutedColor)
            fun updateVisibleRange() {
                val count=visual.rhythm.size
                if(count==0)return
                val cellWidth=dp(17).coerceAtLeast(1)
                val left=(horizontal.scrollX/cellWidth).coerceIn(0,count-1)
                val right=((horizontal.scrollX+horizontal.width-1).coerceAtLeast(0)/cellWidth).coerceIn(left,count-1)
                visibleRange.text="From ${dateFormat.format(Date(visual.rhythm[left].startTime))} to ${dateFormat.format(Date(visual.rhythm[right].endTime))}"
            }
            horizontal.setOnScrollChangeListener { _,_,_,_,_-> updateVisibleRange() }
            horizontal.post { horizontal.fullScroll(View.FOCUS_RIGHT);updateVisibleRange() }
            body.addView(visibleRange)
            val legend=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            visual.hoursBySender.forEachIndexed {index,pair->
                legend.addView(View(this).apply{background=bg(senderGraphColors[index%senderGraphColors.size],8)},LinearLayout.LayoutParams(dp(15),dp(15)).apply{marginEnd=dp(6)})
                legend.addView(text(pair.first,12f,bodyColor),LinearLayout.LayoutParams(-2,-2).apply{marginEnd=dp(14)})
            }
            body.addView(legend)
        }
        }
    }

    private fun renderNewInfographics(body:LinearLayout,visual:ArchiveDb.VisualStats) {
        val colors=senderGraphColors
        val senders=visual.hoursBySender.map{it.first}
        val df=SimpleDateFormat("d MMM yyyy",Locale.UK)
        fun title(t:String,note:String) {
            body.addView(text(t,17f,accentColor,true),LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(13)})
            body.addView(text(note,12f,mutedColor),LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(5)})
        }
        fun go(time:Long) {
            val id=chatId ?: return
            val msg=db.statsMessageAt(id,time,true) ?: db.messageOnOrAfter(id,"",time)
            if(msg!=null)jumpToMessage(msg) else alert("No message found at that date")
        }
        fun summary(day:ArchiveDb.DailySender):String {
            val pieces=senders.mapIndexed{idx,s->"$s: ${day.counts.getOrElse(idx){0}}"}
            return "${df.format(Date(day.dayStart))} · ${day.counts.sum()} messages\n${pieces.joinToString(" · ")}"
        }
        // Flow: AM/PM periods with a stationary centre cursor and a moving, locally scaled plot.
        // The ribbons are centred on the message-count lines: top=messages+photos,
        // bottom=messages-voice notes. Draw only the visible region to avoid huge Android views.
        title("🌊 Flow","AM / PM · swipe to explore · photos above, voice notes below")
        if(visual.flowPeriods.isNotEmpty()) {
            val periods=visual.flowPeriods
            val dateTime=SimpleDateFormat("d MMM yyyy · a",Locale.UK)
            // Initially show the latest half-day period at the far-right edge,
            // giving a full-width wave instead of centring the final point with
            // an empty right-hand half. The centre cursor and swipe behaviour remain unchanged.
            val widthInPeriods = 36
            var selected=(periods.lastIndex-(widthInPeriods-1)/2).coerceAtLeast(0)
            val detail=text("",12f,bodyColor,true)
            val chartHeight=dp(225)
            val seriesCount=minOf(2,senders.size)
            fun rowText(i:Int):String {
                val p=periods[i.coerceIn(0,periods.lastIndex)]
                return "${dateTime.format(Date(p.startTime))}  ·  " + (0 until seriesCount).joinToString("   ") { si ->
                    "${senders[si]}: ${p.messages.getOrElse(si){0}} messages, ${p.photos.getOrElse(si){0}} photos, ${p.voiceNotes.getOrElse(si){0}} voice notes"
                }
            }
            detail.text=rowText(selected)
            // Centre either sender's smoothed message count on the middle gridline.
            // Maximum prototype smoothing = 25 half-day bins; middle width = 18 days.
            var centredSender = 0
            val smoothRadius = 12 // triangular 25-bin smoothing
            fun smoothed(si:Int,kind:Int):FloatArray {
                val values=FloatArray(periods.size)
                for(i in periods.indices) {
                    var total=0f;var weights=0f
                    val from=(i-smoothRadius).coerceAtLeast(0)
                    val to=(i+smoothRadius).coerceAtMost(periods.lastIndex)
                    for(j in from..to) {
                        val weight=(smoothRadius+1-kotlin.math.abs(i-j)).toFloat()
                        val p=periods[j]
                        val count=when(kind) {
                            0 -> p.messages.getOrElse(si){0}
                            1 -> p.photos.getOrElse(si){0}
                            else -> p.voiceNotes.getOrElse(si){0}
                        }
                        total+=count*weight
                        weights+=weight
                    }
                    values[i]=if(weights>0f)total/weights else 0f
                }
                return values
            }
            val smoothData=Array(seriesCount){si->Array(3){kind->smoothed(si,kind)}}
            val mediaEnvelopeMultiplier=9f // 3x the former media envelope scale // The same scale for photos above and voice notes below.
            val graph=object:View(this) {
                private val pen=Paint(Paint.ANTI_ALIAS_FLAG)
                private var dragStartX=0f
                private var dragOffset=0f
                private var dragged=false
                private var position=selected.toFloat()
                private val motion=android.widget.OverScroller(this@MainActivity)
                private var velocity:android.view.VelocityTracker?=null
                private val units=1000
                private fun updatePosition(value:Float) {
                    position=value
                    val nearest=value.toInt().coerceIn(0,periods.lastIndex)
                    if(selected!=nearest) { selected=nearest; detail.text=rowText(selected) }
                    postInvalidateOnAnimation()
                }
                override fun computeScroll() {
                    if(motion.computeScrollOffset()) {
                        updatePosition(motion.currX.toFloat()/units)
                        if(motion.isOverScrolled) motion.springBack(motion.currX,0,0,periods.lastIndex*units,0,0)
                    } else if(position<0f || position>periods.lastIndex.toFloat()) {
                        if(motion.springBack((position*units).toInt(),0,0,periods.lastIndex*units,0,0))postInvalidateOnAnimation()
                    }
                }
                private val topMargin=dp(15).toFloat()
                private val bottomMargin=dp(15).toFloat()
                override fun onDraw(c:Canvas) {
                    super.onDraw(c)
                    if(width<=0||height<=0||seriesCount==0)return
                    val centreX=width/2f
                    val pxPerPeriod=width.toFloat()/(widthInPeriods-1)
                    val halfPoints=widthInPeriods/2+2
                    val left=(selected-halfPoints).coerceAtLeast(0)
                    val right=(selected+halfPoints).coerceAtMost(periods.lastIndex)
                    val anchor=smoothData[centredSender.coerceIn(0,seriesCount-1)][0][selected]
                    var maximumDistance=8f
                    for(i in left..right)for(si in 0 until seriesCount) {
                        val data=smoothData[si]
                        val upper=data[0][i]+mediaEnvelopeMultiplier*data[1][i]
                        val lower=data[0][i]-mediaEnvelopeMultiplier*data[2][i]
                        maximumDistance=maxOf(maximumDistance,kotlin.math.abs(upper-anchor),kotlin.math.abs(lower-anchor))
                    }
                    maximumDistance*=1.12f
                    val middleY=(topMargin+height-bottomMargin)/2f
                    val halfHeight=((height-topMargin-bottomMargin)/2f).coerceAtLeast(1f)
                    fun y(value:Float)=middleY-(value-anchor)/maximumDistance*halfHeight
                    fun x(i:Int)=centreX+(i-position)*pxPerPeriod
                    for(tick in 0..4) {
                        val yy=topMargin+(height-topMargin-bottomMargin)*tick/4f
                        pen.style=Paint.Style.STROKE
                        pen.color=Color.argb(if(tick==2)80 else 30,100,100,100)
                        pen.strokeWidth=dp(1).toFloat()
                        c.drawLine(0f,yy,width.toFloat(),yy,pen)
                        pen.style=Paint.Style.FILL
                        pen.color=mutedColor
                        pen.textSize=dp(10).toFloat()
                        c.drawText(String.format(Locale.UK,"%.0f",anchor+maximumDistance*(2-tick)/2f),dp(3).toFloat(),yy-dp(2),pen)
                    }
                    for(si in 0 until seriesCount) {
                        val colour=colors[si%colors.size]
                        val data=smoothData[si]
                        val upper=android.graphics.Path()
                        val centre=android.graphics.Path()
                        for(i in left..right) {
                            val xx=x(i)
                            val upperY=y(data[0][i]+mediaEnvelopeMultiplier*data[1][i])
                            val centreY=y(data[0][i])
                            if(i==left) {
                                upper.moveTo(xx,upperY)
                                centre.moveTo(xx,centreY)
                            } else {
                                val prevX=x(i-1)
                                val midX=(prevX+xx)/2f
                                upper.cubicTo(midX,y(data[0][i-1]+mediaEnvelopeMultiplier*data[1][i-1]),midX,upperY,xx,upperY)
                                centre.cubicTo(midX,y(data[0][i-1]),midX,centreY,xx,centreY)
                            }
                        }
                        val envelope=android.graphics.Path(upper)
                        for(i in right downTo left) envelope.lineTo(x(i),y(data[0][i]-mediaEnvelopeMultiplier*data[2][i]))
                        envelope.close()
                        pen.color=colour
                        pen.style=Paint.Style.FILL
                        pen.alpha=48
                        c.drawPath(envelope,pen)
                        pen.alpha=255
                        pen.style=Paint.Style.STROKE
                        pen.strokeWidth=dp(3).toFloat()
                        pen.strokeCap=Paint.Cap.ROUND
                        pen.strokeJoin=Paint.Join.ROUND
                        c.drawPath(centre,pen)
                    }
                    pen.style=Paint.Style.STROKE
                    pen.strokeWidth=dp(2).toFloat()
                    pen.color=Color.argb(145,90,90,90)
                    c.drawLine(centreX,topMargin,centreX,height-bottomMargin,pen)
                    pen.style=Paint.Style.FILL
                }
                override fun onTouchEvent(e:android.view.MotionEvent):Boolean {
                    val pixelsPerPeriod=width.toFloat().coerceAtLeast(1f)/(widthInPeriods-1)
                    when(e.actionMasked) {
                        android.view.MotionEvent.ACTION_DOWN -> {
                            if(!motion.isFinished)motion.forceFinished(true)
                            velocity?.recycle()
                            velocity=android.view.VelocityTracker.obtain().also{it.addMovement(e)}
                            dragStartX=e.x;dragOffset=0f;dragged=false
                            parent?.requestDisallowInterceptTouchEvent(true)
                            return true
                        }
                        android.view.MotionEvent.ACTION_MOVE -> {
                            velocity?.addMovement(e)
                            val delta=e.x-dragStartX
                            if(kotlin.math.abs(delta)>dp(4))dragged=true
                            // Sub-pixel continuity: no repeated integer jumps while dragging slowly.
                            val candidate=position-delta/pixelsPerPeriod
                            val edge=widthInPeriods*.20f
                            val damped=when {
                                candidate<0f -> candidate*.30f
                                candidate>periods.lastIndex -> periods.lastIndex+(candidate-periods.lastIndex)*.30f
                                else -> candidate
                            }.coerceIn(-edge,periods.lastIndex+edge)
                            updatePosition(damped)
                            dragStartX=e.x
                            return true
                        }
                        android.view.MotionEvent.ACTION_UP -> {
                            velocity?.addMovement(e)
                            velocity?.computeCurrentVelocity(1000)
                            val vx=velocity?.xVelocity?:0f
                            velocity?.recycle();velocity=null
                            if(!dragged) {
                                val step=((e.x-width/2f)/pixelsPerPeriod).toInt()
                                updatePosition((position+step).coerceIn(0f,periods.lastIndex.toFloat()))
                                performClick()
                            } else if(kotlin.math.abs(vx)>dp(170)) {
                                val flingVelocity=(-vx/pixelsPerPeriod*units).toInt()
                                motion.fling((position*units).toInt(),0,flingVelocity,0,
                                    0,periods.lastIndex*units,0,0,(widthInPeriods*.16f*units).toInt(),0)
                                postInvalidateOnAnimation()
                            } else {
                                motion.springBack((position*units).toInt(),0,0,periods.lastIndex*units,0,0)
                                postInvalidateOnAnimation()
                            }
                            parent?.requestDisallowInterceptTouchEvent(false)
                            return true
                        }
                        android.view.MotionEvent.ACTION_CANCEL -> {
                            velocity?.recycle();velocity=null
                            motion.springBack((position*units).toInt(),0,0,periods.lastIndex*units,0,0)
                            postInvalidateOnAnimation()
                            parent?.requestDisallowInterceptTouchEvent(false)
                            return true
                        }
                    }
                    return true
                }
                override fun performClick():Boolean {super.performClick();return true}
            }
            val centreSelector=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL }
            for(si in 0 until seriesCount) {
                val index=si
                val label=if(si==0)"Centre ${senders[si]}" else "Centre ${senders[si]}"
                centreSelector.addView(button(label) {
                    centredSender=index
                    graph.invalidate()
                },LinearLayout.LayoutParams(0,dp(48),1f))
            }
            body.addView(centreSelector)
            body.addView(graph,LinearLayout.LayoutParams(-1,chartHeight))
            val legend=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            senders.take(2).forEachIndexed {i,name->
                legend.addView(View(this).apply{background=bg(colors[i],8)},LinearLayout.LayoutParams(dp(15),dp(15)).apply{marginEnd=dp(6)})
                legend.addView(text(name,12f,bodyColor),LinearLayout.LayoutParams(-2,-2).apply{marginEnd=dp(16)})
            }
            body.addView(legend)
            body.addView(detail)
            body.addView(button("Open selected period") {go(periods[selected].startTime)})
        }
        // 2: Chronological spiral. Use a bounded number of plotted points for large histories.
        title("🌀 Spiral","Each dot is a day; larger dots mean more messages · tap to explore")
        if(visual.dailySenders.isNotEmpty()) {
            val days=visual.dailySenders
            var chosen=days.lastIndex
            val detail=text(summary(days[chosen]),12f,bodyColor,true)
            val plot=object:View(this) {
                private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
                override fun onDraw(c:Canvas) {
                    super.onDraw(c)
                    val cx=width/2f;val cy=height/2f;val maxR=minOf(cx,cy)*.88f
                    val maxCount=days.maxOf{it.counts.sum()}.coerceAtLeast(1)
                    val step=maxOf(1,days.size/900)
                    for(i in days.indices step step) {
                        val t=i.toFloat()/days.size.coerceAtLeast(1)
                        val angle=t*(Math.PI*16).toFloat()-1.57f
                        val radius=maxR*(.10f+.88f*t)
                        val x=cx+kotlin.math.cos(angle)*radius;val y=cy+kotlin.math.sin(angle)*radius
                        val count=days[i].counts.sum()
                        paint.color=colors[(days[i].counts.indices.maxByOrNull{days[i].counts[it]}?:0)%colors.size]
                        paint.alpha=185
                        c.drawCircle(x,y,dp(2).toFloat()+dp(4).toFloat()*kotlin.math.sqrt(count.toFloat()/maxCount),paint)
                    }
                    val t=chosen.toFloat()/days.size.coerceAtLeast(1)
                    val angle=t*(Math.PI*16).toFloat()-1.57f
                    val radius=maxR*(.10f+.88f*t)
                    paint.color=accentColor;paint.alpha=255;paint.style=Paint.Style.STROKE;paint.strokeWidth=dp(2).toFloat()
                    c.drawCircle(cx+kotlin.math.cos(angle)*radius,cy+kotlin.math.sin(angle)*radius,dp(8).toFloat(),paint)
                    paint.style=Paint.Style.FILL
                }
                override fun onTouchEvent(e:android.view.MotionEvent):Boolean {
                    if(e.action==android.view.MotionEvent.ACTION_UP){
                        // Select the nearest plotted daily point, not an arbitrary angle.
                        val cx=width/2f;val cy=height/2f;val maxR=minOf(cx,cy)*.88f
                        var closest=Float.MAX_VALUE;var best=chosen
                        val step=maxOf(1,days.size/900)
                        for(i in days.indices step step){
                            val t=i.toFloat()/days.size.coerceAtLeast(1);val angle=t*(Math.PI*16).toFloat()-1.57f
                            val r=maxR*(.10f+.88f*t)
                            val dx=cx+kotlin.math.cos(angle)*r-e.x;val dy=cy+kotlin.math.sin(angle)*r-e.y
                            val dist=dx*dx+dy*dy;if(dist<closest){closest=dist;best=i}
                        }
                        chosen=best;detail.text=summary(days[chosen]);invalidate();performClick();return true
                    };return true
                }
                override fun performClick():Boolean {super.performClick();return true}
            }
            body.addView(plot,LinearLayout.LayoutParams(-1,dp(265)))
            body.addView(detail)
            body.addView(button("Open selected day") {go(days[chosen].dayStart)})
        }
        // 3: Nested ring infographic; each sender gets one concentric ring, media categories are segments.
        title("🧬 Conversation DNA","Text and media mix for each person · tap a segment")
        if(visual.mediaTypes.isNotEmpty()) {
            val names=listOf("Text","Photos","Videos","Audio","Other media")
            val typeColors=intArrayOf(Color.rgb(7,132,105),Color.rgb(157,87,173),Color.rgb(49,143,196),Color.rgb(218,139,64),Color.rgb(160,165,172))
            val info=text("Tap any ring segment for a breakdown",12f,bodyColor,true)
            val plot=object:View(this) {
                private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
                override fun onDraw(c:Canvas){
                    super.onDraw(c)
                    val cx=width/2f;val cy=height/2f;val outer=minOf(width,height)*.45f
                    val ringSize=(outer*.75f/visual.mediaTypes.size.coerceAtLeast(1)).coerceAtMost(dp(24).toFloat())
                    visual.mediaTypes.forEachIndexed{index,pair->
                        val values=pair.second;val total=values.sum().coerceAtLeast(1);var angle=-90f
                        val rect=android.graphics.RectF(cx-outer+index*ringSize,cy-outer+index*ringSize,cx+outer-index*ringSize,cy+outer-index*ringSize)
                        paint.style=Paint.Style.STROKE;paint.strokeWidth=ringSize*.80f
                        values.forEachIndexed{kind,value->
                            if(value>0){val sweep=360f*value/total;paint.color=typeColors[kind%typeColors.size]
                                c.drawArc(rect,angle,sweep,false,paint);angle+=sweep}
                        }
                    }
                    paint.style=Paint.Style.FILL;paint.color=bodyColor;paint.textSize=dp(12).toFloat();paint.textAlign=Paint.Align.CENTER
                    c.drawText("DNA",cx,cy+dp(4),paint)
                }
                override fun onTouchEvent(e:android.view.MotionEvent):Boolean{
                    if(e.action==android.view.MotionEvent.ACTION_UP){
                        val cx=width/2f;val cy=height/2f;val radius=kotlin.math.hypot(e.x-cx,e.y-cy)
                        val outer=minOf(width,height)*.45f
                        val ringSize=(outer*.75f/visual.mediaTypes.size.coerceAtLeast(1)).coerceAtMost(dp(24).toFloat())
                        val index=((outer-radius)/ringSize).toInt().coerceIn(0,visual.mediaTypes.lastIndex)
                        val (sender,values)=visual.mediaTypes[index]
                        val theta=Math.toDegrees(kotlin.math.atan2((e.y-cy).toDouble(),(e.x-cx).toDouble()))
                        val position=((theta+450.0)%360.0)/360.0
                        var sum=0.0;val total=values.sum().coerceAtLeast(1);var selected=0
                        for(i in values.indices){sum+=values[i].toDouble()/total;if(position<=sum){selected=i;break}}
                        info.text="$sender · ${names[selected]}: ${values[selected]} of ${values.sum()} messages"
                        performClick();return true
                    };return true
                }
                override fun performClick():Boolean{super.performClick();return true}
            }
            body.addView(plot,LinearLayout.LayoutParams(-1,dp(265)))
            body.addView(info)
            body.addView(text("Quoted replies linked: ${visual.linkedQuotes} (can overlap the categories above)",11f,mutedColor))
            body.addView(text(names.mapIndexed{i,v->"● $v"}.joinToString("    "),11f,mutedColor))
        }
        // 4: Ten most active days; per-person coloured contribution bars, with date jump.
        title("🏆 Our Top Moments","The ten busiest conversation days · tap a day to revisit it")
        val top=visual.dailySenders.sortedByDescending{it.counts.sum()}.take(10)
        if(top.isNotEmpty()) {
            val max=top.maxOf{it.counts.sum()}.coerceAtLeast(1)
            top.forEachIndexed{idx,day->
                val line=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(6),dp(6),dp(6),dp(8))}
                line.addView(text("${idx+1}. ${df.format(Date(day.dayStart))} · ${day.counts.sum()} messages",12f,bodyColor,true))
                val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
                day.counts.forEachIndexed{i,count->
                    if(count>0) row.addView(View(this).apply{setBackgroundColor(colors[i%colors.size])},LinearLayout.LayoutParams(0,dp(13),count.toFloat()))
                }
                val shell=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
                shell.addView(row,LinearLayout.LayoutParams(0,dp(13),day.counts.sum().toFloat()))
                shell.addView(View(this),LinearLayout.LayoutParams(0,dp(13),(max-day.counts.sum()).coerceAtLeast(0).toFloat()))
                line.addView(shell)
                line.contentDescription=summary(day)+". Tap to open day"
                line.setOnClickListener{go(day.dayStart)}
                body.addView(line)
            }
            body.addView(text(senders.mapIndexed{i,v->"● $v"}.joinToString("    "),12f,accentColor))
        }
    }

    private fun renderChatStats(body:LinearLayout,stats:ChatStatistics,extra:ArchiveDb.ExtraStats,visual:ArchiveDb.VisualStats) {
        var openPair:LinearLayout?=null
        var tileIndex=0
        fun section(title:String) {
            openPair=null
            body.addView(text(title,19f,accentColor,true),LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(13);bottomMargin=dp(6)})
        }
        fun card(title:String,value:String,jumpTime:Long?=null,day:Boolean=false,last:Boolean=false) {
            val fill=if(darkMode) {
                if(tileIndex%3==0)Color.rgb(26,47,43) else if(tileIndex%3==1)Color.rgb(38,34,49) else Color.rgb(27,37,48)
            }else{
                if(tileIndex%3==0)Color.rgb(226,247,240) else if(tileIndex%3==1)Color.rgb(248,234,247) else Color.rgb(235,244,251)
            }
            tileIndex++
            val box=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setPadding(dp(9),dp(9),dp(8),dp(9));background=outlinedBg(fill,Color.argb(65,7,94,84),13)}
            box.addView(text(title,12f,accentColor,true))
            val row=LinearLayout(this).apply {orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            row.addView(text(value,15f,bodyColor,true),LinearLayout.LayoutParams(0,-2,1f))
            if(jumpTime!=null) {
                val link=text("🔗",19f,accentColor,true).apply{
                    gravity=Gravity.CENTER
                    contentDescription="Go to ${if(day) "start of day" else "message"}"
                    setOnClickListener {
                        val chat=chatId ?: return@setOnClickListener
                        val target=if(last)db.statsLastMessage(chat) else db.statsMessageAt(chat,jumpTime,day)
                        if(target!=null)jumpToMessage(target) else alert("That message could not be found.")
                    }
                }
                row.addView(link,LinearLayout.LayoutParams(dp(30),dp(38)))
            }
            box.addView(row)
            if(openPair==null) {
                val pair=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.TOP}
                body.addView(pair,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(6)})
                openPair=pair
            }
            openPair!!.addView(box,LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(dp(2),0,dp(2),0)})
            if(openPair!!.childCount>=2)openPair=null
        }
        section("📊 The big picture")
        card("Total messages", "%,d 💬".format(Locale.UK,stats.total))
        card("First message",stats.first?.let {dateFormat.format(Date(it))} ?: "—",stats.first)
        card("Last message",stats.last?.let {dateFormat.format(Date(it))} ?: "—",stats.last,last=true)
        card("Longest consecutive-day streak", "${stats.streak} days",stats.streakStart,day=true)
        card("Days with messages", "${stats.days}")
        card("Most messages in one day", "${stats.busiestCount} · ${stats.busiestDay}",stats.dailyEpochs.getOrNull(stats.daily.indexOfFirst{it.second==stats.busiestCount}),day=true)
        card("Busiest hour",if(stats.busiestHour>=0)"%02d:00 · %,d messages".format(Locale.UK,stats.busiestHour,stats.busiestHourCount) else "—")
        body.addView(text("Messages per day · swipe horizontally",17f,green,true))
        val chartScroll=HorizontalScrollView(this).apply{isHorizontalScrollBarEnabled=true;setBackgroundColor(cardColor)}
        // Restore the proven daily bar chart from v3.7. Stats stay cached in v3.8.
        val bars=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.BOTTOM;setPadding(dp(8),dp(12),dp(8),dp(12))}
        val max=stats.daily.maxOfOrNull {it.second}?.coerceAtLeast(1) ?: 1
        for ((index,entry) in stats.daily.withIndex()) {
            val (day,count)=entry
            val cell=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL}
            cell.addView(text("$count",9f,Color.DKGRAY).apply{gravity=Gravity.CENTER})
            val height=(dp(150)*count/max).coerceAtLeast(dp(2))
            cell.addView(View(this).apply{background=bg(accentColor,3)},LinearLayout.LayoutParams(dp(20),height))
            cell.addView(text(day,8f,mutedColor).apply{gravity=Gravity.CENTER})
            cell.contentDescription="$day: $count messages. Tap to open the start of that day"
            cell.setOnClickListener {
                val id=chatId ?: return@setOnClickListener
                val target=stats.dailyEpochs.getOrNull(index)?.let{db.statsMessageAt(id,it,true)}
                if(target!=null)jumpToMessage(target) else alert("No message found for this date.")
            }
            bars.addView(cell,LinearLayout.LayoutParams(dp(46),-2))
        }
        if(stats.daily.isEmpty())bars.addView(text("No dated messages"))
        chartScroll.addView(bars);body.addView(chartScroll,LinearLayout.LayoutParams(-1,dp(220)))
        chartScroll.post{chartScroll.fullScroll(View.FOCUS_RIGHT)}
        renderVisualHighlights(body,visual,"clock")
        renderNewInfographics(body,visual)
        section("✨ Your chat in numbers")
        card("Pictures sent", "%,d".format(Locale.UK,extra.photos))
        card("Voice notes and audio files", "%,d".format(Locale.UK,extra.voices))
        card("Videos", "%,d".format(Locale.UK,extra.videos))
        card("Other attachments", "%,d".format(Locale.UK,extra.otherFiles))
        section("📸 On-the-hour pictures")
        if(extra.onHourBySender.isEmpty())card("On-the-hour pictures","None yet")
        else extra.onHourBySender.forEach {card("${it.first} · on-the-hour pictures","${it.second} 📸")}
        section("💬 Who sends more?")
        val totalBySender=extra.senders.sumOf{it.second}.coerceAtLeast(1)
        val shareBar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(0,dp(5),0,dp(5))}
        val shareColors=intArrayOf(Color.rgb(22,168,94),Color.rgb(141,78,179),Color.rgb(43,140,188),Color.rgb(230,146,56))
        extra.senders.forEachIndexed{index,pair->
            val weight=pair.second.toFloat()/totalBySender
            shareBar.addView(View(this).apply{setBackgroundColor(shareColors[index%shareColors.size])},LinearLayout.LayoutParams(0,dp(28),weight))
            card("${pair.first} · messages", "%,d · %.1f%%".format(Locale.UK,pair.second,100.0*pair.second/totalBySender))
        }
        body.addView(shareBar)
        // Vocabulary totals use all ordinary message words, including short and common words.
        // Compare the same metric horizontally instead of presenting each sender separately.
        if(extra.vocabularyBySender.isNotEmpty()) {
            body.addView(text("Words & vocabulary by person",16f,green,true))
            val vocabs=extra.vocabularyBySender
            val left=vocabs.first()
            val right=vocabs.getOrNull(1)
            val header=LinearLayout(this).apply {orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),dp(9),dp(8),dp(8))}
            header.addView(text(left.sender,13f,accentColor,true).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(0,-2,1f))
            header.addView(text("STATISTIC",10f,mutedColor,true).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(0,-2,1.25f))
            header.addView(text(right?.sender ?: "",13f,accentColor,true).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(0,-2,1f))
            body.addView(header)
            fun vocabularyRow(label:String,leftValue:String,rightValue:String) {
                val line=LinearLayout(this).apply {orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),dp(12),dp(8),dp(12));background=outlinedBg(cardColor,Color.argb(65,7,94,84),10)}
                line.addView(text(leftValue,15f,bodyColor,true).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(0,-2,1f))
                line.addView(text(label,12f,mutedColor,true).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(0,-2,1.25f))
                line.addView(text(rightValue,15f,bodyColor,true).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(0,-2,1f))
                body.addView(line,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(5)})
            }
            vocabularyRow("Words sent", "%,d".format(Locale.UK,left.words),right?.let{"%,d".format(Locale.UK,it.words)} ?: "—")
            vocabularyRow("Characters sent", "%,d".format(Locale.UK,left.characters),right?.let{"%,d".format(Locale.UK,it.characters)} ?: "—")
            vocabularyRow("Avg word length", "%.2f".format(Locale.UK,left.averageWordLength),right?.let{"%.2f".format(Locale.UK,it.averageWordLength)} ?: "—")
            vocabularyRow("Distinct words", "%,d".format(Locale.UK,left.distinctWords),right?.let{"%,d".format(Locale.UK,it.distinctWords)} ?: "—")
            vocabularyRow("Exclusive words", "%,d".format(Locale.UK,left.exclusiveWords),right?.let{"%,d".format(Locale.UK,it.exclusiveWords)} ?: "—")
            fun wordWithLength(word:String):String = if(word=="—" || word.isBlank()) "—"
                else "$word (${word.codePointCount(0,word.length)} letters)"
            vocabularyRow("Longest recognised word",wordWithLength(left.longestRecognisedWord),right?.let{wordWithLength(it.longestRecognisedWord)} ?: "—")
            // For group chats, retain vocabulary details for any further participants.
            vocabs.drop(2).forEach { vocab ->
                card("${vocab.sender} · words", "%,d".format(Locale.UK,vocab.words))
                card("${vocab.sender} · characters", "%,d".format(Locale.UK,vocab.characters))
                card("${vocab.sender} · avg word length", "%.2f".format(Locale.UK,vocab.averageWordLength))
                card("${vocab.sender} · distinct words", "%,d".format(Locale.UK,vocab.distinctWords))
                card("${vocab.sender} · exclusive words", "%,d".format(Locale.UK,vocab.exclusiveWords))
                card("${vocab.sender} · longest recognised word", wordWithLength(vocab.longestRecognisedWord))
            }
            body.addView(text("Characters include spaces and punctuation. Average word length is in letters. Distinct words count different words used; exclusive words are those not used by any other sender. Longest recognised word checks an offline English dictionary and may exclude names, unusual words or other languages.",11f,mutedColor))
        }
        // The redundant sender-share doughnut previously shown here is intentionally removed.
        section("🎉 Your emoji hall of fame")
        if(extra.emojis.isEmpty()) body.addView(text("No emojis found in archived messages"))
        else {
            // Compact top-five rows, one row per sender, with usage counts under each emoji.
            body.addView(text("Top 5 by participant",15f,green,true))
            val senderColors=senderGraphColors
            val senderNames=extra.senders.map{it.first}
            for(sender in senderNames){
                val counts=extra.emojiBySender.asSequence().mapNotNull{ (emoji,pairs)->
                    val count=pairs.firstOrNull{it.first==sender}?.second ?: 0
                    if(count>0)emoji to count else null
                }.sortedWith(compareByDescending<Pair<String,Int>>{it.second}.thenBy{it.first}).take(5).toList()
                if(counts.isEmpty())continue
                val group=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),dp(5),dp(8),dp(7));background=outlinedBg(cardColor,Color.argb(65,7,94,84),10)}
                group.addView(text(sender,13f,bodyColor,true))
                val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                for((emoji,count) in counts){
                    val cell=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER}
                    cell.addView(text(emoji,23f,bodyColor).apply{gravity=Gravity.CENTER})
                    cell.addView(text("%,d".format(Locale.UK,count),11f,mutedColor,true).apply{gravity=Gravity.CENTER})
                    row.addView(cell,LinearLayout.LayoutParams(0,dp(63),1f))
                }
                group.addView(row)
                body.addView(group,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(5)})
            }
            body.addView(text("All emojis · swipe left for less frequent",15f,green,true))
            val emojiScroll=HorizontalScrollView(this).apply{isHorizontalScrollBarEnabled=true;setBackgroundColor(cardColor)}
            val emojiBars=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.BOTTOM;setPadding(dp(8),dp(6),dp(8),dp(8))}
            val ascending=extra.emojis.asReversed() // cached list is highest count first
            val largest=extra.emojis.first().second.coerceAtLeast(1)
            var selected=extra.emojis.first().first
            val detail=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),dp(9),dp(8),dp(9));background=outlinedBg(cardColor,Color.argb(75,7,94,84),12)}
            val detailLabel=text("",16f,green,true)
            detail.addView(detailLabel)
            val detailRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            val legend=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL}
            val donut=object:View(this){
                private val pen=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=dp(19).toFloat()}
                override fun onDraw(canvas:Canvas){
                    super.onDraw(canvas)
                    val side=(minOf(width,height)-dp(50)).toFloat().coerceAtLeast(1f)
                    val oval=android.graphics.RectF((width-side)/2f,(height-side)/2f,(width+side)/2f,(height+side)/2f)
                    val shares=extra.emojiBySender.firstOrNull{it.first==selected}?.second.orEmpty()
                    val total=shares.sumOf{it.second}.coerceAtLeast(1)
                    var angle=-90f
                    for((index,sender) in senderNames.withIndex()){
                        val count=shares.firstOrNull{it.first==sender}?.second?:0
                        if(count==0)continue
                        pen.color=senderColors[index%senderColors.size]
                        val sweep=360f*count/total
                        canvas.drawArc(oval,angle,sweep,false,pen);angle+=sweep
                    }
                    pen.style=Paint.Style.FILL;pen.color=bodyColor;pen.textAlign=Paint.Align.CENTER;pen.textSize=dp(22).toFloat()
                    canvas.drawText(selected,width/2f,height/2f+dp(7),pen)
                    pen.style=Paint.Style.STROKE;pen.textAlign=Paint.Align.LEFT
                }
            }
            detailRow.addView(donut,LinearLayout.LayoutParams(dp(148),dp(148)))
            detailRow.addView(legend,LinearLayout.LayoutParams(0,-2,1f))
            detail.addView(detailRow)
            val barViews=linkedMapOf<String,View>()
            fun refreshEmoji(){
                val shares=extra.emojiBySender.firstOrNull{it.first==selected}?.second.orEmpty()
                val total=extra.emojis.firstOrNull{it.first==selected}?.second ?: 0
                detailLabel.text="$selected  ·  %,d uses".format(Locale.UK,total)
                legend.removeAllViews()
                for((index,sender) in senderNames.withIndex()){
                    val count=shares.firstOrNull{it.first==sender}?.second?:0
                    val percent=if(total>0)100.0*count/total else 0.0
                    val line=text("● $sender  ·  %,d (%.1f%%)".format(Locale.UK,count,percent),12f,senderColors[index%senderColors.size],true)
                    legend.addView(line,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(5)})
                }
                for((emoji,view) in barViews)view.setBackgroundColor(if(emoji==selected)Color.rgb(8,127,105) else Color.rgb(137,188,170))
                donut.invalidate()
            }
            for((emoji,count) in ascending){
                val cell=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL}
                cell.addView(text("$count",9f,mutedColor).apply{gravity=Gravity.CENTER})
                val height=(dp(115)*count/largest).coerceAtLeast(dp(3))
                val bar=View(this).apply{setBackgroundColor(Color.rgb(137,188,170))}
                barViews[emoji]=bar
                cell.addView(bar,LinearLayout.LayoutParams(dp(24),height))
                cell.addView(text(emoji,20f,bodyColor).apply{gravity=Gravity.CENTER})
                cell.contentDescription="$emoji used $count times. Tap for sender breakdown"
                cell.setOnClickListener { selected=emoji;refreshEmoji() }
                emojiBars.addView(cell,LinearLayout.LayoutParams(dp(51),-2))
            }
            emojiScroll.addView(emojiBars)
            body.addView(emojiScroll,LinearLayout.LayoutParams(-1,dp(192)))
            emojiScroll.post{emojiScroll.fullScroll(View.FOCUS_RIGHT)}
            body.addView(detail,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(7)})
            refreshEmoji() // The most common emoji is selected on first display.
        }
        section("⏱️ Conversation rhythm")
        card("Average time between replies",extra.averageReplyMinutes?.let{"%.1f minutes".format(Locale.UK,it)}?:"—")
        card("Median time between replies",extra.medianReplyMinutes?.let{"%.1f minutes".format(Locale.UK,it)}?:"—")
        renderVisualHighlights(body,visual,"rhythm")
        section("⏳ Longest gaps before a message")
        renderLongestMessageGaps(body,chatId ?: return,stats.first,stats.last)
        section("🚂 Longest Message Train")
        extra.trains.forEach{card(it.first,"${it.second} consecutive messages")}
        card("Average message length","%.1f characters".format(Locale.UK,extra.averageLength))
        card("Longest message", "%,d characters".format(Locale.UK,extra.longestTextLength),extra.longestTextTime)
        card("Busiest weekday",extra.busiestWeekday)
        card("Busiest month",extra.busiestMonth)
        card("Messages sent between midnight and 6 am","%,d".format(Locale.UK,extra.nightMessages))
        section("🗣️ Your signature words")
        for((sender,words) in extra.topWordsBySender){
            if(words.isNotEmpty()){
                card("$sender · most common word", "${words.first().first}  ·  ${words.first().second} times")
                body.addView(text("$sender · runners-up: " + words.drop(1).joinToString("  ·  "){"${it.first} (${it.second})"},12f,mutedColor))
            }
        }
        section("🎲 Little conversation quirks")
        // The existing question statistic is shown in this expanded comparison.
        // Use the same left / statistic / right layout as the vocabulary section.
        val quirks=extra.quirksBySender
        if(quirks.isNotEmpty()) {
            val left=quirks.first()
            val right=quirks.getOrNull(1)
            val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),dp(9),dp(8),dp(8))}
            header.addView(text(left.first,13f,accentColor,true).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(0,-2,1f))
            header.addView(text("STATISTIC",10f,mutedColor,true).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(0,-2,1.25f))
            header.addView(text(right?.first ?: "",13f,accentColor,true).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(0,-2,1f))
            body.addView(header)
            fun quirkRow(label:String,l:String,r:String){
                val line=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(7),dp(11),dp(7),dp(11));background=outlinedBg(cardColor,Color.argb(65,7,94,84),10)}
                line.addView(text(l,14f,bodyColor,true).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(0,-2,1f))
                line.addView(text(label,12f,mutedColor,true).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(0,-2,1.25f))
                line.addView(text(r,14f,bodyColor,true).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(0,-2,1f))
                body.addView(line,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(5)})
            }
            fun count(n:Int)="%,d".format(Locale.UK,n)
            fun value(other:ArchiveDb.SenderQuirks?,field:(ArchiveDb.SenderQuirks)->Int)=other?.let{count(field(it))} ?: "—"
            val l=left.second;val r=right?.second
            quirkRow("Messages with !",count(l.exclamations),value(r){it.exclamations})
            quirkRow("Messages with ?",count(l.questions),value(r){it.questions})
            quirkRow("Messages with emoji",count(l.emojiMessages),value(r){it.emojiMessages})
            quirkRow("Emoji-only messages",count(l.emojiOnly),value(r){it.emojiOnly})
            quirkRow("Messages with laughter",count(l.laughterMessages),value(r){it.laughterMessages})
            quirkRow("Consecutive follow-up texts",count(l.doubleTexts),value(r){it.doubleTexts})
            quirkRow("Midnight–5:59 am",count(l.midnightMessages),value(r){it.midnightMessages})
            quirkRow("Messages with 3+ capitals",count(l.uppercaseMessages),value(r){it.uppercaseMessages})
            fun laughValue(s:String)=if(s=="—")s else "$s (${s.codePointCount(0,s.length)} chars)"
            quirkRow("Longest continuous laugh",laughValue(l.longestLaugh),r?.let{laughValue(it.longestLaugh)} ?: "—")
            quirks.drop(2).forEach { (sender,q) ->
                card("$sender · messages with !",count(q.exclamations))
                card("$sender · messages with ?",count(q.questions))
                card("$sender · messages with emoji",count(q.emojiMessages))
                card("$sender · emoji-only messages",count(q.emojiOnly))
                card("$sender · messages with laughter",count(q.laughterMessages))
                card("$sender · consecutive follow-up texts",count(q.doubleTexts))
                card("$sender · midnight messages",count(q.midnightMessages))
                card("$sender · 3+ capital letters",count(q.uppercaseMessages))
                card("$sender · longest continuous laugh",laughValue(q.longestLaugh))
            }
            body.addView(text("Counts are messages, not individual punctuation marks or emojis. Consecutive follow-up texts count messages after the first in each uninterrupted sender run. Laughter recognises repeated ha/he/hi/lol/lmao patterns; emoji-only messages may contain whitespace.",11f,mutedColor))
        }
        section("📅 Showing up")
        extra.daysBySender.forEach{card(it.first,"${it.second} days")}
        section("🔁 Top repeated messages by person")
        val repeated=extra.repeatedMessages.take(2)
        val repeatedPair=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL;gravity=Gravity.TOP }
        repeated.forEachIndexed { senderIndex,pair ->
            val (sender,ranking)=pair
            val senderColor=senderGraphColors[senderIndex % senderGraphColors.size]
            val panel=LinearLayout(this).apply {
                orientation=LinearLayout.VERTICAL
                setPadding(dp(6),dp(9),dp(6),dp(9))
                background=outlinedBg(if(senderIndex==0)Color.rgb(232,248,242) else Color.rgb(246,233,248),senderColor,15)
            }
            panel.addView(text(sender,15f,senderColor,true).apply{gravity=Gravity.CENTER})
            if(ranking.isEmpty())panel.addView(text("No repeated messages",12f,mutedColor))
            ranking.forEachIndexed { index,item ->
                val row=LinearLayout(this).apply{
                    orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
                    setPadding(dp(4),dp(7),dp(4),dp(7))
                    background=outlinedBg(Color.WHITE,Color.argb(45,70,80,80),12)
                    contentDescription="${sender}: ${item.first}, repeated ${item.second} times. Tap to find an example."
                }
                row.addView(text("${index+1}",12f,senderColor,true),LinearLayout.LayoutParams(dp(22),-2))
                row.addView(text(item.first,12f,bodyColor).apply{maxLines=3;ellipsize=android.text.TextUtils.TruncateAt.END},LinearLayout.LayoutParams(0,-2,1f))
                row.addView(text("${item.second}×",12f,senderColor,true))
                row.setOnClickListener{
                    val activeChat=chatId ?: return@setOnClickListener
                    thread {
                        val target=db.statsRepeatedMessage(activeChat,sender,item.first)
                        runOnUiThread{if(target!=null)jumpToMessage(target) else alert("Message not found")}
                    }
                }
                panel.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(5)})
            }
            repeatedPair.addView(panel,LinearLayout.LayoutParams(0,-2,1f).apply{
                if(senderIndex>0)leftMargin=dp(6) else rightMargin=dp(3)
            })
        }
        body.addView(repeatedPair)
        body.addView(text("Tap any phrase to open an example in the chat.",11f,mutedColor))

        section("📊 Shared favourites")
        body.addView(text("Most repeated messages used by both people · green and purple show each person's share.",12f,mutedColor))
        if(extra.sharedRepeatedMessages.isEmpty()) {
            body.addView(text("No shared repeated messages yet.",13f,mutedColor))
        }else{
            val maximum=extra.sharedRepeatedMessages.maxOf { item -> item.second.sumOf{it.second} }.coerceAtLeast(1)
            extra.sharedRepeatedMessages.forEachIndexed {index,item ->
                val total=item.second.sumOf{it.second}
                val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(2),dp(6),dp(2),dp(6))}
                row.addView(text("${index+1}",12f,accentColor,true),LinearLayout.LayoutParams(dp(24),-2))
                row.addView(text(item.first,11f,bodyColor).apply{maxLines=2;ellipsize=android.text.TextUtils.TruncateAt.END},LinearLayout.LayoutParams(0,-2,1.0f))
                val chartColumn=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
                val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;clipToOutline=true;background=GradientDrawable().apply{cornerRadius=dp(8).toFloat();setColor(Color.rgb(226,231,233))}}
                // Shared counts are returned in statistics-map order, which is not
                // guaranteed to match the sender order used by the top panels.
                // Resolve by the same sender labels used in that legend instead.
                val firstSender=repeated.getOrNull(0)?.first
                val secondSender=repeated.getOrNull(1)?.first
                val first=item.second.firstOrNull{it.first.equals(firstSender,ignoreCase=true)}?.second ?: 0
                val second=item.second.firstOrNull{it.first.equals(secondSender,ignoreCase=true)}?.second ?: 0
                bar.addView(View(this).apply{setBackgroundColor(senderGraphColors[0])},LinearLayout.LayoutParams(0,dp(16),first.toFloat().coerceAtLeast(0.0001f)))
                bar.addView(View(this).apply{setBackgroundColor(senderGraphColors[1])},LinearLayout.LayoutParams(0,dp(16),second.toFloat().coerceAtLeast(0.0001f)))
                val barWidth=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
                barWidth.addView(bar,LinearLayout.LayoutParams(0,dp(16),total.toFloat()))
                barWidth.addView(View(this),LinearLayout.LayoutParams(0,dp(16),(maximum-total).toFloat().coerceAtLeast(0.0001f)))
                chartColumn.addView(barWidth)
                chartColumn.addView(text("${first}  ·  ${second}",10f,mutedColor).apply{gravity=Gravity.CENTER})
                row.addView(chartColumn,LinearLayout.LayoutParams(0,-2,1.4f).apply{leftMargin=dp(6)})
                row.addView(text("${total}×",12f,accentColor,true).apply{gravity=Gravity.END},LinearLayout.LayoutParams(dp(42),-2))
                row.setOnClickListener{
                    val activeChat=chatId ?: return@setOnClickListener
                    val sender=item.second.firstOrNull{it.second>0}?.first ?: return@setOnClickListener
                    thread {val target=db.statsRepeatedMessage(activeChat,sender,item.first);runOnUiThread{if(target!=null)jumpToMessage(target)}}
                }
                body.addView(row)
            }
            val legend=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
            repeated.forEachIndexed {idx,pair->
                legend.addView(text("● ${pair.first}   ",13f,senderGraphColors[idx],true))
            }
            body.addView(legend)
        }
        section("🏷️ Your word counters")
        val id=chatId
        if(id!=null){
            if(extra.trackedCounts.isEmpty() || db.trackedWords(id).isEmpty()) {
                body.addView(text("Add a word to count how often each person uses it.",13f,mutedColor))
            }else{
                for(word in db.trackedWords(id)) {
                    val counts=extra.trackedCounts.joinToString("   "){ (sender,words)->
                        "$sender: ${words.firstOrNull{it.first==word}?.second?:0}"
                    }
                    val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;background=outlinedBg(Color.WHITE,Color.argb(65,7,94,84),12);setPadding(dp(10),dp(7),dp(8),dp(7))}
                    row.addView(text("$word  ·  $counts",13f,bodyColor,true),LinearLayout.LayoutParams(0,-2,1f))
                    row.addView(text("✕",21f,accentColor,true).apply {
                        contentDescription="Remove tracked word $word";setOnClickListener {
                            AlertDialog.Builder(this@MainActivity).setTitle("Remove '$word' counter?")
                                .setNegativeButton("Cancel",null).setPositiveButton("Remove"){_,_->
                                    db.saveTrackedWords(id,db.trackedWords(id).filter{it!=word});showChatStats()
                                }.show()
                        }
                    })
                    body.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(5)})
                }
            }
            body.addView(button("＋ Add a word counter") {
                val field=EditText(this).apply{hint="Word or phrase (e.g. coffee)";setSingleLine(true)}
                AlertDialog.Builder(this).setTitle("Track a word or phrase").setView(field).setNegativeButton("Cancel",null)
                    .setPositiveButton("Add"){_,_->
                        val newWord=field.text.toString().trim().lowercase(Locale.ROOT)
                        val saved=db.trackedWords(id)
                        if(newWord.isBlank() || newWord.length>60)alert("Enter a word or phrase (up to 60 characters).")
                        else if(saved.contains(newWord))alert("Already tracking '$newWord'.")
                        else if(saved.size>=30)alert("Maximum 30 tracked words.")
                        else {db.saveTrackedWords(id,saved+newWord);showChatStats()}
                    }.show()
            })
        }
        body.addView(text("Statistics exclude WhatsApp system notices and use archived messages and your device's local time. Reply timing means the gap between consecutive messages from different senders (gaps over 12 hours are excluded). Media counts use imported attachment filenames; some unrecognised files may appear under Other.",12f,Color.DKGRAY))
    }
    private fun showMedia(page: Int = 0, favouritesOnly:Boolean = false) {
        val id=chatId ?: return showHome()
        val parent=screen(chatName,"Photos and videos · newest first",true)
        chatTabs(parent,"Media")
        val tabs=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        fun tab(label:String,selected:Boolean,onClick:()->Unit){
            val b=button(label,onClick)
            b.alpha=if(selected)1f else .65f
            tabs.addView(b,LinearLayout.LayoutParams(0,dp(43),1f))
        }
        tab("All Media",!favouritesOnly){showMedia(0,false)}
        tab("★ Favourites",favouritesOnly){showMedia(0,true)}
        parent.addView(tabs)
        val paged=true // Media uses the original fast 48-item pages; chat preference is independent.
        val chunkSize=48
        val items=ArrayList(db.mediaPage(id,page,chunkSize,favouritesOnly))
        if(paged) parent.addView(pageNavigation(page,items.size==chunkSize,
            {showMedia(page+1,favouritesOnly)},{showMedia(page-1,favouritesOnly)}))
        val grid=GridView(this).apply {
            numColumns=3;horizontalSpacing=dp(3);verticalSpacing=dp(7)
            setPadding(dp(5),dp(5),dp(5),dp(5));clipToPadding=false
        }
        val thumbSize=((resources.displayMetrics.widthPixels-dp(22))/3).coerceAtLeast(dp(70))
        val adapter=object:android.widget.BaseAdapter(){
            override fun getCount()=items.size
            override fun getItem(position:Int):Any=items[position]
            override fun getItemId(position:Int)=position.toLong()
            override fun getView(position:Int,convertView:View?,container:ViewGroup):View {
                val holder=(convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply{
                    orientation=LinearLayout.VERTICAL
                    layoutParams=AbsListView.LayoutParams(thumbSize,thumbSize+dp(42))
                    val imageBox=android.widget.FrameLayout(this@MainActivity)
                    imageBox.addView(ImageView(this@MainActivity).apply{scaleType=ImageView.ScaleType.CENTER_CROP;setBackgroundColor(Color.LTGRAY)},android.widget.FrameLayout.LayoutParams(-1,-1))
                    imageBox.addView(text("",15f,Color.WHITE,true).apply{gravity=Gravity.TOP or Gravity.END},android.widget.FrameLayout.LayoutParams(-1,-2))
                    addView(imageBox,LinearLayout.LayoutParams(-1,thumbSize))
                    val actions=LinearLayout(this@MainActivity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                    actions.addView(text("☆",24f,accentColor).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(35),dp(40)))
                    actions.addView(text("Go to message",10f,accentColor,true).apply{gravity=Gravity.CENTER;maxLines=2},LinearLayout.LayoutParams(0,dp(40),1f))
                    addView(actions,LinearLayout.LayoutParams(-1,dp(40)))
                }
                val message=items[position];val file=io.mediaFile(message.attachment)
                val imageBox=holder.getChildAt(0) as android.widget.FrameLayout
                val img=imageBox.getChildAt(0) as ImageView
                img.setImageDrawable(null);img.setBackgroundColor(Color.LTGRAY)
                if(file!=null)try {
                    if(file.extension.lowercase(Locale.ROOT) in setOf("jpg","jpeg","png","webp","gif","heic")){
                        val opts=BitmapFactory.Options().apply{inJustDecodeBounds=true}
                        BitmapFactory.decodeFile(file.absolutePath,opts)
                        opts.inSampleSize=maxOf(1,maxOf(opts.outWidth/180,opts.outHeight/180));opts.inJustDecodeBounds=false
                        img.setImageBitmap(BitmapFactory.decodeFile(file.absolutePath,opts))
                    }else {
                        @Suppress("DEPRECATION")
                        val thumbnail=ThumbnailUtils.createVideoThumbnail(file.absolutePath,MediaStore.Video.Thumbnails.MINI_KIND)
                        img.setImageBitmap(thumbnail)
                    }
                }catch(_:Exception){}
                val badge=imageBox.getChildAt(1) as TextView
                badge.text=if(file?.extension?.lowercase(Locale.ROOT) in setOf("mp4","3gp","webm","mov"))"▶" else ""
                imageBox.setOnClickListener{if(file==null)alert("This media file is missing from the archive.") else showMediaViewer(id,message,file,favouritesOnly)}
                val actions=holder.getChildAt(1) as LinearLayout
                val star=actions.getChildAt(0) as TextView
                star.text=if(db.isMediaFavourite(id,message))"★" else "☆"
                star.contentDescription=if(db.isMediaFavourite(id,message))"Remove favourite" else "Add to favourites"
                star.setOnClickListener{
                    db.setMediaFavourite(id,message,!db.isMediaFavourite(id,message))
                    if(favouritesOnly)showMedia(0,true) else notifyDataSetChanged()
                }
                actions.getChildAt(1).setOnClickListener{jumpToMessage(message)}
                return holder
            }
        }
        grid.adapter=adapter
        parent.addView(grid,LinearLayout.LayoutParams(-1,0,1f))
        if(items.isEmpty())parent.addView(text("No photos or videos here yet."))
    }

    private fun showMediaViewer(id:Long,message:Message,file:File,favouritesOnly:Boolean){
        // The thumbnail opens the media itself. The viewer retains favourite and jump actions.
        val isPicture=file.extension.lowercase(Locale.ROOT) in setOf("jpg","jpeg","png","webp","gif","heic")
        if(!isPicture){
            openAttachment(file)
            return
        }
        val container=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),dp(8),dp(8),dp(8))}
        val photo=ImageView(this).apply{
            adjustViewBounds=true
            scaleType=ImageView.ScaleType.FIT_CENTER
            val bounds=BitmapFactory.Options().apply{inJustDecodeBounds=true}
            BitmapFactory.decodeFile(file.absolutePath,bounds)
            val sample=maxOf(1,maxOf(bounds.outWidth/1400,bounds.outHeight/1400))
            val opts=BitmapFactory.Options().apply{inSampleSize=sample}
            setImageBitmap(BitmapFactory.decodeFile(file.absolutePath,opts))
        }
        container.addView(photo,LinearLayout.LayoutParams(-1,dp(460)))
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val star=button(if(db.isMediaFavourite(id,message))"★ Favourited" else "☆ Add to favourites"){}
        val go=button("Go to message"){}
        actions.addView(star,LinearLayout.LayoutParams(0,dp(48),1f))
        actions.addView(go,LinearLayout.LayoutParams(0,dp(48),1f))
        container.addView(actions)
        val dialog=AlertDialog.Builder(this).setView(container).setNegativeButton("Close",null).create()
        star.setOnClickListener{
            val next=!db.isMediaFavourite(id,message)
            db.setMediaFavourite(id,message,next)
            star.text=if(next)"★ Favourited" else "☆ Add to favourites"
        }
        go.setOnClickListener{dialog.dismiss();jumpToMessage(message)}
        dialog.show()
    }

    private fun jumpToMessage(message: Message) {
        val id=chatId ?: return
        val page=db.pageForMessage(id,message)
        if(page==null) alert("The original message couldn't be found.")
        else showChat("",page,"${message.fingerprint}:${message.occurrence}")
    }
    private fun chatTabs(parent: LinearLayout, active: String) {
        val tabs=LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL
            setBackgroundColor(cardColor)
            setPadding(dp(5),dp(3),dp(5),0)
        }
        val entries=listOf("Messages" to {showChat()},"Bookmarks" to {showBookmarks()},"Media" to {showMedia()},"Voice Notes" to {showVoiceNotes()})
        for ((label, go) in entries) {
            val column=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_HORIZONTAL}
            val current=label.equals(active,ignoreCase=true)
            val tab=TextView(this).apply {
                text=label
                textSize=11f
                gravity=Gravity.CENTER
                setTextColor(if(current) accentColor else mutedColor)
                setTypeface(null,if(current) Typeface.BOLD else Typeface.NORMAL)
                setPadding(dp(1),dp(12),dp(1),dp(12))
                setOnClickListener { if(!current)go() }
            }
            column.addView(tab,LinearLayout.LayoutParams(-1,-2))
            val underline=View(this).apply {background=bg(if(current) green else Color.TRANSPARENT,2)}
            column.addView(underline,LinearLayout.LayoutParams(-1,dp(3)))
            tabs.addView(column,LinearLayout.LayoutParams(0,-2,1f))
        }
        parent.addView(tabs)
    }
    private fun waveform(): View = object: View(this) {
        private val paint=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {color=Color.rgb(137,169,157);strokeWidth=dp(3).toFloat();strokeCap=android.graphics.Paint.Cap.ROUND}
        override fun onDraw(canvas:android.graphics.Canvas) {
            super.onDraw(canvas)
            val count=36;val step=width.toFloat()/count
            for(i in 0 until count) {
                val heightFraction=(5+(i*11+i*i*3)%18)/25f
                val half=height*heightFraction/2
                val x=(i+0.5f)*step
                canvas.drawLine(x,height/2f-half,x,height/2f+half,paint)
            }
        }
    }.apply {minimumHeight=dp(28)}

    private fun showVoiceNotes(page: Int = 0) {
        val id=chatId ?: return showHome()
        val parent=screen(chatName,"Voice notes · newest first",true)
        chatTabs(parent,"Voice Notes")
        val items=db.voicePage(id,page,40)
        parent.addView(pageNavigation(page,items.size==40,{showVoiceNotes(page+1)},{showVoiceNotes(page-1)}))
        val body=scroller(parent)
        if(items.isEmpty())body.addView(text("No imported voice notes on this page."))
        for (m in items) {
            val card=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(12));background=outlinedBg(Color.WHITE,Color.argb(45,0,0,0),14)}
            val heading=LinearLayout(this).apply {orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            heading.addView(text(dateFormat.format(Date(m.time)),12f,Color.DKGRAY),LinearLayout.LayoutParams(0,-2,1f))
            heading.addView(text(db.displaySender(id,m.sender),12f,Color.DKGRAY))
            card.addView(heading)
            val label=db.voiceLabel(id,m)
            if(label.isNotBlank())card.addView(text("◆  $label",16f,green,true))
            val file=io.mediaFile(m.attachment)
            val duration=if(file!=null)try {
                val metadata=MediaMetadataRetriever()
                try {metadata.setDataSource(file.absolutePath);val ms=metadata.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?:0L
                    "%d:%02d".format(Locale.UK,ms/60000,(ms/1000)%60)
                } finally {metadata.release()}
            } catch (_:Exception) {""} else ""
            val playerRow=LinearLayout(this).apply {orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            playerRow.addView(button("▶") {if(file!=null)openAttachment(file) else alert("This voice recording is missing from the archive.")},LinearLayout.LayoutParams(dp(60),dp(55)))
            val waveformPanel=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL}
            waveformPanel.addView(waveform(),LinearLayout.LayoutParams(-1,dp(30)))
            val timings=LinearLayout(this).apply {orientation=LinearLayout.HORIZONTAL}
            timings.addView(text("Voice message",11f,Color.GRAY),LinearLayout.LayoutParams(0,-2,1f))
            timings.addView(text(duration,11f,Color.GRAY))
            waveformPanel.addView(timings)
            playerRow.addView(waveformPanel,LinearLayout.LayoutParams(0,-2,1f))
            playerRow.addView(button("✎") {
                val input=EditText(this).apply {setSingleLine(true);hint="Optional label";setText(db.voiceLabel(id,m))}
                AlertDialog.Builder(this).setTitle("Label this recording").setView(input)
                    .setNegativeButton("Cancel",null).setPositiveButton("Save") {_,_->db.setVoiceLabel(id,m,input.text.toString().trim());showVoiceNotes(page)}.show()
            },LinearLayout.LayoutParams(dp(56),dp(55)))
            card.addView(playerRow)
            val jump=TextView(this).apply {text="↗  Go to message";textSize=12f;setTextColor(green);gravity=Gravity.END;setPadding(dp(8),dp(10),dp(6),dp(5));setOnClickListener {jumpToMessage(m)}}
            card.addView(jump)
            body.addView(card,LinearLayout.LayoutParams(-1,-2).apply {bottomMargin=dp(10)})
        }
    }

    private fun showBookmarks() {
        val id=chatId ?: return showHome()
        val parent=screen(chatName,"Saved bookmarks · newest saved first",true)
        chatTabs(parent,"Bookmarks")
        val body=scroller(parent)
        val entries=db.bookmarks(id)
        if(entries.isEmpty())body.addView(text("No bookmarks yet. Open Messages and long-press a bubble, then select more messages if you want a group."))
        for(mark in entries) {
            val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(10),dp(12),dp(10));background=outlinedBg(Color.WHITE,Color.argb(45,0,0,0),14)}
            card.addView(text(mark.label,18f,green,true))
            card.addView(text("Saved ${dateFormat.format(Date(mark.savedAt))} · ${mark.messages.size} message(s)",12f,Color.GRAY))
            for(m in mark.messages) {
                card.addView(text("${db.displaySender(id,m.sender)} · ${dateFormat.format(Date(m.time))}",12f,green,true))
                card.addView(text("",14f).apply { text=formattedMessage(m.body) })
                val file=io.mediaFile(m.attachment)
                if(file!=null) card.addView(text("Attachment: ${file.name}",12f,Color.DKGRAY).apply{setOnClickListener {openAttachment(file)}})
            }
            card.addView(button("Go to messages") {
                val target=mark.messages.firstOrNull()
                if (target == null) alert("This bookmark no longer contains any messages.")
                else {
                    val targetPage=db.pageForMessage(id,target)
                    if (targetPage == null) alert("The original message could not be found in this conversation.")
                    else showChat("",targetPage,"${target.fingerprint}:${target.occurrence}")
                }
            })
            card.addView(button("Remove bookmark") {
                AlertDialog.Builder(this).setMessage("Remove this bookmark? Original messages will remain.").setNegativeButton("Cancel",null).setPositiveButton("Remove"){_,_->db.deleteBookmark(mark.groupId);showBookmarks()}.show()
            })
            body.addView(card,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(12)})
        }
    }
    // Playback stays inside the app and reads from its private media folder.
    private fun openAttachment(file: File) {
        when (file.extension.lowercase(Locale.ROOT)) {
            "jpg", "jpeg", "png", "webp", "gif", "heic" -> showImage(file)
            "mp4", "3gp", "webm", "mov" -> showVideo(file)
            "mp3", "m4a", "aac", "ogg", "opus", "wav", "amr" -> showAudio(file)
            else -> alert("This attachment type cannot yet be opened inside Tangled: ${file.extension}")
        }
    }

    private fun showVideo(file: File) {
        val player = VideoView(this)
        val dialog = AlertDialog.Builder(this)
            .setTitle("Video")
            .setView(player)
            .setPositiveButton("Close", null)
            .create()
        player.layoutParams = LinearLayout.LayoutParams(-1, dp(260))
        player.setMediaController(MediaController(this).apply { setAnchorView(player) })
        player.setOnErrorListener { _, _, _ ->
            android.widget.Toast.makeText(this, "Video format not supported by this phone", android.widget.Toast.LENGTH_LONG).show()
            true
        }
        dialog.setOnShowListener {
            player.setVideoPath(file.absolutePath)
            player.setOnPreparedListener { it.isLooping = false; player.start() }
        }
        dialog.setOnDismissListener { player.stopPlayback() }
        dialog.show()
    }

    private fun showAudio(file: File) {
        val player = MediaPlayer()
        val button = Button(this).apply { text = "Pause"; isAllCaps = false }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Audio · ${file.name}")
            .setView(button)
            .setPositiveButton("Close", null)
            .create()
        try {
            player.setDataSource(file.absolutePath)
            player.prepare()
        } catch (e: Exception) {
            player.release()
            alert("This audio format could not be opened: ${e.localizedMessage ?: "unsupported format"}")
            return
        }
        button.setOnClickListener {
            if(player.isPlaying) { player.pause(); button.text = "Play" }
            else { player.start(); button.text = "Pause" }
        }
        player.setOnCompletionListener { button.text = "Play"; player.seekTo(0) }
        dialog.setOnShowListener { player.start() }
        dialog.setOnDismissListener { player.release() }
        dialog.show()
    }

    private fun showImage(file:File){
        val img=ImageView(this).apply{setImageBitmap(BitmapFactory.decodeFile(file.path));adjustViewBounds=true}
        AlertDialog.Builder(this).setView(img).setPositiveButton("Close",null).show()
    }
    private fun importMoreMenu() {
        AlertDialog.Builder(this).setTitle("Import More")
            .setItems(arrayOf("Import WhatsApp chat manually", "Auto Sync · watched folder", "Import quoted-message JSON manually", "Crypt15 Import")){_,choice->
                when(choice){0->chooseImport(chatName);1->showAutoSync();2->chooseReplyJson();3->showCrypt15Menu()}
            }.show()
    }
    private fun chooseAutoFolder() {
        val intent=Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)}
        externalFilePickerOpen=true
        try{startActivityForResult(intent,folderCode)}catch(e:Exception){externalFilePickerOpen=false;alert("Cannot open folder picker: ${e.message}")}
    }
    private fun startAutoSync(showReport:Boolean) {
        if(!::autoSync.isInitialized || !autoSync.enabled() || !scanningAuto.compareAndSet(false,true))return
        if(currentScreen=="autoSync") autoHandler.postDelayed({ if(currentScreen=="autoSync")showAutoSync() },100L)
        thread {
            val result=runCatching {
                autoSync.flushQueuedScannerJson()
                val report=autoSync.scan(force=showReport)
                if(cryptSync.hasKey()) {
                    val newBackup=cryptSync.importNewestWatched(autoSync.folder())
                    if(newBackup)cryptSync.syncLinked()
                }
                report
            }
            runOnUiThread {
                scanningAuto.set(false)
                if(result.isSuccess){
                    latestAutoReport=result.getOrNull()
                    if(showReport)showAutoSync()
                    else if((latestAutoReport?.imported?:0)>0)Toast.makeText(this,"Tangled Auto Sync: ${latestAutoReport?.imported} new items",Toast.LENGTH_LONG).show()
                }else if(showReport){alert("Auto Sync failed: ${result.exceptionOrNull()?.message}")}
            }
        }
    }
    private fun showAutoSync() {
        // Preserve where the user entered Auto Sync, including screen refreshes.
        if(currentScreen!="autoSync") autoSyncReturnToChat=(chatId!=null && currentScreen!="home")
        val parent=screen("Auto Sync","Watched WhatsApp exports · private & offline",true)
        val body=scroller(parent)
        // The global scanner shortcuts use the exact same bookmarklet as the
        // chat-specific Quotes & Reactions screen. Historical scanning needs no
        // chat selection; update scanning needs the selected chat's checkpoint.
        body.addView(text("Quotes & Reactions · WhatsApp Web scanners",17f,green,true))
        body.addView(button("Historical Quotes & Reactions · Legacy scanner") {
            copyScannerCode("Tangled historical scanner",makeTest8Bookmarklet())
        })
        body.addView(button("Update scan · Copy bookmarklet") {
            val available=db.chats()
            if(available.isEmpty()) {
                alert("Import a conversation before running an update scan.")
            } else {
                AlertDialog.Builder(this)
                    .setTitle("Select conversation for update scan")
                    .setItems(available.map{it.name}.toTypedArray()) { _, which ->
                        val chosen=available[which]
                        val checkpoint=db.webCheckpoint(chosen.id).ifBlank { db.historyResume(chosen.id)?.first.orEmpty() }
                        if(checkpoint.isBlank()) {
                            alert("No saved scanning checkpoint for ${chosen.name}. Run a historical scan first.")
                        } else {
                            copyScannerCode("Tangled update scanner · ${chosen.name}",makeUpdateBookmarklet(checkpoint))
                        }
                    }
                    .setNegativeButton("Cancel",null)
                    .show()
            }
        })
        body.addView(text("Copy a scanner bookmarklet, run it in WhatsApp Web and press SAVE JSON, then select the watched Auto Sync folder in the Save As dialog. No clipboard import is performed.",12f,Color.DKGRAY))
        body.addView(Space(this).apply{minimumHeight=dp(8)})
        body.addView(text("Selected folder: ${autoSync.displayFolder()}",17f,green,true))
        body.addView(text("New exports enter Private Files first. Android ZIPs supply messages/media; WhatsApp Web ZIPs (TXT + MD) verify message times and quoted replies. QAR JSONs supply reactions and additional quotes. Unmatched sources remain private for later linking.",13f,Color.DKGRAY))
        body.addView(button("${if(autoSync.folder()==null)"Choose" else "Change"} watched folder") {chooseAutoFolder()})
        body.addView(button("Manage Private Files") {showSyncedVault()})
        body.addView(button("Crypt15 Import · Database conversations") {showCrypt15Menu()})
        body.addView(button("Rebuild Quotes & Reactions · All Chats") {confirmRebuildQar()})
        if(autoSync.folder()!=null) {
            if(!autoSync.hasWriteAccess())body.addView(text("To rename and archive ZIPs, reselect this folder and grant write access. Existing read-only selections can still import.",14f,Color.RED,true))
            body.addView(button(if(autoSync.enabled())"Pause Auto Sync" else "Enable Auto Sync") {autoSync.setEnabled(!autoSync.enabled());showAutoSync()})
            body.addView(button("Sync Now · Verify All Sources") {startAutoSync(true)})
            body.addView(button("Consolidate Chat ZIPs") {chooseConsolidation()})
        }
        body.addView(text("Auto Sync and its old Archive folder are temporary inboxes. ZIP, TXT and JSON files are checksum-verified into Tangled's private vault before any syncing. You can manage or export them from Private Files. Keep a complete backup before deleting files.",12f,Color.DKGRAY))
        val report=latestAutoReport
        if(report!=null){
            body.addView(text("Last check: ${report.scanned} files · ${report.imported} new items · ${report.skipped} unchanged",14f,green,true))
            for(error in report.errors.take(12))body.addView(text("⚠ $error",13f,Color.DKGRAY))
        }
        val files=runCatching{autoSync.vaultPending()}.getOrDefault(emptyList())
        val pending=files.filter{autoSync.assignedChat(it)==null}
        if(pending.isNotEmpty()){
            body.addView(text("Quotes & Reactions · awaiting chat link",17f,green,true))
            body.addView(text("These quoted JSONs don't yet have a saved conversation association. Choose one to connect it; ZIPs create conversations automatically.",13f,Color.DKGRAY))
            for(file in pending.take(30))body.addView(button("Link: ${file.name.take(42)}") {associateAutoFile(file)})
        }
        val autoCreated=db.autoCreatedChats()
        if(autoCreated.isNotEmpty()) {
            body.addView(text("New Auto Sync conversations · tap to review",18f,green,true))
            body.addView(button("Confirm All · clear ${autoCreated.size} reviewed conversation(s)") {
                AlertDialog.Builder(this).setTitle("Confirm all automatically added conversations?")
                    .setMessage("Remove all ${autoCreated.size} review entries. Conversations and their archived sources will stay intact.")
                    .setNegativeButton("Cancel",null)
                    .setPositiveButton("Confirm All"){_,_->
                        val removed=db.confirmAllAutoCreatedChats()
                        showAutoSync()
                        Toast.makeText(this,"Confirmed $removed conversation(s)",Toast.LENGTH_LONG).show()
                    }.show()
            })
            for(chat in autoCreated)body.addView(button("${chat.name} · ${chat.count} messages  ›") {reviewAutoCreatedChat(chat.id)})
        }
        body.addView(text("All ZIP/TXT and JSON sources, including pending and failed scans, are verified and moved to app-private storage before processing. Public originals are removed only after private checksum verification.",12f,Color.DKGRAY))
        body.addView(button("Manage recognised source filenames") {manageAutoSources()})
        body.addView(text("Synced Files",18f,green,true))
        val syncedFileRows=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        body.addView(syncedFileRows)
        val generation=++syncedFilesRefreshGeneration
        fun refreshFileRows() {
            if(currentScreen!="autoSync" || generation!=syncedFilesRefreshGeneration || isFinishing)return
            renderSyncedFileRows(syncedFileRows)
            if(scanningAuto.get() || autoSync.isBusy()) {
                autoHandler.postDelayed({refreshFileRows()},650L)
            }
        }
        refreshFileRows()
    }
    /** Source-type sections reuse the original import batches and detailed reports. */
    private fun renderSyncedFileRows(container:LinearLayout) {
        container.removeAllViews()
        val batches=db.autoBatches()
        val active=autoSync.syncProgress
        if(batches.isEmpty() && active==null){
            container.addView(text("No synced files yet.",13f,Color.DKGRAY));return
        }
        if(active!=null && active.fileName.isBlank())container.addView(text("↻ ${active.stage}",13f,green,true))
        val grouped=batches.groupBy{it.kind}
        val categories=listOf(Triple("chat","Conversations","💬"),Triple("web","WhatsApp Web Exports","🌐"),Triple("quote","Quotes & Reactions","💬"),Triple("crypt","Crypt15 Database Sync","🔐"))
        val state=getSharedPreferences("tangled_synced_sections",MODE_PRIVATE)
        for((kind,title,icon) in categories){
            val entries=grouped[kind].orEmpty()
            val working=active?.takeIf{p->p.fileName.isNotBlank() && (entries.any{it.fileName==p.fileName} || (kind=="web" && p.fileName.endsWith(".zip",true) && batches.none{it.fileName==p.fileName}))}
            val section=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
            val expanded=state.getBoolean(kind,true)
            val header=LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
                setPadding(dp(7),dp(13),dp(7),dp(13))
                isClickable=true;isFocusable=true
            }
            header.addView(text("$icon  $title",15f,accentColor,true),LinearLayout.LayoutParams(0,-2,1f))
            header.addView(text("${entries.size}  ${if(expanded)"▴" else "▾"}",13f,mutedColor))
            section.addView(header)
            val details=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=if(expanded)View.VISIBLE else View.GONE}
            header.setOnClickListener{
                val open=details.visibility!=View.VISIBLE
                state.edit().putBoolean(kind,open).apply()
                renderSyncedFileRows(container)
            }
            if(working!=null && entries.none{it.fileName==working.fileName})addSyncedFileRow(details,working.fileName,"importing",null,true)
            for(batch in entries){
                addSyncedFileRow(details,batch.fileName,batch.status,batch.id,active?.fileName==batch.fileName)
            }
            if(entries.isEmpty() && working==null)details.addView(text("No files yet",12f,mutedColor))
            section.addView(details)
            container.addView(section)
            container.addView(View(this).apply{setBackgroundColor(if(darkMode)Color.DKGRAY else Color.LTGRAY)},LinearLayout.LayoutParams(-1,dp(1)))
        }
    }
    private fun addSyncedFileRow(parent:LinearLayout,name:String,status:String,batchId:Long?,working:Boolean) {
        val row=LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(7),dp(9),dp(6),dp(9))
            isClickable=true
            isFocusable=true
        }
        val label=text(name,14f,if(darkMode)Color.WHITE else Color.DKGRAY,true).apply {
            maxLines=2
            ellipsize=android.text.TextUtils.TruncateAt.END
        }
        row.addView(label,LinearLayout.LayoutParams(0,-2,1f))
        val icon=TextView(this).apply {
            text=when {
                working -> "🔄"
                status=="completed" || status=="waiting" -> "✓"
                else -> "⚠"
            }
            textSize=23f
            gravity=Gravity.CENTER
            setTextColor(when {
                working -> green
                status=="completed" || status=="waiting" -> Color.rgb(26,137,82)
                else -> Color.rgb(184,112,26)
            })
            contentDescription=when {
                working -> "Syncing"
                status=="completed" || status=="waiting" -> "Initial sync completed; unresolved matches remain in file details"
                else -> "Sync failed"
            }
        }
        row.addView(icon,LinearLayout.LayoutParams(dp(44),dp(43)))
        if(working) {
            icon.startAnimation(android.view.animation.RotateAnimation(
                0f,360f,android.view.animation.Animation.RELATIVE_TO_SELF,.5f,
                android.view.animation.Animation.RELATIVE_TO_SELF,.5f).apply {
                duration=1100L
                repeatCount=android.view.animation.Animation.INFINITE
                interpolator=android.view.animation.LinearInterpolator()
            })
        }
        row.setOnClickListener {
            val progress=autoSync.syncProgress
            if(working && progress!=null && (progress.fileName==name || progress.fileName.isBlank())) {
                showActiveSyncDetails(name)
            } else if(batchId!=null)showAutoBatch(batchId)
            else showActiveSyncDetails(name)
        }
        parent.addView(row,LinearLayout.LayoutParams(-1,-2))
        parent.addView(View(this).apply{setBackgroundColor(if(darkMode)Color.DKGRAY else Color.LTGRAY)},LinearLayout.LayoutParams(-1,dp(1)))
    }
    private fun showActiveSyncDetails(name:String) {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(22),dp(12),dp(22),dp(12))}
        val statusText=text("Syncing…",14f,Color.DKGRAY)
        box.addView(statusText)
        val bar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate=true
            // A file importer does not yet expose a trustworthy percentage.
        }
        box.addView(bar,LinearLayout.LayoutParams(-1,dp(12)).apply{topMargin=dp(16)})
        val dialog=AlertDialog.Builder(this).setTitle(name).setView(box).setNegativeButton("Close",null).create()
        val handler=autoHandler
        val refresh=object:Runnable {
            override fun run(){
                if(!dialog.isShowing || isFinishing)return
                val p=autoSync.syncProgress
                if(p!=null && (p.fileName==name || p.fileName.isBlank())) {
                    val position=if(p.recordsTotal>0)" (${p.recordsDone}/${p.recordsTotal} messages/quotes)"
                        else if(p.total>0)" (${p.index}/${p.total} files)" else ""
                    statusText.text=p.stage+position
                    if(p.recordsTotal>0){
                        bar.isIndeterminate=false
                        bar.max=p.recordsTotal
                        bar.progress=p.recordsDone.coerceIn(0,p.recordsTotal)
                    } else bar.isIndeterminate=true
                    handler.postDelayed(this,650L)
                } else {
                    bar.isIndeterminate=false
                    bar.progress=100
                    statusText.text="Processing finished. Tap the file again for the full sync report."
                }
            }
        }
        dialog.setOnShowListener{refresh.run()}
        dialog.show()
    }
    private fun showArchiveMaintenance() {
        AlertDialog.Builder(this).setTitle("Archive maintenance")
            .setItems(arrayOf("Rebuild Quotes & Reactions · All Chats", "Rebuild Entire Archive · Private Files only")){_,which ->
                if(which==0)confirmRebuildQar() else confirmFullArchiveRebuild()
            }.setNegativeButton("Cancel",null).show()
    }
    private fun confirmFullArchiveRebuild() {
        if(!authenticated){alert("Unlock Tangled before rebuilding.");return}
        val retained=SyncedVault(this).list()
        val conversations=retained.count{it.kind=="chat"}
        val qar=retained.count{it.kind=="quote"}
        val web=retained.count{it.kind=="web"}
        val preserve=CheckBox(this).apply {
            text="Preserve bookmarks, media favourites and voice-note labels"
            isChecked=true
            setPadding(dp(16),dp(8),dp(16),dp(8))
        }
        AlertDialog.Builder(this).setTitle("Rebuild Entire Archive?")
            .setView(preserve)
            .setMessage("Only files CURRENTLY in Private Files will be used: $conversations conversation sources and $qar quote/reaction JSON sources.\n\n"+
                "All conversations, imported media, quotes, reactions, manually edited chat identities, merged chats and scan histories will be replaced by what can be reconstructed from those files. Deleted private source files will NOT be recovered.\n\n"+
                "Optional: keep bookmarks, media favourites and voice-note labels where the exact conversation and message can be matched; unmatched annotations are held for recovery.\n\n"+
                "Tangled first builds a separate replacement archive; if any source fails, your existing archive remains unchanged. Keep a separate backup before proceeding.")
            .setNegativeButton("Cancel",null)
            .setPositiveButton("Rebuild entire archive"){_,_->
                if(scanningAuto.get() || autoSync.isBusy()) {
                    alert("An Auto Sync is currently running. Retry after it finishes.")
                } else {
                    val keepAnnotations=preserve.isChecked
                    runTask("Rebuilding entire archive") {
                    val wasEnabled=autoSync.enabled()
                    autoSync.setEnabled(false)
                    try {FullArchiveRebuild(this,db).rebuild(keepAnnotations)}
                    finally {autoSync.setEnabled(wasEnabled)}
                    }
                }
            }.show()
    }

    private fun confirmRebuildQar() {
        AlertDialog.Builder(this).setTitle("Rebuild Quotes & Reactions?")
            .setMessage("REMOVE ALL quotes, reactions, manually confirmed QAR links and pending QAR matches from EVERY chat, then rebuild ONLY from QAR JSON files still in Private Files. Deleted files will NOT return. If no QAR JSON files remain, all QAR will be empty. Messages, media, bookmarks, identities and private files are preserved. An import failure rolls back the database changes.")
            .setNegativeButton("Cancel",null)
            .setPositiveButton("Rebuild"){_,_->
                thread {
                    val result=runCatching{autoSync.rebuildQar()}.getOrElse{"Rebuild stopped safely: ${it.message}"}
                    runOnUiThread{showAutoSync();alert(result)}
                }
            }.show()
    }

    // Fixed logical subfolders: sources remain checksum-addressed in the private
    // vault, so existing backups, clean rebuilds and file verification still work.
    // These are views, not movable directories: only Copy and Delete are offered.
    private fun showSyncedVault(section:String?=null) {
        if(!authenticated){alert("Unlock Tangled before viewing private files.");return}
        val files=runCatching{autoSync.vault.list()}.getOrElse{alert("Private files unavailable: ${it.message}");return}
        val parent=screen(if(section==null)"Private Files" else "Private Files · $section",
            "Private sources are organised automatically",true)
        currentScreen="vault"
        val body=scroller(parent)
        if(section==null){
            body.addView(button("Restore All · Copy files to folder") { chooseVaultRestoreAllFolder() })
            body.addView(text("Copies private files outside Tangled; originals stay here. Deleted private sources are excluded from clean rebuilds.",12f,mutedColor))
            val categories=listOf("Exported ZIPs","WhatsApp Web Exports","Quotes & Reactions","Other Files")
            for(category in categories){
                val count=files.count{privateFileCategory(it)==category}
                body.addView(button("▣  $category  ($count)  ›") {showSyncedVault(category)})
            }
        }else{
            body.addView(button("‹ Back to Private Files") {showSyncedVault()})
            val selected=files.filter{privateFileCategory(it)==section}.sortedBy{it.name.lowercase(Locale.ROOT)}
            if(selected.isEmpty())body.addView(text("No files in this folder.",14f,mutedColor))
            for(item in selected){
                body.addView(button("▤  ${item.name}") {
                    AlertDialog.Builder(this).setTitle(item.name)
                        .setItems(arrayOf("Copy to another folder","Delete file")){_,which->
                            if(which==0)exportPrivateFile(item,false)
                            else confirmDeletePrivateFile(item)
                        }.setNegativeButton("Cancel",null).show()
                })
            }
        }
    }
    private fun privateFileCategory(item:SyncedVault.Item):String=when {
        item.kind=="web" && item.name.endsWith(".zip",true)->"WhatsApp Web Exports"
        item.kind=="quote" && item.name.endsWith(".json",true)->"Quotes & Reactions"
        item.kind=="chat" && item.name.endsWith(".zip",true)->"Exported ZIPs"
        else->"Other Files"
    }
    private fun chooseVaultRestoreAllFolder() {
        if(!authenticated){alert("Unlock Tangled before restoring private files.");return}
        val count=autoSync.vault.list().size
        if(count==0){alert("There are no private files to copy.");return}
        AlertDialog.Builder(this).setTitle("Restore all private files?")
            .setMessage("Choose a destination folder to copy $count ZIP/JSON source files. Files will remain in Tangled's private vault. Existing destination files won't be overwritten.")
            .setNegativeButton("Cancel",null).setPositiveButton("Choose folder"){_,_->
                val intent=Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                }
                externalFilePickerOpen=true
                try{startActivityForResult(intent,vaultRestoreAllCode)}
                catch(e:Exception){externalFilePickerOpen=false;alert("Unable to choose folder: ${e.message}")}
            }.show()
    }
    private fun restoreAllVaultFiles(folder:Uri):String {
        val items=autoSync.vault.list().filter {
            it.name.endsWith(".zip",true) || it.name.endsWith(".json",true) || it.name.endsWith(".txt",true)
        }.sortedBy{it.name.lowercase(Locale.ROOT)}
        val parentId=DocumentsContract.getTreeDocumentId(folder)
        val parentUri=DocumentsContract.buildDocumentUriUsingTree(folder,parentId)
        val existing=mutableSetOf<String>()
        val childrenUri=DocumentsContract.buildChildDocumentsUriUsingTree(folder,parentId)
        contentResolver.query(childrenUri,arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME),null,null,null)?.use { cursor ->
            while(cursor.moveToNext())existing.add(cursor.getString(0))
        }
        var copied=0;var skipped=0;val errors=mutableListOf<String>()
        for(item in items) {
            // Never replace an existing file, even if the original name repeats.
            if(item.name in existing){skipped++;continue}
            val mime=when {item.name.endsWith(".json",true)->"application/json";item.name.endsWith(".txt",true)->"text/plain";else->"application/zip"}
            var created:Uri?=null
            try {
                created=DocumentsContract.createDocument(contentResolver,parentUri,mime,item.name)
                    ?:error("Android couldn't create destination")
                // export() validates the original and re-reads the exported copy
                // to confirm its SHA-256 checksum. A failed copy leaves the vault intact.
                autoSync.vault.export(item,created)
                copied++
                existing.add(item.name)
            }catch(e:Exception){
                if(created!=null)runCatching{DocumentsContract.deleteDocument(contentResolver,created)}
                errors.add("${item.name}: ${e.message ?: "copy failed"}")
            }
        }
        return buildString {
            append("Restored $copied private source files to the selected folder. All private originals retained.")
            if(skipped>0)append("\n$skipped already existed and were skipped (not overwritten).")
            if(errors.isNotEmpty())append("\n${errors.size} failed:\n"+errors.take(8).joinToString("\n"))
        }
    }
    private fun exportPrivateFile(item:SyncedVault.Item,move:Boolean) {
        exportingPrivateSource=item
        movingPrivateSource=move
        val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type=if(item.kind=="quote")"application/json" else if(item.name.endsWith(".txt",true))"text/plain" else "application/zip"
            putExtra(Intent.EXTRA_TITLE,item.name)
        }
        externalFilePickerOpen=true
        try{startActivityForResult(intent,vaultExportCode)}
        catch(e:Exception){externalFilePickerOpen=false;exportingPrivateSource=null;movingPrivateSource=false;alert("Unable to choose destination: ${e.message}")}
    }
    private fun confirmDeletePrivateFile(item:SyncedVault.Item) {
        AlertDialog.Builder(this).setTitle("Delete saved source permanently?")
            .setMessage("${item.name}\n\nThis deletes the private source file. The already imported conversation remains unchanged. The source cannot be recovered without a backup.")
            .setNegativeButton("Cancel",null).setPositiveButton("Delete"){_,_->
                runCatching{autoSync.vault.remove(item)}
                    .onFailure{alert("Could not delete: ${it.message}")}
                    .onSuccess{showSyncedVault()}
            }.show()
    }
    private fun chooseConsolidation() {
        if(autoSync.folder()==null){alert("Choose an Auto Sync folder first.");return}
        val chats=db.chats()
        if(chats.isEmpty()){alert("No conversations to consolidate.");return}
        AlertDialog.Builder(this).setTitle("Consolidate which conversation?")
            .setItems(chats.map{it.name}.toTypedArray()){_,chosen->
                val chat=chats[chosen]
                thread {
                    val result=runCatching{autoSync.previewConsolidation(chat.id)}
                    runOnUiThread{
                        result.onSuccess{preview->
                            AlertDialog.Builder(this).setTitle("Consolidate ${chat.name}?")
                                .setMessage("Found ${preview.fileCount} ZIP files containing approximately ${preview.messageCount} distinct messages. Original ZIPs are only deleted after the WhatsApp-style merged ZIP passes verification. The app's imported conversation remains untouched.\n\nMake a separate backup of the sync folder first.")
                                .setNegativeButton("Cancel",null)
                                .setNeutralButton("Keep originals"){_,_->runConsolidation(chat.id,false)}
                                .setPositiveButton("Merge and delete originals"){_,_->
                                    AlertDialog.Builder(this).setTitle("Delete original ZIPs after verification?")
                                        .setMessage("This cannot be undone. A verified consolidated ZIP will replace the current ZIP, and earlier ZIP versions will be deleted only after verification. Keep an external backup before continuing.")
                                        .setNegativeButton("Cancel",null)
                                        .setPositiveButton("Consolidate"){_,_->runConsolidation(chat.id,true)}.show()
                                }.show()
                        }.onFailure{alert("Cannot consolidate: ${it.message}")}
                    }
                }
            }.setNegativeButton("Cancel",null).show()
    }
    private fun runConsolidation(chatId:Long,deleteOriginals:Boolean){
        thread {
            val result=runCatching{autoSync.consolidate(chatId,deleteOriginals)}
            runOnUiThread{
                result.onSuccess{r->showAutoSync();alert("Verified merged ZIP: ${r.messageCount} messages, ${r.mediaCount} attachments. Processed ${r.fileCount} ZIPs; ${r.deleted} originals deleted. ${if(deleteOriginals)"Current ZIP was replaced." else "Originals retained; new ZIP saved alongside them."}")}
                    .onFailure{showAutoSync();alert("Consolidation stopped: ${it.message}. Check the sync folder before retrying; existing Tangled chats were not modified.")}
            }
        }
    }

    private fun reviewAutoCreatedChat(sourceId:Long) {
        val source=db.chats().firstOrNull{it.id==sourceId}?:return
        val choices=arrayOf("Confirm · clear from this list (keep conversation)", "Undo Sync · remove auto-created conversation")
        AlertDialog.Builder(this).setTitle(source.name).setMessage("${source.count} messages · Automatically created from an unrecognised export. Confirm clears this review entry without deleting the conversation; Undo reverses its automatic import.")
            .setItems(choices){_,option->when(option){
                0 -> {
                    runCatching{check(db.confirmAutoCreatedChat(sourceId)){"Review entry was not cleared"}}
                        .onSuccess{showAutoSync();Toast.makeText(this,"Conversation confirmed; archived chat retained",Toast.LENGTH_LONG).show()}
                        .onFailure{alert("Could not confirm: ${it.message}")}
                }
                1-> AlertDialog.Builder(this).setTitle("Undo auto-created conversation?")
                    .setMessage("Undo its automatic import batches and remove this conversation only if no manual changes, bookmarks or quoted links depend on it. Its source ZIP will remain in the private vault.")
                    .setNegativeButton("Cancel",null).setPositiveButton("Undo"){_,_->
                        thread {
                            val outcome=runCatching {
                                val batches=db.autoBatches().filter{it.chatId==sourceId && it.status=="completed"}.sortedByDescending{it.id}
                                for(batch in batches) {
                                    val status=db.undoAutoBatch(batch.id)
                                    if(!status.startsWith("Undid") && !status.startsWith("Removed"))error(status)
                                }
                                require(db.removeEmptyAutoCreatedChat(sourceId)){"Cannot remove conversation: additional data remains"}
                                "Auto-created conversation undone. Its source ZIP is retained in Tangled's private vault."
                            }.getOrElse{"Undo not completed: ${it.message}"}
                            runOnUiThread{showAutoSync();alert(outcome)}
                        }
                    }.show()
            }}.setNegativeButton("Close",null).show()
    }
    private fun manageAutoSources() {
        val chats=db.chats()
        if(chats.isEmpty()){alert("No conversations available");return}
        AlertDialog.Builder(this).setTitle("Recognised source filenames")
            .setItems(chats.map{it.name}.toTypedArray()){_,idx->manageAutoSourcesFor(chats[idx].id)}
            .setNegativeButton("Close",null).show()
    }
    private fun manageAutoSourcesFor(chatId:Long) {
        val chat=db.chats().firstOrNull{it.id==chatId}?:return
        val sources=db.sourceNames(chatId)
        val labels=sources.map{"${if(it.first=="chat")"ZIP/TXT" else "Quoted JSON"}: ${it.second}"}
        AlertDialog.Builder(this).setTitle("Source names · ${chat.name}")
            .setMessage("These names match future files even if the displayed conversation name changes. Tap a source name to unlink it; existing messages will remain.")
            .setItems((labels+"Add another source name").toTypedArray()){_,index->
                if(index==sources.size){
                    val field=EditText(this).apply{setSingleLine(true);hint="Original WhatsApp export filename"}
                    AlertDialog.Builder(this).setTitle("Associate export filename")
                        .setView(field).setNegativeButton("Cancel",null).setPositiveButton("Add"){_,_->
                            val name=field.text.toString().trim()
                            if(name.isNotEmpty())try {
                                autoSync.remember(AutoSync.Candidate(name,Uri.EMPTY,"chat",autoSync.normalise(name)),chatId)
                                showAutoSync()
                            }catch(e:Exception){alert(e.message?:"Could not add source")}
                        }.show()
                } else {
                    val (kind,key)=sources[index]
                    AlertDialog.Builder(this).setTitle("Unlink source name?")
                        .setMessage("$key will no longer automatically sync to ${chat.name}. Previously imported messages are unaffected.")
                        .setNegativeButton("Cancel",null).setPositiveButton("Unlink"){_,_->autoSync.unlink(kind,key,chatId);manageAutoSourcesFor(chatId)}.show()
                }
            }.setNegativeButton("Close",null).show()
    }
    private fun associateAutoFile(file:AutoSync.Candidate){
        val choices=db.chats()
        if(choices.isEmpty()){alert("Import a conversation manually first, then connect this export to it.");return}
        AlertDialog.Builder(this).setTitle("Associate ${file.name} with which chat?")
            .setItems(choices.map{it.name}.toTypedArray()){_,idx->
                autoSync.remember(file,choices[idx].id)
                startAutoSync(true)
            }.setNegativeButton("Cancel",null).show()
    }
    private fun showAutoBatch(id:Long){
        val batch=db.autoBatches().find{it.id==id} ?: return
        val range=if(batch.kind=="quote")"\n${autoSync.syncedItemRange(batch.id)}\nThese dates are content markers, not verified message-range scan checkpoints." else ""
        val detail="${batch.fileName}\n${if(batch.kind=="quote")autoSync.batchBreakdown(batch.id)+"\n" else ""}Type: ${when(batch.kind){"chat"->"WhatsApp chat";"web"->"WhatsApp Web export";"crypt"->"Crypt15 backup";else->"Quotes & Reactions"}}\nAdded: ${batch.added}\nAlready present or awaiting matching: ${batch.duplicates}\nStatus: ${batch.status}$range"
        val builder=AlertDialog.Builder(this).setTitle("Auto Sync details").setMessage(detail)
            .setNegativeButton("Close",null)
        if(batch.kind=="quote")builder.setPositiveButton("Unlink source") {_,_->
            val candidate=autoSync.vault.list().firstOrNull{it.name==batch.fileName && it.kind=="quote"}?.let{
                AutoSync.Candidate(it.name,autoSync.vault.uri(it),it.kind,autoSync.normalise(it.name))
            }
            if(candidate!=null) {
                autoSync.unlink(candidate.kind,candidate.key,batch.chatId)
                showAutoSync()
            } else alert("The original JSON file is no longer in the watched folder.")
        }
        builder
            .setNeutralButton("Undo sync"){_,_->
                AlertDialog.Builder(this).setTitle("Undo this automatic sync?")
                    .setMessage("Only changes recorded for this sync can be removed. Existing manual imports are protected. Any linked or bookmarked messages will block removal.")
                    .setNegativeButton("Cancel",null).setPositiveButton("Undo"){_,_->
                        thread {val outcome=runCatching{autoSync.undoBatch(id)}.getOrElse{"Undo failed: ${it.message}"};runOnUiThread{showAutoSync();alert(outcome)}}
                    }.show()
            }.show()
    }
    private fun rememberManualExport(uri:Uri,chatName:String){
        val filename=contentResolver.query(uri,null,null,null,null)?.use{c->val col=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);if(col>=0&&c.moveToFirst())c.getString(col)else null} ?: return
        val id=db.chats().find{it.name==chatName}?.id ?: return
        val kind=if(filename.endsWith(".json",true))"quote" else "chat"
        autoSync.remember(AutoSync.Candidate(filename,uri,kind,autoSync.normalise(filename)),id)
    }
    private fun chooseImport(name:String=""){
        importSuggestedName=name
        val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="*/*";putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("text/plain","application/zip","application/octet-stream"))}
        startActivityForResult(intent,importCode)
    }
    private var importSuggestedName=""
    private fun createBackup() {
        val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/zip";putExtra(Intent.EXTRA_TITLE,"Tangled-complete-${SimpleDateFormat("yyyy-MM-dd",Locale.UK).format(Date())}.zip")}
        startActivityForResult(intent,backupCode)
    }
    private fun confirmRestore(){
        val entries=if(io.canUndoMerge()) arrayOf("Replace existing archive", "Merge with existing archive", "Undo last merge", "Accept previous merge (remove Undo)")
            else arrayOf("Replace existing archive", "Merge with existing archive")
        AlertDialog.Builder(this).setTitle("Restore Tangled Backup").setItems(entries){_,which->
            when(which){
                0 -> AlertDialog.Builder(this).setTitle("Replace entire archive?")
                    .setMessage("This restores conversations, media, quotes, reactions, Auto Sync history and supported settings. It replaces your current archive. On a different phone, select a new Auto Sync folder afterward; Android folder permissions cannot be moved. Make a backup first.")
                    .setNegativeButton("Cancel",null).setPositiveButton("Choose backup"){_,_->selectRestoreFile(restoreCode)}.show()
                1 -> {
                    if(io.canUndoMerge())alert("Please undo or accept the previous merge before beginning another.")
                    else selectRestoreFile(mergeCode)
                }
                2 -> AlertDialog.Builder(this).setTitle("Undo last backup merge?")
                    .setMessage("This removes items added by the last merge only. If you have edited newly merged content, undo may not be appropriate. Back up first.")
                    .setNegativeButton("Cancel",null).setPositiveButton("Undo merge"){_,_->runTask("Undoing backup merge"){io.undoLastMerge()}}.show()
                3 -> AlertDialog.Builder(this).setTitle("Keep merged archive?")
                    .setMessage("The merge will be kept and its Undo record discarded. This cannot be reversed using Undo afterward.")
                    .setNegativeButton("Cancel",null).setPositiveButton("Keep"){_,_->io.acceptLastMerge();alert("Merge retained. You can now merge another backup.")}.show()
            }
        }.setNegativeButton("Cancel",null).show()
    }
    private fun selectRestoreFile(requestCode:Int){
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/zip"},requestCode)
    }
    private fun previewBackupMerge(uri:Uri){
        val progress=AlertDialog.Builder(this).setTitle("Checking backup").setMessage("Reading conversations and attachments…").setCancelable(false).create()
        progress.show()
        thread {
            val result=runCatching{io.previewMerge(uri)}
            runOnUiThread{
                progress.dismiss()
                result.onSuccess{preview->
                    AlertDialog.Builder(this).setTitle("Merge backup into Tangled?")
                        .setMessage("Backup includes ${preview.chats} conversations (${preview.newChats} not currently named in Tangled), ${preview.messages} message records and ${preview.mediaEntries} media files. Existing conversations, messages and settings are retained; duplicate records are skipped. Chats are matched by exact name, so differently renamed chats may remain separate. An Undo record will be available under Restore.\n\nBack up your current Tangled data before proceeding.")
                        .setNegativeButton("Cancel",null)
                        .setPositiveButton("Merge backup"){_,_->runTask("Merging backup"){io.mergeBackup(uri)}}.show()
                }.onFailure{alert("Cannot preview backup: ${it.message}")}
            }
        }
    }
    @Deprecated("Using platform activity results to avoid external dependencies")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==replyJsonCode || requestCode==folderCode || requestCode==vaultRestoreAllCode || requestCode==cryptImportCode)externalFilePickerOpen=false
        if(resultCode!=RESULT_OK)return
        val uri=data?.data ?: return
        when(requestCode) {
            cryptImportCode -> {
                runCryptTask("Importing crypt15 backup") {
                    val changed=cryptSync.importFile(uri)
                    if(changed)"Backup verified and stored. Previously linked conversations can now sync." else "This exact backup has already been imported."
                }
            }
            folderCode -> {
                try {contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION);autoSync.setFolder(uri);startAutoSync(true)}
                catch(e:Exception){alert("Cannot watch folder: ${e.message}")}
            }
            importCode -> {
                val exportFileName=contentResolver.query(uri,null,null,null,null)?.use { cursor ->
                    val column=cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if(column>=0 && cursor.moveToFirst())cursor.getString(column) else null
                } ?: uri.lastPathSegment.orEmpty()
                // Prefer the selected existing chat when importing into it; otherwise
                // suggest the export filename without its extension and numbered suffix.
                val suggested=importSuggestedName.ifBlank { autoSync.suggestedChatName(exportFileName) }
                if(importSuggestedName.isBlank()) {
                    val name=suggested.ifBlank{"WhatsApp Chat"}
                    runTask("Importing messages") {
                        val (added,duplicates)=io.importChat(uri,name)
                        rememberManualExport(uri,name)
                        "Imported $added new messages into '$name'; skipped $duplicates already present. Rename it anytime in Chat Edits."
                    }
                } else {
                    // Manual import into an existing chat remains available unchanged.
                    val name=importSuggestedName
                    runTask("Importing messages") {
                        val (added,duplicates)=io.importChat(uri,name)
                        rememberManualExport(uri,name)
                        "Imported $added new messages into '$name'; skipped $duplicates already present."
                    }
                }
            }
            replyJsonCode -> {loadReplyJson(uri);chatId?.let{id->db.chats().find{it.id==id}?.let{chat->rememberManualExport(uri,chat.name)}}}
            vaultRestoreAllCode -> runTask("Restoring all private files") {restoreAllVaultFiles(uri)}
            vaultExportCode -> {
                val item=exportingPrivateSource;exportingPrivateSource=null
                movingPrivateSource=false
                if(item!=null)runTask("Exporting private synced file") {
                    autoSync.vault.export(item,uri)
                    "Copied ${item.name} to the selected destination. Private source retained."
                }
            }
            backupCode -> runTask("Creating backup") {io.backup(uri);"Backup saved. Keep another copy somewhere safe before clearing WhatsApp."}
            restoreCode -> runTask("Restoring archive") {io.restore(uri);"Archive restored successfully."}
            mergeCode -> previewBackupMerge(uri)
        }
    }
    private data class ReplyProposal(val number:Int, val quote:String, val replyCandidates:List<Message>, val originalCandidates:List<Message>, val replyText:String="", val replyTimestamp:Long?=null)
    // Exact user-tested Test 5.1; do not modify its scanning loop or browser export.
    private fun makeScannerBookmarklet():String = """javascript:(async()=>{try{document.getElementById('tg5')?.remove();const main=document.querySelector('#main');if(!main){alert('Open a WhatsApp chat first');return}const sleep=t=>new Promise(r=>setTimeout(r,t));let run=true,steps=0,stalls=0,reason='',first=null,oldest=null;const seen=new Set(),reacted=new Set(),quotes=new Map(),reactions=new Map();const p=document.createElement('div');p.id='tg5';p.style.cssText='position:fixed!important;top:6px!important;left:8px!important;right:8px!important;z-index:2147483647!important;background:#075e54!important;color:white!important;padding:12px!important;border-radius:9px!important;font:13px Arial!important';const h=document.createElement('div'),stop=document.createElement('button'),copy=document.createElement('button');for(const b of[stop,copy])b.style.cssText='padding:11px!important;margin:5px!important;background:white!important;color:#075e54!important;border:0!important;border-radius:7px!important';stop.textContent='STOP';copy.textContent='COPY JSON';p.append(h,stop,copy);document.body.append(p);const msgs=()=>[...main.querySelectorAll('[data-id]')].filter(e=>e.getAttribute('data-id')&&e.querySelector('[data-pre-plain-text]'));const info=m=>({id:m.getAttribute('data-id'),time:m.querySelector('[data-pre-plain-text]')?.getAttribute('data-pre-plain-text')||''});const norm=s=>String(s||'').replaceAll(String.fromCharCode(65039),'').trim();const count=()=>[...reactions.values()].reduce((n,r)=>n+r.reactions.length,0);const show=s=>h.textContent='Tangled Test 5.1 | '+seen.size+' messages | '+quotes.size+' quotes | '+count()+' reactions | '+steps+' scrolls | '+s;const output=()=>JSON.stringify({test:'tangled-quotes-reactions-test5.1',scroll_steps:steps,unique_messages_seen:seen.size,stop_reason:reason,checkpoint:{newest:first,oldest},quotes:[...quotes.values()],reactions:[...reactions.values()]},null,2);stop.onclick=()=>{run=false;reason='Stopped by user';show('stopping')};copy.onclick=async()=>{const s=output();try{await navigator.clipboard.writeText(s);copy.textContent='COPIED'}catch(e){const t=document.createElement('textarea');t.value=s;p.append(t);t.select();document.execCommand('copy');t.remove();copy.textContent='COPIED'}};const sc=[...main.querySelectorAll('div')].filter(e=>e.clientHeight>180&&e.scrollHeight>e.clientHeight+150&&/auto|scroll/.test(getComputedStyle(e).overflowY)).sort((a,b)=>b.clientHeight-a.clientHeight)[0];if(!sc){show('Scroller not found');return}const parse=s=>{const a=s.split(' reacted with ');return a.length===2?{actor:a[0]==='You'?'self':a[0],emoji:a[1].replace(' Click to remove','')}:null};const scan=async()=>{for(const m of msgs()){if(!run)break;const id=m.getAttribute('data-id'),stamp=info(m).time;if(!seen.has(id)){seen.add(id);if(!first)first=info(m);oldest=info(m);const q=m.querySelector('[data-testid="quoted-message"]');if(q){const c=m.cloneNode(true);c.querySelectorAll('[data-testid="quoted-message"]').forEach(x=>x.remove());quotes.set(id,{reply_id:id,reply_time:stamp,quoted_text:q.innerText?.trim()||q.textContent?.trim()||'',reply_text:[...c.querySelectorAll('.selectable-text')].map(x=>x.textContent?.trim()).filter(Boolean).join(' ')})}}if(reacted.has(id))continue;const b=m.querySelector('[data-testid="reaction-bubble"]');if(!b)continue;reacted.add(id);const emojis=[...b.querySelectorAll('img[alt]')].map(e=>e.alt),found=new Set();const ob=new MutationObserver(cs=>{for(const c of cs)for(const n of(c.type==='childList'?[...c.addedNodes]:[c.target])){if(n.nodeType!==1)continue;for(const e of[n,...n.querySelectorAll('[aria-label]')]){const a=e.getAttribute('aria-label')||'';if(a.includes(' reacted with '))found.add(a)}}});ob.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['aria-label']});b.click();for(let k=0;k<22&&run;k++){await sleep(100);if(found.size){await sleep(200);break}}ob.disconnect();const foundReactions=[...found].map(parse).filter(r=>r&&emojis.some(e=>norm(e)===norm(r.emoji)));reactions.set(id,{message_id:id,timestamp:stamp,emojis,reactions:foundReactions,status:foundReactions.length?'verified':'unresolved'});const active=document.activeElement;if(active?.isContentEditable||active?.matches?.('textarea,input,[role="textbox"]'))active.blur();show('collecting');await sleep(120)}};show('starting');let previous=0;for(let k=0;k<80&&run;k++){await scan();if(!run)break;const before=sc.scrollTop;sc.scrollTop-=Math.max(250,sc.clientHeight*.7);sc.dispatchEvent(new Event('scroll',{bubbles:true}));steps++;show('scrolling backwards');await sleep(1150);stalls=Math.abs(sc.scrollTop-before)<2&&seen.size===previous?stalls+1:0;previous=seen.size;if(stalls>=6){reason='No more older messages detected';break}}if(!reason)reason=run?'80-scroll test limit':'Stopped by user';run=false;stop.textContent='FINISHED';show(reason+' — COPY JSON')}catch(e){const t=document.querySelector('#tg5 div');if(t)t.textContent='ERROR: '+e.message;else alert('Tangled: '+e.message)}})()"""
    private fun copyScannerCode(label:String, code:String) {
        val clipboard=getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText(label,code))
        alert("Bookmarklet copied. Save it as a Chrome bookmark, then open WhatsApp Web and run it from Chrome's address bar.")
    }
    private fun makeTest8Bookmarklet():String = """javascript:(async()=>{try{['tg5','tg6','tg7','tg8'].forEach(x=>document.getElementById(x)?.remove());let main=document.querySelector('#main');if(!main){alert('Open chat');return}let wait=t=>new Promise(r=>setTimeout(r,t)),run=true,steps=0,stall=0,why='',first=null,oldest=null,S=new Set(),R=new Set(),Q=new Map(),E=new Map(),p=document.createElement('div'),h=document.createElement('div'),stop=document.createElement('button'),copy=document.createElement('button');p.id='tg8';p.style.cssText='position:fixed;top:6px;left:8px;right:8px;z-index:2147483647;background:teal;color:white;padding:10px';stop.textContent='STOP';copy.textContent='SAVE JSON';p.append(h,stop,copy);document.body.append(p);let msgs=()=>[...main.querySelectorAll('[data-id]')].filter(m=>m.querySelector('[data-pre-plain-text]')),info=m=>({id:m.getAttribute('data-id'),time:m.querySelector('[data-pre-plain-text]')?.getAttribute('data-pre-plain-text')||''}),txt=m=>{let c=m.cloneNode(true);c.querySelectorAll('[data-testid="quoted-message"],[data-testid="reaction-bubble"]').forEach(x=>x.remove());return [...c.querySelectorAll('.selectable-text')].map(x=>x.textContent.trim()).filter(Boolean).join(' ')},count=()=>[...E.values()].reduce((n,x)=>n+x.reactions.length,0),show=t=>h.textContent='T8 '+S.size+' msgs '+Q.size+' quotes '+count()+' reacts '+steps+' scrolls '+t;stop.onclick=()=>{run=false;why='Stopped';show('stopping')};copy.onclick=async()=>{let j=JSON.stringify({test:'tangled-quotes-reactions-test7',scroll_steps:steps,unique_messages_seen:S.size,stop_reason:why,checkpoint:{newest:first,oldest},quotes:[...Q.values()],reactions:[...E.values()]}),name='tangled-scan-'+Date.now()+'.json';try{if(!window.showSaveFilePicker)throw Error('Unsupported');let f=await showSaveFilePicker({suggestedName:name}),w=await f.createWritable();await w.write(j);await w.close();copy.textContent='SAVED'}catch(e){if(e.name==='AbortError')return;let u=URL.createObjectURL(new Blob([j],{type:'application/json'})),a=document.createElement('a');a.href=u;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),60000);copy.textContent='DOWNLOADING'}};let sc=[...main.querySelectorAll('div')].filter(e=>e.clientHeight>180&&e.scrollHeight>e.clientHeight+150&&/auto|scroll/.test(getComputedStyle(e).overflowY)).sort((a,b)=>b.clientHeight-a.clientHeight)[0];if(!sc){show('No scroll');return}let norm=s=>String(s||'').replace(/[\uFE0E\uFE0F]/g,'').trim(),scan=async()=>{for(let m of msgs()){if(!run)break;let id=m.getAttribute('data-id'),time=info(m).time;if(!S.has(id)){S.add(id);if(!first)first=info(m);oldest=info(m);let q=m.querySelector('[data-testid="quoted-message"]');if(q)Q.set(id,{reply_id:id,reply_time:time,quoted_text:q.innerText?.trim()||q.textContent.trim(),reply_text:txt(m)})}if(R.has(id))continue;let b=m.querySelector('[data-testid="reaction-bubble"]');if(!b)continue;R.add(id);let text=txt(m),emojis=[...b.querySelectorAll('img[alt]')].map(x=>x.alt),found=new Set(),ob=new MutationObserver(cs=>{for(let c of cs)for(let n of(c.type==='childList'?[...c.addedNodes]:[c.target])){if(n.nodeType!==1)continue;for(let x of[n,...n.querySelectorAll('[aria-label]')]){let a=x.getAttribute('aria-label')||'';if(a.includes(' reacted with '))found.add(a)}}});ob.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['aria-label']});b.click();for(let k=0;k<22&&run;k++){await wait(100);if(found.size){await wait(200);break}}ob.disconnect();let matches=[...found].map(a=>{let z=a.split(' reacted with ');return z.length===2?{actor:z[0]==='You'?'self':z[0],emoji:z[1].replace(' Click to remove','')}:null}).filter(x=>x&&emojis.some(e=>norm(e)===norm(x.emoji)));E.set(id,{message_id:id,timestamp:time,message_text:text,emojis,reactions:matches,status:matches.length?'verified':'unresolved'});let a=document.activeElement;if(a&&(a.isContentEditable||a.matches?.('textarea,input,[role="textbox"]')))a.blur();show('collecting');await wait(120)}};show('starting');let prev=0;for(let k=0;k<80&&run;k++){await scan();if(!run)break;let before=sc.scrollTop;sc.scrollTop-=Math.max(250,sc.clientHeight*.7);sc.dispatchEvent(new Event('scroll',{bubbles:true}));steps++;show('scrolling');await wait(1150);stall=Math.abs(sc.scrollTop-before)<2&&S.size===prev?stall+1:0;prev=S.size;if(stall>=6){why='Oldest';break}}if(!why)why=run?'80 limit':'Stopped';run=false;stop.textContent='FINISHED';show(why+' - SAVE JSON')}catch(e){let h=document.querySelector('#tg8 div');if(h)h.textContent='ERROR: '+e.message;else alert('Test 8: '+e.message)}})()"""

    private fun makeTest7Bookmarklet():String = """javascript:(async()=>{try{document.getElementById('tg7')?.remove();let main=document.querySelector('#main');if(!main){alert('Open WhatsApp chat');return}let wait=t=>new Promise(r=>setTimeout(r,t)),run=true,steps=0,stall=0,why='',first=null,oldest=null,S=new Set(),R=new Set(),Q=new Map(),E=new Map(),p=document.createElement('div'),h=document.createElement('div'),stop=document.createElement('button'),copy=document.createElement('button');p.id='tg7';p.style.cssText='position:fixed;top:6px;left:8px;right:8px;z-index:2147483647;background:#075e54;color:white;padding:10px;border-radius:8px;font:13px Arial';for(let b of[stop,copy])b.style.cssText='padding:10px;margin:5px;background:white;color:#075e54;border:0;border-radius:6px';stop.textContent='STOP';copy.textContent='SAVE JSON';p.append(h,stop,copy);document.body.append(p);let msgs=()=>[...main.querySelectorAll('[data-id]')].filter(m=>m.querySelector('[data-pre-plain-text]')),info=m=>({id:m.getAttribute('data-id'),time:m.querySelector('[data-pre-plain-text]')?.getAttribute('data-pre-plain-text')||''}),txt=m=>{let c=m.cloneNode(true);c.querySelectorAll('[data-testid="quoted-message"],[data-testid="reaction-bubble"]').forEach(x=>x.remove());return [...c.querySelectorAll('.selectable-text')].map(x=>x.textContent.trim()).filter(Boolean).join(' ')},count=()=>[...E.values()].reduce((n,x)=>n+x.reactions.length,0),show=t=>h.textContent='Test 7 | '+S.size+' messages | '+Q.size+' quotes | '+count()+' reactions | '+steps+' scrolls | '+t;stop.onclick=()=>{run=false;why='Stopped by user';show('stopping')};copy.onclick=()=>{let j=JSON.stringify({test:'tangled-quotes-reactions-test7',scroll_steps:steps,unique_messages_seen:S.size,stop_reason:why,checkpoint:{newest:first,oldest},quotes:[...Q.values()],reactions:[...E.values()]});try{let u=URL.createObjectURL(new Blob([j],{type:'application/json'})),a=document.createElement('a');a.href=u;a.download='tangled-scan-'+Date.now()+'.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),60000);copy.textContent='SAVE REQUESTED'}catch(e){alert('Save failed: '+e.message)}};let sc=[...main.querySelectorAll('div')].filter(e=>e.clientHeight>180&&e.scrollHeight>e.clientHeight+150&&/auto|scroll/.test(getComputedStyle(e).overflowY)).sort((a,b)=>b.clientHeight-a.clientHeight)[0];if(!sc){show('Scroller not found');return}let norm=s=>String(s||'').replace(/[\uFE0E\uFE0F]/g,'').trim(),scan=async()=>{for(let m of msgs()){if(!run)break;let id=m.getAttribute('data-id'),time=info(m).time;if(!S.has(id)){S.add(id);if(!first)first=info(m);oldest=info(m);let q=m.querySelector('[data-testid="quoted-message"]');if(q)Q.set(id,{reply_id:id,reply_time:time,quoted_text:q.innerText?.trim()||q.textContent.trim(),reply_text:txt(m)})}if(R.has(id))continue;let b=m.querySelector('[data-testid="reaction-bubble"]');if(!b)continue;R.add(id);let text=txt(m),emojis=[...b.querySelectorAll('img[alt]')].map(x=>x.alt),found=new Set(),ob=new MutationObserver(cs=>{for(let c of cs)for(let n of(c.type==='childList'?[...c.addedNodes]:[c.target])){if(n.nodeType!==1)continue;for(let x of[n,...n.querySelectorAll('[aria-label]')]){let a=x.getAttribute('aria-label')||'';if(a.includes(' reacted with '))found.add(a)}}});ob.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['aria-label']});b.click();for(let k=0;k<22&&run;k++){await wait(100);if(found.size){await wait(200);break}}ob.disconnect();let matches=[...found].map(a=>{let z=a.split(' reacted with ');return z.length===2?{actor:z[0]==='You'?'self':z[0],emoji:z[1].replace(' Click to remove','')}:null}).filter(x=>x&&emojis.some(e=>norm(e)===norm(x.emoji)));E.set(id,{message_id:id,timestamp:time,message_text:text,emojis,reactions:matches,status:matches.length?'verified':'unresolved'});let a=document.activeElement;if(a&&(a.isContentEditable||a.matches?.('textarea,input,[role="textbox"]')))a.blur();show('collecting');await wait(120)}};show('starting');let prev=0;for(let k=0;k<80&&run;k++){await scan();if(!run)break;let before=sc.scrollTop;sc.scrollTop-=Math.max(250,sc.clientHeight*.7);sc.dispatchEvent(new Event('scroll',{bubbles:true}));steps++;show('scrolling');await wait(1150);stall=Math.abs(sc.scrollTop-before)<2&&S.size===prev?stall+1:0;prev=S.size;if(stall>=6){why='Oldest reached';break}}if(!why)why=run?'80 scroll limit':'Stopped by user';run=false;stop.textContent='FINISHED';show(why+' - SAVE JSON')}catch(e){let h=document.querySelector('#tg7 div');if(h)h.textContent='ERROR: '+e.message;else alert('Test 7: '+e.message)}})()"""

    private fun makeUpdateBookmarklet(stopId:String):String {
        // Tested longer update scanner (3C); the target is the last verified newest-message checkpoint.
        return """javascript:(()=>{if(window.__tu){alert('Update scanner already open');return}const STOP='${stopId}',R=new Map(),S=new Set(),chat=document.querySelector('#main header [data-testid="conversation-info-header-chat-title"]')?.textContent?.trim()||document.querySelector('#main header span[title]')?.getAttribute('title')?.trim()||'';let steps=0,done=false,halt=false,stalls=0,timer;const p=document.createElement('div');p.style.cssText='position:fixed!important;bottom:8px!important;left:8px!important;right:8px!important;z-index:2147483647!important;background:#075e54;color:white;padding:10px;border-radius:9px;font:12px Arial';const info=document.createElement('div'),b=document.createElement('button'),discard=document.createElement('button');b.textContent='Stop & Export';discard.textContent='Stop Without Saving';b.style.cssText='margin-top:6px;background:white;color:#075e54;border:0;border-radius:6px;padding:8px';discard.style.cssText=b.style.cssText+';margin-left:7px';p.append(info,b,discard);document.documentElement.append(p);window.__tu=p;function ms(){return [...document.querySelectorAll('[data-id]')].filter(x=>x.querySelector('[data-pre-plain-text]'))}const first=ms(),top=first[first.length-1],topid=top?.getAttribute('data-id')||'',toptime=top?.querySelector('[data-pre-plain-text]')?.getAttribute('data-pre-plain-text')||'';function read(){let a=ms(),i=a.findIndex(x=>x.getAttribute('data-id')===STOP);for(let x of(i<0?a:a.slice(i+1))){let id=x.getAttribute('data-id');if(!id||id===STOP||S.has(id))continue;S.add(id);let q=x.querySelector('[data-testid="quoted-message"]');if(!q)continue;let c=x.cloneNode(true);c.querySelectorAll('[data-testid="quoted-message"]').forEach(z=>z.remove());R.set(id,{reply_id:id,reply_time:x.querySelector('[data-pre-plain-text]')?.getAttribute('data-pre-plain-text')||'',quoted_text:q.innerText.trim(),reply_text:[...c.querySelectorAll('.selectable-text')].map(z=>z.textContent.trim()).filter(Boolean).join('\n')})}if(i>=0)done=true}function status(t){info.textContent='Tangled update: '+t+' | '+S.size+' messages | '+R.size+' replies | '+steps+' steps'}async function saveJson(data,name){const json=JSON.stringify(data,null,2);if(typeof showSaveFilePicker==='function'){try{const h=await window.showSaveFilePicker({suggestedName:name,types:[{description:'JSON',accept:{'application/json':['.json']}}]});const w=await h.createWritable();await w.write(json);await w.close();return true}catch(e){if(e.name==='AbortError'){status('Save cancelled — tap Export JSON to retry');return false}alert('Save picker unavailable ('+e.message+'). Downloading instead.')}}const u=URL.createObjectURL(new Blob([json],{type:'application/json'}));const a=document.createElement('a');a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),60000);return true;}async function save(){clearInterval(timer);halt=true;read();let d={version:2,scanner_version:13,chat_name:chat,source_chat_name:chat,scan_mode:'new',checkpoint_reached:done,scan_complete:done,stop_reason:done?'Previous newest message found':'Stopped before checkpoint',checkpoint:{prior_checkpoint_id:STOP,prior_newest_message_id:STOP,newest_message_id:topid,newest_message_time:toptime},message_ids_seen:S.size,replies:[...R.values()]};const saved=await saveJson(d,chat?chat.replace(/[\\/:*?"<>|]/g,'_')+'-quoted-update.json':'tangled-update-replies.json');if(saved){p.remove();delete window.__tu}else{status('Export cancelled — tap Stop & Export to retry')}}b.onclick=save;discard.onclick=()=>{halt=true;clearInterval(timer);p.remove();delete window.__tu};function scroller(){let e=ms()[0];while(e&&!(e.scrollHeight>e.clientHeight+100&&e.clientHeight>120))e=e.parentElement;return e}function tick(){if(halt)return;try{read();if(done){clearInterval(timer);status('CHECKPOINT FOUND — tap Export');b.textContent='Export JSON';return}let s=scroller();if(!s){clearInterval(timer);status('No scroll area — export incomplete');return}let t=s.scrollTop;s.scrollTop=Math.max(0,t-Math.max(140,s.clientHeight*.45));s.dispatchEvent(new Event('scroll',{bubbles:true}));steps++;stalls=Math.abs(t-s.scrollTop)<3?stalls+1:0;if(stalls>=8){clearInterval(timer);status('No movement — export incomplete')}else status('Seeking previous newest message')}catch(e){clearInterval(timer);status('Error: '+e.message)}}status('Starting');timer=setInterval(tick,1100);tick()})()"""
    }
    private fun scanDate(header:String):Long? = try {
        val found=Regex("""\[([^]]+)]""").find(header)
        found?.groupValues?.get(1)?.let {SimpleDateFormat("h:mm a, M/d/yyyy",Locale.US).apply{isLenient=false}.parse(it)?.time}
    }catch(_:Exception){null}
    private fun compactSyncBookmarklet():String = assets.open("quote_reaction_sync.js").bufferedReader().use{it.readText()}
    private fun showCoverageTimeline(content:LinearLayout,id:Long) {
        val scanner=db.scanCoverage(id)
        val web=db.webQuoteCoverage(id)
        content.addView(text("Conversation coverage",18f,green,true))
        content.addView(text("Quotes and reactions have separate coverage. WhatsApp Web Markdown supplies quote evidence only; bookmarklet JSON supplies both.",12f,Color.DKGRAY))
        // Both coverage percentages use the full archived conversation as the
        // denominator; covered date ranges are still clipped to its bounds.
        val bounds=db.conversationTimeBounds(id)
        if(bounds==null) {
            content.addView(text("No conversation messages yet. Import the chat before displaying coverage.",13f,Color.DKGRAY))
            return
        }
        val start=bounds.first
        val end=bounds.second
        val fmt=SimpleDateFormat("d MMM yyyy, HH:mm",Locale.UK)
        val dayFmt=SimpleDateFormat("d MMM yyyy",Locale.UK)
        content.addView(text("Full conversation: ${fmt.format(Date(start))} – ${fmt.format(Date(end))}",13f,Color.DKGRAY))
        if(scanner.isEmpty() && web.isEmpty()) {
            content.addView(text("No scan ranges recorded yet. Import a WhatsApp Web ZIP or Quotes & Reactions JSON to begin.",13f,Color.DKGRAY))
        }
        // Clip to the conversation before merging. Do not bridge real gaps.
        fun merge(ranges:List<Pair<Long,Long>>):List<Pair<Long,Long>> {
            val joined=mutableListOf<Pair<Long,Long>>()
            for((a,b) in ranges) {
                val lo=maxOf(start,minOf(a,b))
                val hi=minOf(end,maxOf(a,b))
                if(hi<lo)continue
                val last=joined.lastOrNull()
                if(last!=null && lo<=last.second)
                    joined[joined.lastIndex]=last.first to maxOf(last.second,hi)
                else joined.add(lo to hi)
            }
            return joined
        }
        fun cleaned(ranges:List<Pair<Long,Long>>)=merge(ranges.sortedBy{minOf(it.first,it.second)})
        val quotes=cleaned(scanner.map{it.oldest to it.newest}+web)
        val reactions=cleaned(scanner.map{it.oldest to it.newest})
        fun coverageBar(label:String,intervals:List<Pair<Long,Long>>,color:Int,source:String) {
            content.addView(text(label,16f,color,true))
            content.addView(text(source,11f,Color.DKGRAY))
            // Each message takes equal horizontal space. Keep the 4.4.81
            // chronological, backwards-scanning layout, including grey gaps;
            // unlike its time-based widths, each segment is proportional to the
            // number of archived messages in that covered/uncovered region.
            val segments=db.archivedCoverageMessageSegments(id,intervals)
            val totalMessages=segments.sumOf{it.second}
            val coveredMessages=segments.filter{it.first}.sumOf{it.second}
            val percentage=if(totalMessages>0L)
                (coveredMessages.toDouble()*100.0/totalMessages).coerceIn(0.0,100.0)
                else 0.0
            val track=LinearLayout(this).apply {
                orientation=LinearLayout.HORIZONTAL
                minimumHeight=dp(20)
                setBackgroundColor(Color.LTGRAY)
            }
            for((filled,count) in segments) {
                if(count<=0L)continue
                track.addView(View(this).apply {
                    setBackgroundColor(if(filled)color else Color.LTGRAY)
                },LinearLayout.LayoutParams(0,dp(18),count.toFloat()))
            }
            if(segments.isEmpty()) {
                track.addView(View(this).apply {setBackgroundColor(Color.LTGRAY)},
                    LinearLayout.LayoutParams(0,dp(18),1f))
            }
            content.addView(track)
            // The date list is part of each timeline, not just the shared axis.
            content.addView(text("Covered periods",13f,color,true))
            if(intervals.isEmpty())content.addView(text("No recorded coverage",12f,Color.DKGRAY))
            for((lo,hi) in intervals) {
                content.addView(text("• ${fmt.format(Date(lo))} – ${fmt.format(Date(hi))}",12f,Color.DKGRAY))
            }
            val gaps=(0 until intervals.size-1).count{intervals[it+1].first>intervals[it].second}
            val edges=(if(intervals.isEmpty()) 1 else (if(intervals.first().first>start)1 else 0)+(if(intervals.last().second<end)1 else 0))
            content.addView(text("${String.format(Locale.UK,"%.1f",percentage)}% of messages covered ($coveredMessages / $totalMessages) · ${intervals.size} period(s) · ${gaps+edges} uncovered region(s)",12f,Color.DKGRAY))
        }
        coverageBar("Quoted Messages",quotes,green,"WhatsApp Web Markdown + bookmarklet JSON")
        coverageBar("Reactions",reactions,Color.rgb(103,139,205),"Bookmarklet JSON")
        content.addView(text("Bars show the conversation from oldest (left) to newest (right), with coloured coverage and grey gaps. Each message contributes equal bar width, so the coloured share is the percentage of archived messages covered; covered dates are listed above. A period containing no messages contributes no width. Overlapping scans count once. Coverage is estimated from reported scan periods, not proof that every message was inspected.",12f,Color.DKGRAY))
        // Retain separate date-based gap planning for quotes and reactions.
        fun gapPlans(label:String,intervals:List<Pair<Long,Long>>) {
            val gaps=mutableListOf<Pair<Long,Long>>()
            var cursor=start
            for((lo,hi) in intervals){if(lo>cursor)gaps.add(cursor to lo);cursor=maxOf(cursor,hi)}
            if(cursor<end)gaps.add(cursor to end)
            for((i,gap) in gaps.withIndex()) {
                val gapStart=gap.first;val gapEnd=gap.second
                val search=java.util.Calendar.getInstance().apply{timeInMillis=gapEnd;add(java.util.Calendar.DAY_OF_MONTH,1)}
                val searchDate=SimpleDateFormat("d MMMM yyyy",Locale.UK).format(search.time)
                val days=String.format(Locale.UK,"%.1f",(gapEnd-gapStart)/86400000.0)
                content.addView(text("$label gap ${i+1} · $days days · ${fmt.format(Date(gapStart))} to ${fmt.format(Date(gapEnd))}",13f,Color.DKGRAY))
                content.addView(button("Plan $label gap scan · Search $searchDate") {
                    val clipboard=getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("WhatsApp search date",searchDate))
                    alert("Date copied: $searchDate. Find it in WhatsApp Web and scan backwards using the Quotes & Reactions bookmarklet. Save JSON into the watched folder.")
                })
            }
        }
        gapPlans("Quote",quotes)
        gapPlans("Reaction",reactions)
        if(reactions.isNotEmpty() && reactions.first().first>start) {
            val oldest=reactions.first().first
            val date=java.util.Calendar.getInstance().apply{timeInMillis=oldest;add(java.util.Calendar.DAY_OF_MONTH,1)}
            val suggested=SimpleDateFormat("d MMMM yyyy",Locale.UK).format(date.time)
            content.addView(button("Extend older reaction history · Search $suggested") {
                val clipboard=getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("WhatsApp historical start",suggested))
                alert("Date copied: $suggested. Find it in WhatsApp Web, scan backwards and save JSON. This extends reaction and quote coverage.")
            })
        }
        content.addView(text("Recent bookmarklet scans",15f,green,true))
        for(item in scanner.asReversed().take(12)) {
            val suffix=when(item.reason.lowercase(Locale.ROOT)){"checkpoint"->"Checkpoint reached";"oldest"->"No more messages loaded";else->"Stopped / partial"}
            content.addView(text("${fmt.format(Date(item.oldest))} – ${fmt.format(Date(item.newest))} · ${item.count} messages · $suffix",12f,Color.DKGRAY))
        }
    }
    private fun replyExporterGuide() {
        val id=chatId ?: return
        val history=db.historyResume(id)
        val historyTime=db.historyResumeTime(id)
        val parent=screen("Quotes & Reactions", "WhatsApp Web · quoted messages and reactions",true)
        val content=scroller(parent)
        content.addView(text("Quotes & Reactions",22f,green,true))
        val reactionSummary=db.reactionCounts(id)
        content.addView(text("Reactions: ${reactionSummary.first} saved · ${reactionSummary.second} awaiting message match",15f,green,true))
        content.addView(button("Retry matching saved reactions") {
            db.retryReactionMatches(id)
            val counts=db.reactionCounts(id)
            alert("Reactions: ${counts.first} saved · ${counts.first-counts.second} linked to messages · ${counts.second} awaiting message match. No source files were changed.")
        })
        content.addView(button("Your Name · ${getSharedPreferences("tangled_user",MODE_PRIVATE).getString("your_name","You")}") {editSelfName()})
        content.addView(text("Link quoted messages and collect emoji reactions from WhatsApp Web. Existing quote links and their history are preserved.",13f,Color.DKGRAY))
        val jumpDate=try {
            val millis=scanDate(historyTime)!!
            val cal=java.util.Calendar.getInstance().apply{timeInMillis=millis;add(java.util.Calendar.DAY_OF_MONTH,1)}
            SimpleDateFormat("d MMMM yyyy",Locale.UK).format(cal.time)
        }catch(_:Exception){null}
        val status=when { history==null -> "No previous scan"; jumpDate!=null -> "Start scan at $jumpDate"; else -> "Previous scan found · date unavailable" }
        content.addView(text("NEXT HISTORICAL SCAN",13f,green,true))
        content.addView(text(status,20f,green,true))
        content.addView(Space(this).apply{minimumHeight=dp(8)})
        content.addView(button("Copy Quotes & Reactions bookmarklet") {copyScannerCode("Tangled Quotes & Reactions",compactSyncBookmarklet())})
        content.addView(text("One bookmarklet for updates, older history and gaps. Start at the newest messages for updates; search the suggested date for older history or gaps. SAVE JSON into the watched folder. Chrome's saved checkpoint can stop an update; otherwise press STOP when you want to finish.",13f,Color.DKGRAY))
        val oldScanners=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE}
        content.addView(button("Older scanner tools  ▾") { oldScanners.visibility=if(oldScanners.visibility==View.VISIBLE)View.GONE else View.VISIBLE })
        content.addView(oldScanners)
        oldScanners.addView(button("Legacy historical scanner") {copyScannerCode("Legacy historical scanner",makeTest8Bookmarklet())})
        val checkpoint=db.webCheckpoint(id).ifBlank {history?.first.orEmpty()}
        oldScanners.addView(button("Legacy update scanner") {
            if(checkpoint.isBlank())alert("Import a historical scan first. Tangled needs a saved message checkpoint before it can safely stop an update scan.")
            else copyScannerCode("Tangled update scanner",makeUpdateBookmarklet(checkpoint))
        })
        content.addView(button("Import Quotes & Reactions JSON") {chooseReplyJson()})
        content.addView(text("Use SAVE JSON in WhatsApp Web and choose the watched Auto Sync folder. Tangled imports saved JSON files; clipboard contents are never inspected.",12f,Color.DKGRAY))
        content.addView(Space(this).apply{minimumHeight=dp(12)})
        showCoverageTimeline(content,id)
        content.addView(text("Existing scan checkpoints",18f,green,true))
        val recent=db.scanEvents(id)
        if(history==null && db.webCheckpoint(id).isBlank()) content.addView(text("No scan data yet",14f,Color.DKGRAY))
        else {
            val upper=db.latestCompleteScanTime(id)
            val lower=scanDate(historyTime)
            if(upper!=null)content.addView(text("●  "+dateFormat.format(Date(upper))+"  ·  Newest complete update",14f,green,true))
            if(upper!=null && lower!=null)content.addView(text("│  Successfully scanned coverage",13f,green))
            if(lower!=null)content.addView(text("●  "+dateFormat.format(Date(lower))+"  ·  Oldest historical scan",14f,green,true))
            for(event in recent.take(8)) {
                val stamp=event.second?.let {dateFormat.format(Date(it))} ?: "Date unavailable"
                val symbol=if(event.first) "●" else "┊"
                val suffix=if(event.first) "Completed scan" else "Partial scan · checkpoint unchanged"
                content.addView(text("$symbol  $stamp  ·  $suffix",13f,if(event.first) green else Color.DKGRAY))
            }
        }
        val instructions=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE}
        content.addView(button("How to sync quoted messages  ▾") {instructions.visibility=if(instructions.visibility==View.VISIBLE)View.GONE else View.VISIBLE})
        content.addView(instructions)
        instructions.addView(text("1  Open Chrome Incognito, choose Desktop site, sign in at web.whatsapp.com, and open your conversation.",14f,Color.DKGRAY))
        instructions.addView(text("2  Historical: jump to the suggested date BEFORE running your saved historical bookmarklet. For a first scan, start at the newest messages.",14f,Color.DKGRAY))
        instructions.addView(text("3  Update: start at the newest WhatsApp message and run the same Quotes & Reactions bookmarklet. For a gap, use its Plan gap scan date. The bookmarklet only scans backwards.",14f,Color.DKGRAY))
        instructions.addView(text("4  Press STOP then SAVE JSON, or save after the bookmarklet finds its Chrome checkpoint. Choose the watched Auto Sync folder. Tangled records the scanned time range and imports quotes and reactions; partial scans are kept.",14f,Color.DKGRAY))
        instructions.addView(button("Open WhatsApp Web") {startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://web.whatsapp.com/")))})
        if(history!=null)instructions.addView(button("Reset historical scan progress") {
            AlertDialog.Builder(this).setTitle("Reset historical scan progress?").setMessage("This clears the historical date but preserves existing reply links.").setNegativeButton("Cancel",null).setPositiveButton("Reset") {_,_->db.clearHistoryResume(id);replyExporterGuide()}.show()
        })
        content.addView(Space(this).apply{minimumHeight=dp(14)})
        content.addView(text("Manage Quoted Message Sync",18f,green,true))
        content.addView(button("Sync Management  ›") {showSyncManagement()})
    }

    private fun editSelfName() {
        val prefs=getSharedPreferences("tangled_user",MODE_PRIVATE)
        val field=EditText(this).apply {
            setSingleLine(true);setText(prefs.getString("your_name","You"))
            selectAll()
        }
        AlertDialog.Builder(this).setTitle("Your Name")
            .setMessage("Display name for WhatsApp reactions labelled You. The stored identity remains self.")
            .setView(field).setNegativeButton("Cancel",null)
            .setPositiveButton("Save") { _,_->
                prefs.edit().putString("your_name",field.text.toString().trim().ifBlank {"You"}).apply()
                replyExporterGuide()
            }.show()
    }

    private fun showSyncManagement() {
        val id=chatId ?: return
        AlertDialog.Builder(this).setTitle("Manage Quoted Message Sync")
            .setItems(arrayOf("Link messages manually", "Manage all quoted messages", "Reset historical scan progress", "Manage watched folder", "Clear imported reactions")) { _, choice ->
                when(choice) {
                    0 -> {pendingReply=null;selectingReply=true;showChat(previousChatQuery,previousChatPage)}
                    1 -> manageAllReplyLinks(id,previousChatQuery,previousChatPage)
                    2 -> AlertDialog.Builder(this).setTitle("Reset historical scan progress?")
                        .setMessage("This clears the historical date but keeps existing quote links.")
                        .setNegativeButton("Cancel",null)
                        .setPositiveButton("Reset") { _,_->db.clearHistoryResume(id);replyExporterGuide()}.show()
                    3 -> showAutoSync()
                    4 -> AlertDialog.Builder(this).setTitle("Clear imported reactions?")
                        .setMessage("This removes saved reaction records for this chat, but keeps quoted-message links.")
                        .setNegativeButton("Cancel",null)
                        .setPositiveButton("Clear") { _,_->db.clearReactions(id);replyExporterGuide()}.show()
                }
            }.show()
    }
    private fun chooseReplyJson() {
        if(chatId==null)return
        val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply {addCategory(Intent.CATEGORY_OPENABLE);type="application/json";putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("application/json","text/plain","application/octet-stream"))}
        externalFilePickerOpen=true
        try { startActivityForResult(intent,replyJsonCode) }
        catch(e:Exception) {externalFilePickerOpen=false;alert("Unable to open file picker: ${e.message}")}
    }
    private fun loadReplyJson(uri:Uri) {
        try {
            val content=contentResolver.openInputStream(uri)?.bufferedReader()?.use {it.readText()} ?: throw IllegalArgumentException("Empty file")
            processReplyJson(content)
        }catch(e:Exception){alert("Unable to read scanner JSON: ${e.message}")}
    }
    private fun processReplyJson(content:String) {
        val id=chatId ?: return
        try {
            if(content.length>20_000_000)throw IllegalArgumentException("JSON exceeds the 20 MB import limit")
            val json=JSONObject(content)
            val test51=json.optString("test") in setOf("tangled-quotes-reactions-test5.1","tangled-quotes-reactions-test6","tangled-quotes-reactions-test7")
            if(!test51 && json.optInt("version") !in 1..2)throw IllegalArgumentException("Expected Tangled exporter version 1 or 2, or Test 5.1 JSON")
            val reactionRecords=json.optJSONArray("reactions")
            var importedReactions=0
            var unresolvedReactions=0
            if(reactionRecords!=null) {
                val fmt=SimpleDateFormat("h:mm a, M/d/yyyy",Locale.US).apply{isLenient=false}
                if(reactionRecords.length()>50000)throw IllegalArgumentException("Reaction file too large")
                for(j in 0 until reactionRecords.length()) {
                    val entry=reactionRecords.optJSONObject(j) ?: continue
                    val webId=entry.optString("message_id").trim()
                    val header=entry.optString("timestamp")
                    if(webId.isBlank())continue
                    val parsed=Regex("""^\[([^]]+)]\s*(.*?):\s*$""").find(header)
                    val sender=parsed?.groupValues?.get(2).orEmpty()
                    val instant=runCatching{fmt.parse(parsed?.groupValues?.get(1).orEmpty())?.time}.getOrNull()
                    val details=entry.optJSONArray("reactions") ?: continue
                    for(r in 0 until details.length()) {
                        val data=details.optJSONObject(r) ?: continue
                        val actor=data.optString("actor").trim()
                        val emoji=data.optString("emoji").trim()
                        if(actor.isBlank()||emoji.isBlank())continue
                        db.saveReaction(id,webId,header,sender,actor,emoji,instant,entry.optString("message_text"))
                        importedReactions++
                    }
                }
                db.retryReactionMatches(id)
                unresolvedReactions=db.reactionCounts(id).second
            }
            val array=(if(test51)json.optJSONArray("quotes") else json.optJSONArray("replies")) ?: org.json.JSONArray()
            if(array.length()>20000)throw IllegalArgumentException("This version accepts up to 20,000 quoted replies per file")
            val proposals=mutableListOf<ReplyProposal>()
            val latestArchivedTime=db.latestArchivedMessageTime(id)
            var futureRepliesSkipped=0
            val dateParser=SimpleDateFormat("h:mm a, M/d/yyyy",Locale.US).apply {isLenient=false}
            for(i in 0 until array.length()) {
                val entry=array.getJSONObject(i)
                // WhatsApp Web's [time, date] sender: header belongs to the REPLY, not the quotation.
                val header=entry.optString("reply_time")
                val match=Regex("""^\[([^]]+)]\s*(.*?):\s*$""").find(header)
                val timestamp=try {match?.groupValues?.get(1)?.let{dateParser.parse(it)?.time}}catch(_:Exception){null}
                // Replies newer than the local archive cannot be matched yet.
                // Exclude them entirely, including from original-message candidate searches.
                if(timestamp!=null && (latestArchivedTime==null || timestamp>latestArchivedTime)) {
                    futureRepliesSkipped++
                    continue
                }
                val replySender=match?.groupValues?.get(2)?.trim().orEmpty()
                val quote=entry.optString("quoted_text").trim()
                val parts=quote.split('\n',limit=2)
                val quotedSender=if(parts.size==2) parts[0].trim() else ""
                val quotedBody=(if(parts.size==2)parts[1] else quote).trim()
                // Quotations can be truncated by WhatsApp Web: match only the visible prefix.
                val usablePrefix=quotedBody.removeSuffix("...").trim().replace(Regex("""\s+""")," ").take(300)
                val replies=if(timestamp!=null && replySender.isNotBlank()) db.replyCandidates(id,timestamp,replySender) else emptyList()
                val originals=if(usablePrefix.length>=8) db.originalCandidates(id,usablePrefix,if(quotedSender.equals("You",true)) mySender else quotedSender,timestamp) else emptyList()
                proposals.add(ReplyProposal(i+1,quote.take(150),replies,originals,entry.optString("reply_text").trim(),timestamp))
            }
            if(proposals.isNotEmpty())showReplyProposals(id,proposals,futureRepliesSkipped)
            else if(importedReactions>0)alert("Saved $importedReactions reaction records. $unresolvedReactions cannot yet be linked unambiguously to archived messages.")
            // Keep the historical resume point separate from the new-message boundary.
            // Importing a partial scan cannot mark history complete.
            val meta=json.optJSONObject("checkpoint")
            val scanMode=if(test51)"legacy" else json.optString("scan_mode","legacy")
            val complete=json.optBoolean("scan_complete",false)
            val newest=meta?.optString("newest_message_id").orEmpty()
            if(scanMode=="history" || scanMode=="fresh" || scanMode=="resume") {
                val first=meta?.optString("history_start_id").orEmpty().ifBlank { newest }.ifBlank { meta?.optString("oldest_message_id").orEmpty() }
                val oldest=meta?.optString("oldest_message_id").orEmpty()
                val oldestTime=meta?.optString("oldest_message_time").orEmpty()
                val newestTime=meta?.optString("newest_message_time").orEmpty()
                val saved=db.historyResume(id)
                val timestampParser=SimpleDateFormat("h:mm a, M/d/yyyy",Locale.US).apply {isLenient=false}
                fun parsedTimestamp(raw:String):Long? = try {
                    val m=Regex("""\[([^]]+)]""").find(raw)
                    m?.groupValues?.get(1)?.let { timestampParser.parse(it)?.time }
                }catch(_:Exception){null}
                val previousTime=parsedTimestamp(db.historyResumeTime(id))
                val latestTime=parsedTimestamp(newestTime) ?: (0 until array.length()).mapNotNull { parsedTimestamp(array.getJSONObject(it).optString("reply_time")) }.maxOrNull()
                val nextOldestTime=parsedTimestamp(oldestTime)
                // First import must have a valid start and ending time. Subsequent scans
                // must cross the saved time boundary; overlaps are matched/deduplicated.
                // IDs are not directly comparable across scans without a full ID manifest.
                val crossesBoundary=saved!=null && previousTime!=null && latestTime!=null &&
                    nextOldestTime!=null && latestTime>=previousTime && nextOldestTime<previousTime
                val validStart=if(saved==null) first.isNotBlank() && nextOldestTime!=null
                    else crossesBoundary
                if(validStart && oldest.isNotBlank() && json.optInt("message_ids_seen",0)>0) {
                    val originalStart=saved?.first ?: first
                    // A stopped scan is not proof of reaching the first ever message.
                    if(complete && json.optString("stop_reason")=="Oldest confirmed") {
                        db.clearHistoryResume(id)
                        if(db.webCheckpoint(id).isBlank())db.setWebCheckpoint(id,originalStart)
                    } else {
                        db.saveHistoryResumeTime(id,originalStart,oldest,oldestTime)
                        db.saveScanEvent(id,true,scanDate(oldestTime))
                    }
                } else if(saved!=null && oldest.isNotBlank()) {
                    alert("Reply records were read, but historical progress was NOT advanced: the scan did not demonstrate timestamp overlap and extension beyond the saved boundary. Start on the suggested date and scroll farther back.")
                }
            } else {
                val prior=meta?.optString("prior_checkpoint_id").orEmpty().ifBlank { meta?.optString("prior_newest_message_id").orEmpty() }
                val stored=db.webCheckpoint(id).ifBlank { db.historyResume(id)?.first.orEmpty() }
                if(scanMode=="new" && complete && newest.isNotBlank() &&
                    prior.isNotBlank() && prior==stored && json.optBoolean("checkpoint_reached",false)) {
                    db.setWebCheckpoint(id,newest)
                    db.saveScanEvent(id,true,scanDate(meta?.optString("newest_message_time").orEmpty()))
                } else if(scanMode=="new") {
                    db.saveScanEvent(id,false,scanDate(meta?.optString("newest_message_time").orEmpty()))
                }
            }
        } catch(e:Exception) {alert("Could not read Tangled reply JSON: ${e.message ?: e.javaClass.simpleName}")}
    }
    // WhatsApp Web's v2 export includes the reply body, unlike the old v1 format.
    // Normalise only for matching; the archived text is never changed.
    private fun normaliseReplyText(value:String):String = value
        .replace("\u200e", "").replace("\u200f", "")
        .replace(Regex("(?i)\\(?this message was edited\\)?"), " ")
        .replace(Regex("[\\p{Punct}\\p{Z}\\s]+"), " ")
        .trim().lowercase(Locale.ROOT)

    // Approximate matching is restricted to same-sender candidates in the small time
    // window returned by ArchiveDb. It is never treated as verified/confident.
    // This handles exported edit notices and minor wording/formatting differences,
    // without silently mapping a reply to a neighbouring message just by time.
    private fun replyTextSimilarity(a:String,b:String):Double {
        if(a.isEmpty() || b.isEmpty())return 0.0
        if(a==b)return 1.0
        if(a.length>=12 && b.contains(a))return 0.96
        if(b.length>=12 && a.contains(b))return 0.91
        val aw=a.split(' ').filter{it.isNotBlank()}
        val bw=b.split(' ').filter{it.isNotBlank()}
        val at=aw.groupingBy{it}.eachCount()
        val bt=bw.groupingBy{it}.eachCount()
        val overlap=at.entries.sumOf{ (word,count)->minOf(count,bt[word]?:0) }
        val dice=2.0*overlap/(aw.size+bw.size).coerceAtLeast(1)
        // Avoid matching short generic phrases solely by one common word.
        return if(aw.size<4 || bw.size<4) {if(a==b)1.0 else 0.0} else dice
    }

    private fun replyMatchScore(candidate:Message, replyText:String, time:Long?):Int {
        val wanted=normaliseReplyText(replyText)
        val actual=normaliseReplyText(candidate.body)
        val similarity=replyTextSimilarity(wanted,actual)
        val textScore=when {
            wanted.isBlank() -> 0
            similarity>=0.999 -> 10000
            similarity>=0.94 -> 9000
            similarity>=0.83 -> 7600
            similarity>=0.74 -> 6100
            else -> -20000
        }
        val drift=if(time!=null) kotlin.math.abs(candidate.time-time) else 0L
        return textScore - (drift/1000L).coerceAtMost(200L).toInt()
    }

    private fun showReplyProposals(id:Long, proposals:List<ReplyProposal>, futureRepliesSkipped:Int=0) {
        var confident=0;var uncertain=0;var unmatched=0;var skipped=0;var replaced=0
        val summaries=mutableListOf<String>()
        for(p in proposals) {
            val options=p.replyCandidates.sortedWith(
                compareByDescending<Message> { replyMatchScore(it,p.replyText,p.replyTimestamp) }
                    .thenBy { kotlin.math.abs(it.time-(p.replyTimestamp ?: it.time)) }
                    .thenBy { it.fingerprint }.thenBy { it.occurrence })
            val originals=p.originalCandidates.sortedWith(compareBy<Message>{it.time}.thenBy{it.fingerprint}.thenBy{it.occurrence})
            val eligible=if(p.replyText.isNotBlank()) options.filter {replyMatchScore(it,p.replyText,p.replyTimestamp)>0} else options
            val pair=eligible.asSequence().flatMap { r ->
                originals.asSequence().filter { o -> o.fingerprint!=r.fingerprint || o.occurrence!=r.occurrence }.map { o -> r to o }
            }.firstOrNull()
            if(pair==null) {
                unmatched++
                val reason=when {
                    p.replyCandidates.isEmpty() && originals.isEmpty() -> "reply and original not found"
                    p.replyCandidates.isEmpty() -> "reply not found; ${originals.size} original candidate(s)"
                    originals.isEmpty() -> "original not found; ${p.replyCandidates.size} reply candidate(s)"
                    eligible.isEmpty() -> "reply text mismatch; ${p.replyCandidates.size} nearby reply(s), ${originals.size} original(s); closest score ${options.firstOrNull()?.let{replyMatchScore(it,p.replyText,p.replyTimestamp)} ?: 0}"
                    else -> "no plausible pair (same message or incompatible candidates)"
                }
                summaries.add("Quote ${p.number}: $reason")
                continue
            }
            val (reply,original)=pair
            val prior=db.replyTarget(id,reply)
            val priorStatus=if(prior!=null)db.replyStatus(id,reply) else ""
            if(prior!=null && priorStatus !in listOf("auto","uncertain")) {
                skipped++;summaries.add("Quote ${p.number}: manually verified link preserved");continue
            }
            if(prior!=null && prior.fingerprint==original.fingerprint && prior.occurrence==original.occurrence) {
                skipped++;summaries.add("Quote ${p.number}: existing link already correct");continue
            }
            // Never remove links on neighbouring replies as a side effect of importing
            // this record: consecutive replies may legitimately quote the same original.
            // setReplyLink updates the selected reply only; verified links remain protected.
            val topScore=replyMatchScore(reply,p.replyText,p.replyTimestamp)
            val tied=eligible.count{replyMatchScore(it,p.replyText,p.replyTimestamp)==topScore}>1
            val unsure=p.replyText.isBlank() || topScore<8500 || tied || originals.size!=1
            db.setReplyLink(id,reply,original)
            db.updateReplyStatus(id,reply,if(unsure)"uncertain" else "auto")
            if(unsure)uncertain++ else confident++
            summaries.add("Quote ${p.number}: ${if(unsure)"uncertain (?)" else "confident (✓)"} · ${eligible.size} reply candidates, ${originals.size} originals")
        }
        val parent=screen("Reply import results", "${proposals.size} records processed",true)
        val body=scroller(parent)
        body.addView(text("$confident confident · $uncertain uncertain · $unmatched unmatched · $skipped existing · $futureRepliesSkipped newer than archive (ignored)",17f,green,true))
        if(futureRepliesSkipped>0)body.addView(text("$futureRepliesSkipped WhatsApp Web replies are later than Tangled's newest archived message. None were sent to the matching algorithm. Update the chat archive and re-import this JSON to process them.",13f,Color.DKGRAY))
        body.addView(text("Reply text, sender and time are used together, with conservative similarity matching for consecutive replies. Unmatched records explain whether the reply, the original, or the text match failed. Manual confirmations remain protected; ? means check the link.",13f,Color.DKGRAY))
        for(summary in summaries)body.addView(text(summary,13f,Color.DKGRAY))
        parent.addView(button("Return to conversation") {showChat()})
    }
    private fun runCryptTask(title:String, work:()->String) {
        val progress=AlertDialog.Builder(this).setTitle(title).setMessage("Working locally…").setCancelable(false).create()
        progress.show()
        thread {
            val result=runCatching {work()}
            runOnUiThread {
                progress.dismiss()
                result.onSuccess { showCrypt15Menu();alert(it) }
                    .onFailure { showCrypt15Menu();alert("Crypt15: ${it.message ?: it.javaClass.simpleName}") }
            }
        }
    }
    private fun chooseCrypt15Backup() {
        val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type="*/*";addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        externalFilePickerOpen=true
        try {startActivityForResult(intent,cryptImportCode)}
        catch(e:Exception){externalFilePickerOpen=false;alert("Cannot open backup picker: ${e.message}")}
    }
    private fun showCrypt15Menu() {
        val root=screen("Crypt15 Import","Local encrypted WhatsApp database · additional import method",true)
        val body=scroller(root)
        body.addView(text(cryptSync.status(),16f,green,true))
        body.addView(text("Media and voice recordings continue to come from WhatsApp export ZIPs. Existing chats, bookmarks, media and manual names are retained.",13f,Color.DKGRAY))
        body.addView(button(if(cryptSync.hasKey())"Update encryption key" else "Enter encryption key") {
            val field=EditText(this).apply{hint="64 hexadecimal characters";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
            AlertDialog.Builder(this).setTitle("Crypt15 encryption key").setView(field)
                .setPositiveButton("Save securely") {_,_->
                    runCatching{cryptSync.saveKey(field.text.toString())}.onSuccess{showCrypt15Menu()}
                        .onFailure{alert(it.message?:"Cannot save key")}
                }.setNegativeButton("Cancel",null).show()
        })
        body.addView(button("Import crypt15 backup") {chooseCrypt15Backup()})
        if(cryptSync.hasBackup()) {
            body.addView(button("Browse / link conversations") {browseCrypt15Conversations()})
            body.addView(button("Sync linked conversations") {
                runCryptTask("Syncing crypt15 conversations") {
                    cryptSync.syncLinked().joinToString("\n").ifBlank{"No linked conversations found in this backup."}
                }
            })
        }
        body.addView(text("The watched Auto Sync folder also detects new .crypt15 files on subsequent scans. The latest verified backup replaces the previous private backup; the original in your watched folder is left untouched.",13f,Color.DKGRAY))
        if(cryptSync.lastSync().isNotBlank())body.addView(text("Last crypt15 sync: ${cryptSync.lastSync()}",13f,green))
        val history=cryptSync.history()
        if(history.isNotEmpty()){
            body.addView(text("Crypt15 Sync History",17f,green,true))
            history.take(12).forEach { body.addView(text(it,12f,Color.DKGRAY)) }
        }
        body.addView(button("Full Auto Sync history") {showAutoSync()})
    }
    private fun browseCrypt15Conversations() {
        val progress=AlertDialog.Builder(this).setMessage("Reading crypt15 conversations…").setCancelable(false).create();progress.show()
        thread {
            val result=runCatching{cryptSync.conversations()}
            runOnUiThread {
                progress.dismiss()
                result.onSuccess{list->
                    val root=screen("Crypt15 Conversations","Latest message first · ${list.size} conversations",true)
                    val body=scroller(root)
                    body.addView(text("Select a conversation to link it to Tangled. Already-linked conversations sync automatically when a new backup arrives.",13f,Color.DKGRAY))
                    for(item in list){
                        val target=item.linkedChat?.let{id->db.chats().firstOrNull{it.id==id}?.name}
                        val date=if(item.latest>0)dateFormat.format(Date(item.latest)) else "No date"
                        body.addView(button("${item.title}  ·  ${item.count} messages\n$date · ${target?.let{"Linked: $it"}?:"Not linked"}") {
                            val options=db.chats()
                            val labels=arrayOf("Import as NEW Tangled conversation")+options.map{"Link to: ${it.name}"}
                            AlertDialog.Builder(this).setTitle("Link ${item.title}")
                                .setItems(labels){_,which->
                                    val chosen=if(which==0){
                                        val base=item.title.ifBlank{"Crypt15 conversation"}
                                        var name=base;var number=2
                                        while(db.chats().any{it.name==name}){name="$base (crypt15 $number)";number++}
                                        db.createAutoChat(name)
                                    } else options[which-1].id
                                    cryptSync.link(item.jid,item.title,chosen)
                                    runCryptTask("Syncing ${item.title}") {
                                        val r=cryptSync.sync(item.jid)
                                        "${item.title}: ${r.added} new messages, ${r.skipped} already known."
                                    }
                                }.setNegativeButton("Cancel",null).show()
                        })
                    }
                }.onFailure{alert("Unable to list crypt15 conversations: ${it.message}")}
            }
        }
    }
    private fun runTask(title:String,work:()->String){
        val progress=AlertDialog.Builder(this).setTitle(title).setMessage("Working on your device…").setCancelable(false).create();progress.show()
        thread {
            val outcome=runCatching {work()}
            runOnUiThread {
                progress.dismiss();showHome()
                alert(outcome.getOrElse { "Operation failed: ${it.message ?: it.javaClass.simpleName}" })
            }
        }
    }
    private fun alert(message:String){AlertDialog.Builder(this).setMessage(message).setPositiveButton("OK",null).show()}
    @Deprecated("Use app back navigation")
    override fun onBackPressed() { navigateBack() }
}
